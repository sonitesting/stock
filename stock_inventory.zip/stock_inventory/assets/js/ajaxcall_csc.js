select_state();
//select_spare();
$(document).ready(function(){

	$(document).delegate('#country_id', 'change', function(){
		select_state();
	});

	$(document).delegate('#state_id', 'change', function(){
		select_city();
	});

	 
});

function select_state(){
	$country_id = $('#country_id').val();
	var state_id = $('#state_id_val').val();
	$('#state_id').html('<option value="">Select</option>');
	if($country_id != '' && $country_id != undefined && $country_id != " " ){
		$.ajax({
			type : 'POST',
			url: base_url+'ajaxcall',
			data : 'type=state&country_id='+$country_id,
			cache : false,
			success:function(result){
					var obj = $.parseJSON(result);
					var objlength = obj.length;
					var select_option = '';
					for(var i=0;i < objlength;i++){
						if(state_id == obj[i].id){
							select_option +='<option value="'+obj[i].id+'" selected>'+obj[i].state_name+'</option>'; 
						}else{
							select_option +='<option value="'+obj[i].id+'">'+obj[i].state_name+'</option>'; 	
						}
					}
					$('#state_id').append(select_option);
					select_city();
			}
		});
	}
}

function select_city(){
	$state_id = $('#state_id').val();
	var city_id = $('#city_id_val').val();
	$('#city_id').html('<option value="">Select</option>');
	if($state_id != '' && $state_id != undefined && $state_id != " "){
		$.ajax({
			type : 'POST',
			url: base_url+'ajaxcall',
			data : 'type=city&state_id='+$state_id,
			cache : false,
			success:function(result){
					var obj = $.parseJSON(result);
					var objlength = obj.length;
					var select_option = '';
					for(var i=0;i < objlength;i++){
						if(city_id == obj[i].id){
							select_option +='<option value="'+obj[i].id+'" selected>'+obj[i].city_name+'</option>'; 
						}else{
							select_option +='<option value="'+obj[i].id+'">'+obj[i].city_name+'</option>'; 	
						} 
					}
					$('#city_id').append(select_option);
			}
		});
	}
}



