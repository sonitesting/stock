-- phpMyAdmin SQL Dump
-- version 4.0.10.18
-- https://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Jun 15, 2017 at 10:54 AM
-- Server version: 5.6.35-cll-lve
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `meedzone`
--

-- --------------------------------------------------------

--
-- Table structure for table `access_list`
--

CREATE TABLE IF NOT EXISTS `access_list` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `roles_id` int(10) DEFAULT NULL,
  `controllerlist_id` text,
  `created_by` int(10) NOT NULL,
  `created_date` datetime NOT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `access_list`
--

INSERT INTO `access_list` (`id`, `user_id`, `roles_id`, `controllerlist_id`, `created_by`, `created_date`, `update_date`) VALUES
(1, 1, NULL, '1,7,8,18,19,21,24,25,26,27,28,29,30,31,32,33,34,35', 1, '2016-10-04 00:00:00', '2016-10-04 12:03:22');

-- --------------------------------------------------------

--
-- Table structure for table `action_list`
--

CREATE TABLE IF NOT EXISTS `action_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_name` varchar(20) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `updated_by` int(10) NOT NULL,
  `created_date` datetime NOT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `action_list`
--

INSERT INTO `action_list` (`id`, `action_name`, `status`, `created_by`, `updated_by`, `created_date`, `update_date`) VALUES
(1, 'Edit', '1', 1, 1, '2017-05-09 22:47:51', '2017-05-09 22:47:51'),
(2, 'Delete', '1', 1, 1, '2017-05-09 22:48:07', '2017-05-09 22:48:07'),
(3, 'Add', '1', 1, 1, '2017-05-09 22:48:20', '2017-05-09 22:48:20'),
(4, 'View', '1', 1, 1, '2017-05-09 22:48:39', '2017-05-09 22:48:39'),
(5, 'PDF', '1', 1, 1, '2017-05-09 22:48:51', '2017-05-09 22:48:51'),
(6, 'Excel', '1', 1, 1, '2017-05-09 22:49:48', '2017-05-09 22:49:48'),
(7, 'Download', '1', 1, 1, '2017-05-09 22:50:01', '2017-05-09 22:50:01'),
(8, 'Group Access', '1', 1, 1, '2017-05-19 00:27:47', '2017-05-19 00:27:47');

-- --------------------------------------------------------

--
-- Table structure for table `city`
--

CREATE TABLE IF NOT EXISTS `city` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(50) NOT NULL,
  `state_id` int(10) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `created_by` int(10) NOT NULL,
  `updated_by` int(10) NOT NULL,
  `created_date` datetime NOT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `city`
--

INSERT INTO `city` (`id`, `city_name`, `state_id`, `status`, `created_by`, `updated_by`, `created_date`, `update_date`) VALUES
(3, 'Mumbai', 1, '1', 1, 1, '2017-05-25 13:19:46', '2017-05-25 13:19:46'),
(4, 'Pune', 1, '1', 1, 1, '2017-05-25 13:19:58', '2017-05-25 13:19:58');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(50) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` longtext NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `controllerlist`
--

CREATE TABLE IF NOT EXISTS `controllerlist` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `controllername` varchar(50) DEFAULT NULL,
  `parent` int(10) DEFAULT NULL,
  `menu_name` varchar(100) NOT NULL,
  `menu_type` enum('1','2','3','4') NOT NULL DEFAULT '2',
  `action_id` int(10) NOT NULL,
  `url` varchar(50) NOT NULL,
  `page_active_title` varchar(20) NOT NULL,
  `ctl_menu_icon` varchar(50) NOT NULL,
  `ctl_menu_position` int(10) NOT NULL,
  `menu_category_id` int(10) NOT NULL,
  `dir_path` varchar(50) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=151 ;

--
-- Dumping data for table `controllerlist`
--

INSERT INTO `controllerlist` (`id`, `controllername`, `parent`, `menu_name`, `menu_type`, `action_id`, `url`, `page_active_title`, `ctl_menu_icon`, `ctl_menu_position`, `menu_category_id`, `dir_path`, `status`, `created_date`) VALUES
(1, 'action_list', 0, '', '2', 0, '', '', '', 16, 0, 'admin', '', '2017-05-26 23:05:20'),
(2, 'index', 1, 'Action List', '4', 0, 'action_list', 'Action', '', 98, 2, NULL, '1', '2017-05-29 17:11:07'),
(3, 'edit', 1, 'Edit', '4', 1, '', '', '', 19, 0, NULL, '1', '2017-05-25 14:06:05'),
(4, 'add', 1, 'Add', '4', 3, '', '', '', 13, 0, NULL, '1', '2017-05-25 14:06:05'),
(5, 'view', 1, 'View', '4', 4, '', '', '', 14, 0, NULL, '1', '2017-05-25 14:06:05'),
(6, 'delete', 1, 'Delete', '4', 2, '', '', '', 15, 0, NULL, '1', '2017-05-25 14:06:05'),
(7, 'ajaxcall', 0, '', '2', 0, '', '', '', 36, 0, 'admin', '', '2017-05-26 23:05:20'),
(8, 'index', 7, '', '3', 0, 'ajaxcall/', '', '', 65, 0, NULL, '1', '2017-05-26 00:54:16'),
(9, 'state', 7, '', '3', 0, '', '', '', 72, 0, NULL, '1', '2017-05-25 00:16:24'),
(10, 'city', 7, '', '3', 0, '', '', '', 11, 0, NULL, '1', '2017-05-25 00:16:25'),
(11, 'auth_access', 0, '', '2', 0, '', '', '', 12, 0, 'admin', '0', '2017-05-26 23:05:20'),
(12, 'index', 11, 'Auth Access', '4', 0, 'auth_access/', 'Access', '', 104, 2, NULL, '1', '2017-05-29 17:11:13'),
(13, 'auth_roles', 0, '', '2', 0, '', '', '', 17, 0, 'admin', '', '2017-05-26 23:05:20'),
(14, 'index', 13, 'Roles', '1', 0, 'roles/', 'Roles', '', 5, 1, NULL, '1', '2017-06-03 03:36:27'),
(15, 'edit', 13, 'Edit', '1', 1, '', '', '', 18, 0, NULL, '1', '2017-05-21 03:41:36'),
(16, 'add', 13, 'Add', '1', 3, '', '', '', 20, 0, NULL, '1', '2017-05-21 03:43:56'),
(17, 'view', 13, 'View', '1', 4, '', '', '', 21, 0, NULL, '1', '2017-05-21 03:43:53'),
(18, 'delete', 13, 'Delete', '1', 2, '', '', '', 22, 0, NULL, '1', '2017-05-21 03:43:49'),
(19, 'group_access', 13, 'Group Access', '1', 8, '', '', '', 23, 0, NULL, '1', '2017-05-21 03:43:45'),
(20, 'city', 0, '', '2', 0, '', '', '', 24, 0, 'admin', '', '2017-05-26 23:05:20'),
(21, 'index', 20, 'City', '1', 0, 'city/', 'City', '', 8, 1, NULL, '1', '2017-06-03 03:36:47'),
(22, 'edit', 20, 'Edit', '1', 1, '', '', '', 25, 0, NULL, '1', '2017-05-21 03:43:38'),
(23, 'add', 20, 'Add', '1', 3, '', '', '', 26, 0, NULL, '1', '2017-05-21 03:43:36'),
(24, 'view', 20, 'View', '1', 4, '', '', '', 27, 0, NULL, '1', '2017-05-21 03:43:34'),
(25, 'delete', 20, 'Delete', '1', 2, '', '', '', 28, 0, NULL, '1', '2017-05-21 03:43:31'),
(26, 'country', 0, '', '2', 0, '', '', '', 29, 0, 'admin', '', '2017-05-26 23:05:20'),
(27, 'index', 26, 'Country', '1', 0, 'country/', 'Country', '', 6, 1, NULL, '1', '2017-06-03 03:36:35'),
(28, 'edit', 26, 'Edit', '1', 1, '', '', '', 30, 0, NULL, '1', '2017-05-21 03:43:26'),
(29, 'add', 26, 'Add', '1', 3, '', '', '', 31, 0, NULL, '1', '2017-05-21 03:43:23'),
(30, 'view', 26, 'View', '1', 4, '', '', '', 32, 0, NULL, '1', '2017-05-21 03:43:21'),
(31, 'delete', 26, 'Delete', '1', 2, '', '', '', 33, 0, NULL, '1', '2017-05-21 03:43:18'),
(32, 'dashboard', 0, '', '2', 0, '', '', '', 34, 0, 'admin', '', '2017-05-26 23:05:20'),
(33, 'index', 32, 'Dashboard', '1', 0, 'dashboard/', 'Dashboard', '', 1, 3, NULL, '1', '2017-05-26 02:09:57'),
(34, 'employees', 0, '', '2', 0, '', '', '', 35, 0, 'admin', '', '2017-05-26 23:05:20'),
(35, 'index', 34, 'Employees', '1', 0, 'employees/', 'Employees', 'icon-user', 9, 3, NULL, '1', '2017-06-03 03:36:54'),
(36, 'edit', 34, 'Edit', '1', 1, '', '', '', 37, 0, NULL, '1', '2017-05-21 03:43:08'),
(37, 'alpha_dash_space', 34, '', '2', 0, '', '', '', 38, 0, NULL, '0', '2017-05-21 03:43:04'),
(38, 'check_username', 34, '', '2', 0, '', '', '', 39, 0, NULL, '0', '2017-05-21 03:43:01'),
(39, 'check_email', 34, '', '2', 0, '', '', '', 40, 0, NULL, '0', '2017-05-21 03:42:58'),
(40, 'upload_image', 34, '', '2', 0, '', '', '', 41, 0, NULL, '0', '2017-05-21 03:42:56'),
(41, 'add', 34, 'Add', '1', 3, '', '', '', 42, 0, NULL, '1', '2017-05-21 03:42:54'),
(42, 'view', 34, 'View', '1', 4, '', '', '', 43, 0, NULL, '1', '2017-05-21 03:42:51'),
(43, 'delete', 34, 'Delete', '1', 2, '', '', '', 44, 0, NULL, '1', '2017-05-21 03:42:49'),
(44, 'pdf', 34, 'PDF', '2', 5, '', '', '', 45, 0, NULL, '1', '2017-05-21 03:42:47'),
(45, 'excel', 34, 'Excel', '2', 6, '', '', '', 46, 0, NULL, '1', '2017-05-21 03:42:44'),
(46, 'login', 0, '', '2', 0, '', '', '', 47, 0, 'admin', '', '2017-05-26 23:05:20'),
(47, 'index', 46, '', '2', 0, '', '', '', 48, 0, NULL, '', '2017-05-21 03:42:39'),
(48, 'checkdata', 46, '', '2', 0, '', '', '', 49, 0, NULL, '', '2017-05-21 03:42:36'),
(49, 'check_activation', 46, '', '2', 0, '', '', '', 50, 0, NULL, '', '2017-05-21 03:42:34'),
(50, 'email_verification', 46, '', '2', 0, '', '', '', 51, 0, NULL, '', '2017-05-21 03:42:31'),
(51, 'forgetpassword', 46, '', '2', 0, '', '', '', 52, 0, NULL, '', '2017-05-21 03:42:28'),
(52, 'verify_email', 46, '', '2', 0, '', '', '', 53, 0, NULL, '', '2017-05-21 03:42:26'),
(53, 'resetpassword', 46, '', '2', 0, '', '', '', 54, 0, NULL, '', '2017-05-21 03:42:23'),
(54, 'sendmail', 46, '', '2', 0, '', '', '', 55, 0, NULL, '', '2017-05-21 03:42:21'),
(55, 'logout', 46, '', '2', 0, '', '', '', 56, 0, NULL, '', '2017-05-21 03:42:19'),
(56, 'oops_404', 0, '', '2', 0, '', '', '', 57, 0, '', '', '2017-05-26 23:05:21'),
(57, 'index', 56, '', '3', 0, 'oops_404', '', '', 58, 0, NULL, '', '2017-05-26 00:54:16'),
(58, 'state', 0, '', '2', 0, '', '', '', 59, 0, 'admin', '', '2017-05-26 23:05:21'),
(59, 'index', 58, 'State', '1', 0, 'state/', 'State', '', 7, 1, NULL, '1', '2017-06-03 03:36:41'),
(60, 'edit', 58, 'Edit', '1', 1, '', '', '', 60, 0, NULL, '1', '2017-05-21 21:17:38'),
(61, 'add', 58, 'Add', '1', 3, '', '', '', 61, 0, NULL, '1', '2017-05-21 21:17:38'),
(62, 'view', 58, 'View', '1', 4, '', '', '', 62, 0, NULL, '1', '2017-05-21 21:17:38'),
(63, 'delete', 58, 'Delete', '1', 2, '', '', '', 63, 0, NULL, '1', '2017-05-21 21:17:38'),
(64, 'menu_category', 0, '', '2', 0, '', '', '', 64, 0, 'admin', '', '2017-05-26 23:05:20'),
(65, 'index', 64, 'Menu Category', '4', 0, 'menu_category', 'Menu_category', '', 10, 2, NULL, '1', '2017-05-29 17:11:19'),
(66, 'edit', 64, 'Edit', '4', 1, '', '', '', 66, 0, NULL, '1', '2017-05-25 14:06:05'),
(67, 'add', 64, 'Add', '4', 3, '', '', '', 67, 0, NULL, '1', '2017-05-25 14:06:05'),
(68, 'view', 64, 'View', '4', 4, '', '', '', 68, 0, NULL, '1', '2017-05-25 14:06:05'),
(69, 'delete', 64, 'Delete', '4', 2, '', '', '', 69, 0, NULL, '1', '2017-05-25 14:06:05'),
(85, 'menu_position', 0, '', '2', 0, '', '', '', 70, 0, 'admin', '0', '2017-05-26 23:05:21'),
(86, 'position_level', 85, 'Set Position', '4', 0, '', '', '', 71, 0, NULL, '1', '2017-05-25 14:06:05'),
(87, 'index', 85, 'Menu Position', '4', 0, 'menu_position/', 'menu_position', '', 116, 2, NULL, '1', '2017-06-03 03:36:54'),
(88, 'partners', 0, '', '2', 0, '', '', '', 73, 0, 'admin', '0', '2017-05-26 23:05:21'),
(89, 'index', 88, 'Partners', '2', 0, 'partners', 'Partners', '', 74, 3, NULL, '0', '2017-05-29 14:31:09'),
(90, 'edit', 88, 'Edit', '2', 1, '', '', '', 75, 0, NULL, '0', '2017-05-29 14:31:09'),
(91, 'alpha_dash_space', 88, '', '2', 0, '', '', '', 76, 0, NULL, '0', '2017-05-25 16:35:56'),
(92, 'check_username', 88, '', '2', 0, '', '', '', 77, 0, NULL, '0', '2017-05-25 16:35:56'),
(93, 'check_email', 88, '', '2', 0, '', '', '', 78, 0, NULL, '0', '2017-05-25 16:35:56'),
(94, 'upload_image', 88, '', '2', 0, '', '', '', 79, 0, NULL, '0', '2017-05-25 16:35:56'),
(95, 'upload_doc', 88, '', '2', 0, '', '', '', 80, 0, NULL, '0', '2017-05-25 16:35:56'),
(96, 'add', 88, 'Add', '2', 3, '', '', '', 81, 0, NULL, '0', '2017-05-29 14:31:09'),
(97, 'view', 88, 'View', '2', 4, '', '', '', 82, 0, NULL, '0', '2017-05-29 14:31:09'),
(98, 'delete', 88, 'Delete', '2', 2, '', '', '', 83, 0, NULL, '0', '2017-05-29 14:31:09'),
(99, 'pdf', 88, 'Pdf', '2', 5, '', '', '', 84, 0, NULL, '0', '2017-05-29 14:31:09'),
(119, 'developers', 0, '', '2', 0, '', '', '', 85, 0, 'admin', '0', '2017-05-28 00:43:17'),
(120, 'index', 119, 'Developers', '4', 0, 'developers/', 'Developers', '', 86, 2, NULL, '1', '2017-05-28 00:54:37'),
(121, 'edit', 119, 'Edit', '4', 1, '', '', '', 87, 0, NULL, '1', '2017-05-28 00:47:18'),
(122, 'alpha_dash_space', 119, '', '2', 0, '', '', '', 88, 0, NULL, '0', '2017-05-28 00:43:17'),
(123, 'check_username', 119, '', '2', 0, '', '', '', 89, 0, NULL, '0', '2017-05-28 00:43:17'),
(124, 'check_email', 119, '', '2', 0, '', '', '', 90, 0, NULL, '0', '2017-05-28 00:43:17'),
(125, 'upload_image', 119, '', '2', 0, '', '', '', 91, 0, NULL, '0', '2017-05-28 00:43:17'),
(126, 'add', 119, 'Add', '4', 3, '', '', '', 92, 0, NULL, '1', '2017-05-28 00:47:18'),
(127, 'view', 119, 'View', '4', 4, '', '', '', 93, 0, NULL, '1', '2017-05-28 00:47:18'),
(128, 'delete', 119, 'Delete', '4', 2, '', '', '', 94, 0, NULL, '1', '2017-05-28 00:47:18'),
(129, 'pdf', 119, 'Pdf', '4', 5, '', '', '', 95, 0, NULL, '1', '2017-05-28 00:47:18'),
(130, 'excel', 119, 'Excel', '4', 6, '', '', '', 96, 0, NULL, '1', '2017-05-28 00:47:18'),
(131, 'product_category', 0, '', '2', 0, '', '', '', 97, 0, 'admin', '0', '2017-05-28 18:19:57'),
(132, 'index', 131, 'Category', '1', 0, 'category/', 'Category', 'fa fa-tags', 2, 3, NULL, '1', '2017-05-29 17:17:47'),
(133, 'edit', 131, 'Edit', '1', 1, '', '', '', 99, 0, NULL, '1', '2017-05-28 18:22:15'),
(134, 'add', 131, 'Add', '1', 3, '', '', '', 100, 0, NULL, '1', '2017-05-28 18:22:15'),
(135, 'view', 131, 'View', '1', 4, '', '', '', 101, 0, NULL, '1', '2017-05-28 18:22:15'),
(136, 'delete', 131, 'Delete', '1', 2, '', '', '', 102, 0, NULL, '1', '2017-05-28 18:22:16'),
(137, 'customer_service', 0, '', '2', 0, '', '', '', 103, 0, 'admin', '0', '2017-05-29 17:02:52'),
(138, 'index', 137, 'Customer Service', '1', 0, 'customer_service', 'Customer Service', 'fa fa-comments-o', 3, 3, NULL, '1', '2017-05-29 17:19:34'),
(139, 'edit', 137, 'Edit', '1', 1, '', '', '', 105, 0, NULL, '1', '2017-05-29 17:08:26'),
(140, 'alpha_dash_space', 137, '', '2', 0, '', '', '', 106, 0, NULL, '0', '2017-05-29 17:09:41'),
(141, 'add', 137, 'Add', '1', 3, '', '', '', 107, 0, NULL, '1', '2017-05-29 17:08:26'),
(142, 'view', 137, 'View', '1', 4, '', '', '', 108, 0, NULL, '1', '2017-05-29 17:08:26'),
(143, 'delete', 137, 'Delete', '1', 2, '', '', '', 109, 0, NULL, '1', '2017-05-29 17:08:26'),
(144, 'customer_query', 0, '', '2', 0, '', '', '', 110, 0, 'admin', '0', '2017-05-31 00:39:55'),
(145, 'index', 144, 'Customer Query', '1', 0, 'customer_query', 'Customer Query', 'fa fa-comments-o', 111, 3, NULL, '1', '2017-05-31 00:41:29'),
(146, 'edit', 144, 'Edit', '1', 1, '', '', '', 112, 0, NULL, '1', '2017-05-31 00:41:29'),
(147, 'alpha_dash_space', 144, '', '2', 0, '', '', '', 113, 0, NULL, '0', '2017-05-31 00:39:56'),
(148, 'view', 144, 'View', '1', 4, '', '', '', 114, 0, NULL, '1', '2017-05-31 00:41:29'),
(149, 'stock', 0, '', '2', 0, '', '', '', 115, 0, 'admin', '0', '2017-06-03 03:35:07'),
(150, 'index', 149, 'Stock', '1', 0, 'stock/', 'Stock', 'fa fa-cubes', 4, 3, NULL, '1', '2017-06-03 03:36:20');

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(50) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `updated_by` int(10) NOT NULL,
  `created_date` datetime NOT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`id`, `country_name`, `status`, `created_by`, `updated_by`, `created_date`, `update_date`) VALUES
(1, 'India', '1', 1, 1, '2017-05-01 13:57:53', '2017-05-01 13:57:53'),
(2, 'USA', '1', 1, 1, '2017-05-01 13:58:02', '2017-05-01 13:58:02');

-- --------------------------------------------------------

--
-- Table structure for table `customer_service`
--

CREATE TABLE IF NOT EXISTS `customer_service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `mobile` bigint(11) NOT NULL,
  `gender` enum('Male','Female','Other') DEFAULT 'Male',
  `dob` date NOT NULL,
  `address` varchar(200) NOT NULL,
  `city_id` int(10) NOT NULL,
  `state_id` int(10) NOT NULL,
  `postcode` int(10) NOT NULL,
  `country_id` int(10) NOT NULL,
  `service_center_id` int(10) DEFAULT NULL,
  `status` enum('0','1','2','3','4') NOT NULL DEFAULT '1',
  `product_cat_id` int(10) DEFAULT NULL,
  `complain_msg` tinytext,
  `created_by` int(11) NOT NULL,
  `updated_by` int(10) NOT NULL,
  `created_date` datetime NOT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id` (`id`),
  KEY `id_2` (`id`),
  KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `customer_service`
--

INSERT INTO `customer_service` (`id`, `email`, `first_name`, `last_name`, `mobile`, `gender`, `dob`, `address`, `city_id`, `state_id`, `postcode`, `country_id`, `service_center_id`, `status`, `product_cat_id`, `complain_msg`, `created_by`, `updated_by`, `created_date`, `update_date`) VALUES
(1, 'testing@gmail.com', 'Testing', 'Testing', 9876543212, 'Male', '0000-00-00', 'testing testing', 3, 1, 400012, 1, 7, '1', 4, 'Not working', 1, 1, '2017-05-29 18:01:24', '2017-05-31 00:24:51'),
(2, 'Testing_data@gmail.com', 'Testing data', 'Testing data', 7876777723, 'Female', '0000-00-00', 'Testing data Testing data Testing data', 3, 1, 400011, 1, 6, '0', 5, 'Testing Testing testing', 1, 5, '2017-05-29 18:08:37', '2017-06-02 02:11:20'),
(3, 'bharat.keshwani@outlook.com', 'Bharat', 'Keshwani', 9830253737, 'Male', '0000-00-00', '28/7 new alipore', 3, 1, 700053, 1, 6, '0', 4, 'smps not working,  smps replaced.', 5, 6, '2017-06-02 15:32:08', '2017-06-02 03:25:55'),
(4, 'hiresh@inalsa.co.in', 'Hiresh', 'sharma', 9830253737, 'Male', '0000-00-00', '287 new alipore', 3, 1, 700053, 1, 6, '0', 6, 'smsps not working\n\nSmsp fixed, issue is resolved now.', 5, 6, '2017-06-05 11:32:19', '2017-06-04 23:15:31');

-- --------------------------------------------------------

--
-- Table structure for table `excel_master`
--

CREATE TABLE IF NOT EXISTS `excel_master` (
  `master_id` int(10) NOT NULL AUTO_INCREMENT,
  `added_date` datetime NOT NULL,
  `update_date` datetime NOT NULL,
  `id` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`master_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `group_access`
--

CREATE TABLE IF NOT EXISTS `group_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roles_id` int(10) NOT NULL,
  `menu_id` text NOT NULL,
  `access_id` text NOT NULL,
  `action_list_id` text NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `created_by` int(11) NOT NULL,
  `updated_by` int(10) NOT NULL,
  `created_date` datetime NOT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `group_access`
--

INSERT INTO `group_access` (`id`, `roles_id`, `menu_id`, `access_id`, `action_list_id`, `status`, `created_by`, `updated_by`, `created_date`, `update_date`) VALUES
(1, 5, '', '', '3,7,1,5,4', '1', 1, 1, '2017-05-10 23:19:25', '2017-05-11 00:42:36'),
(2, 1, '33,132,138,150,14,27,59,21,35', '133,134,135,136,139,141,142,143,15,16,17,18,19,28,29,30,31,60,61,62,63,22,23,24,25,36,41,42,43', '131_1,131_3,131_4,131_2,137_1,137_3,137_4,137_2,13_1,13_3,13_4,13_2,13_8,26_1,26_3,26_4,26_2,58_1,58_3,58_4,58_2,20_1,20_3,20_4,20_2,34_1,34_3,34_4,34_2', '1', 1, 1, '0000-00-00 00:00:00', '2017-06-03 03:37:15'),
(3, 2, '33,14', '17', '13_4', '1', 1, 4, '0000-00-00 00:00:00', '2017-05-24 00:23:19'),
(4, 3, '', '', '', '1', 1, 1, '0000-00-00 00:00:00', '2017-05-19 00:24:37'),
(5, 4, '', '', '', '1', 1, 1, '0000-00-00 00:00:00', '2017-05-19 00:24:39'),
(6, 6, '14,21', '15,16,17,18,19,23', '1,3,4,2,0,3', '1', 1, 1, '2017-05-19 00:24:05', '2017-05-19 00:25:14'),
(7, 7, '33,145', '146,148', '144_1,144_4', '1', 1, 1, '2017-05-30 23:53:22', '2017-05-31 00:42:07');

-- --------------------------------------------------------

--
-- Table structure for table `menu_category`
--

CREATE TABLE IF NOT EXISTS `menu_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_cat_name` varchar(50) NOT NULL,
  `menu_icon` varchar(50) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `updated_by` int(10) NOT NULL,
  `created_date` datetime NOT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `menu_category`
--

INSERT INTO `menu_category` (`id`, `menu_cat_name`, `menu_icon`, `status`, `created_by`, `updated_by`, `created_date`, `update_date`) VALUES
(1, 'Master', 'icon-social-dribbble', '1', 1, 1, '2017-05-17 23:19:57', '2017-05-20 03:38:59'),
(2, 'Setting', 'icon-settings', '1', 1, 1, '2017-05-17 23:21:14', '2017-05-20 03:38:34'),
(3, 'Root Menu', 'icon-home', '1', 1, 1, '2017-05-20 01:22:52', '2017-05-20 01:22:52');

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE IF NOT EXISTS `product_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) NOT NULL,
  `parent_id` int(10) DEFAULT NULL,
  `level_depth` int(10) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `updated_by` int(10) NOT NULL,
  `created_date` datetime NOT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`id`, `category_name`, `parent_id`, `level_depth`, `status`, `created_by`, `updated_by`, `created_date`, `update_date`) VALUES
(5, 'TV', NULL, NULL, '1', 5, 5, '2017-05-29 14:19:06', '2017-05-29 14:19:06'),
(6, 'Computer', NULL, NULL, '1', 5, 5, '2017-06-04 08:55:08', '2017-06-03 20:25:08');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roles_name` varchar(20) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `created_by` int(10) NOT NULL,
  `updated_by` int(10) NOT NULL,
  `created_date` datetime NOT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `roles_name`, `status`, `created_by`, `updated_by`, `created_date`, `update_date`) VALUES
(1, 'Super Admin', '1', 1, 1, '2017-05-01 14:25:47', '2017-05-01 14:25:47'),
(2, 'Admin', '1', 1, 1, '2017-05-01 14:26:01', '2017-05-01 14:26:01'),
(3, 'Partner', '1', 1, 1, '2017-05-01 14:26:34', '2017-05-01 14:26:34'),
(4, 'Sponsor', '1', 1, 1, '2017-05-01 14:27:08', '2017-05-26 23:36:45'),
(5, 'Staff', '1', 1, 1, '2017-05-10 23:19:25', '2017-05-10 23:19:25'),
(6, 'Employee', '1', 1, 1, '2017-05-19 00:24:05', '2017-05-19 00:24:05'),
(7, 'Service Center', '1', 1, 1, '2017-05-30 23:53:21', '2017-05-30 23:57:50');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE IF NOT EXISTS `state` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `state_name` varchar(50) NOT NULL,
  `country_id` int(10) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `created_by` int(10) NOT NULL,
  `updated_by` int(10) NOT NULL,
  `created_date` datetime NOT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `state_name`, `country_id`, `status`, `created_by`, `updated_by`, `created_date`, `update_date`) VALUES
(1, 'Maharashtra', 1, '1', 1, 1, '2017-05-01 14:03:00', '2017-05-01 14:03:00'),
(2, 'GOA', 1, '1', 1, 1, '2017-05-10 00:22:22', '2017-05-10 00:22:22');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE IF NOT EXISTS `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(10) NOT NULL,
  `stock_in` int(10) DEFAULT NULL,
  `stock_out` int(10) DEFAULT NULL,
  `service_center_id` int(10) NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `updated_by` int(10) NOT NULL,
  `created_date` datetime NOT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `product_id`, `stock_in`, `stock_out`, `service_center_id`, `status`, `created_by`, `updated_by`, `created_date`, `update_date`) VALUES
(1, 6, 1000, 100, 6, '1', 5, 5, '2017-06-03 00:00:00', '2017-06-04 05:22:22'),
(2, 5, 100, 10, 7, '1', 5, 5, '2017-06-03 00:00:00', '2017-06-04 05:20:28');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `mobile` bigint(11) NOT NULL,
  `gender` enum('Male','Female','Other') DEFAULT 'Male',
  `profile_pic` varchar(100) DEFAULT NULL,
  `roles_id` int(10) NOT NULL,
  `dob` date NOT NULL,
  `address` varchar(200) NOT NULL,
  `city_id` int(10) NOT NULL,
  `state_id` int(10) NOT NULL,
  `postcode` int(10) NOT NULL,
  `country_id` int(10) NOT NULL,
  `email_token` varchar(100) DEFAULT NULL,
  `password_token` varchar(100) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '0',
  `email_token_date` datetime DEFAULT NULL,
  `last_password_change_date` datetime DEFAULT NULL,
  `user_type` enum('1','2','3','') NOT NULL COMMENT '1: Employees,2:Developer,3:Partner',
  `created_by` int(11) NOT NULL,
  `updated_by` int(10) NOT NULL,
  `created_date` datetime NOT NULL,
  `update_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email_token` (`email_token`),
  KEY `id` (`id`),
  KEY `id_2` (`id`),
  KEY `email` (`email`),
  KEY `username` (`username`),
  KEY `roles` (`roles_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `first_name`, `last_name`, `mobile`, `gender`, `profile_pic`, `roles_id`, `dob`, `address`, `city_id`, `state_id`, `postcode`, `country_id`, `email_token`, `password_token`, `status`, `email_token_date`, `last_password_change_date`, `user_type`, `created_by`, `updated_by`, `created_date`, `update_date`) VALUES
(1, 'admin@123', '25f9e794323b453885f5181f1b624d0b', 'sumeet2088@gmail.com', 'Sumeet', 'Singh', 9876543210, 'Male', 'upload/profile_pic/avatar1.jpg', 1, '0000-00-00', '', 0, 0, 0, 0, NULL, NULL, '1', '2016-08-26 14:41:20', NULL, '2', 0, 0, '2016-06-15 00:00:00', '2017-05-25 13:14:03'),
(4, 'admin@444', '25f9e794323b453885f5181f1b624d0b', 'sumeet20883@gmail.com', 'testt', 'testt', 9876543212, 'Male', 'upload/profile_pic/23352.jpg', 2, '2017-05-20', 'testing testingtesting testing   test', 3, 1, 400080, 1, NULL, NULL, '1', NULL, NULL, '1', 1, 1, '2017-05-07 23:25:46', '2017-05-25 13:20:27'),
(5, 'admin@test', 'f4a7eccf2d88332ddcf65cf1555f40c6', 'admin@gmail.com', 'Super', 'Admin Test', 9876543219, 'Male', 'upload/profile_pic/29711.jpg', 1, '0000-00-00', 'Super Admin', 3, 1, 421306, 1, NULL, NULL, '1', NULL, NULL, '1', 1, 1, '2017-05-26 00:30:26', '2017-05-29 11:05:10'),
(6, 'mumbai@center', '2f14c1dc39b508620861f84318304be5', 'mumbaicenter@gmail.com', 'Mumbai', 'Center', 9876543219, 'Male', NULL, 7, '0000-00-00', 'testing testing testing testing testing', 3, 1, 400001, 1, NULL, NULL, '1', NULL, NULL, '1', 1, 1, '2017-05-31 00:05:27', '2017-05-31 00:06:35'),
(7, 'kolkata@center', '7dae4c504540e888007b57af6d17d442', 'kolkatacenter@gmail.com', 'Kolkata', 'Center', 9876543219, 'Male', NULL, 7, '0000-00-00', 'testing testing testing testing', 3, 1, 400001, 1, NULL, NULL, '1', NULL, NULL, '1', 1, 1, '2017-05-31 00:24:40', '2017-05-31 00:24:40');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
