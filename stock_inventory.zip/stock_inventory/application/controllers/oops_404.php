<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Oops_404 extends CI_Controller{
	function __Construct(){
		parent::__construct();
		date_default_timezone_set('asia/kolkata');
	}

	function index(){
		$this->load->view('errors/error_404');
	}
}