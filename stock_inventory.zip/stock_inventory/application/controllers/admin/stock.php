<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Stock extends CI_Controller{

	function __Construct(){
		parent::__construct();

		$this->load->library('auth');
		if(!$this->auth->is_logged_in()){
			redirect('login','refresh');
		}
	}

	function _remap($method, $params=array())
    {	
        $methodToCall = method_exists($this, $method) ? $method : 'index';
        return call_user_func_array(array($this, $methodToCall), $params);
    }

	function index(){
		
		$created_by = $this->auth->get_data('user','id,first_name,last_name','user_type="1"','','order by first_name asc');
		$created_by_option =array();
		if(!empty($created_by)){
			foreach($created_by as $row){
				$created_by_option[$row['id']] = $row['first_name'].' '.$row['last_name']; 
			}	
		}


		$prd_category = $this->auth->get_data('product_category','id,category_name','','','order by category_name asc');
		$product_option =array();
		if(!empty($prd_category)){
			foreach($prd_category as $row){
				$product_option[$row['id']] = $row['category_name']; 
			}	
		}

		$service_center = $this->auth->get_data('user','id,first_name,last_name','roles_id=7','','order by first_name asc');
		$service_center_option =array();
		if(!empty($service_center)){
			foreach($service_center as $row){
				$service_center_option[$row['id']] = $row['first_name'].' '.$row['last_name']; 
			}	
		}

		$base_url = base_url().'stock';
		$segment = 2;
		$per_page = 10;

		/*$this->load->library('generate_table');
		$this->generate_table->set_table_name('stock');
		$this->generate_table->set_order_by('id:asc');
		$this->generate_table->set_pagination_url($base_url);
		$this->generate_table->set_per_page($per_page);
		$this->generate_table->set_uri_segment($segment);
		$this->generate_table->set_table_caption('stock');*/


		$this->load->library('generate_table');
    	$this->generate_table->set_table_name('stock');
		$this->generate_table->set_table_join('left Join product_category on product_category.id=stock.product_id');
		$this->generate_table->set_where('product_category.status="1"');
		$this->generate_table->set_group_by('stock.product_id');
		$this->generate_table->set_order_by('stock.product_id:desc');
		$this->generate_table->set_pagination_url($base_url);
		$this->generate_table->set_per_page($per_page);
		$this->generate_table->set_uri_segment($segment);
		$this->generate_table->set_table_caption('stock');
		$field_list = array(
				'id' =>array(
					'type'=>'number',
					'table_heading' =>'ID',
					'search_field' => false,
					'display_field' =>true,
				),
				'product_id' =>array(
					'type'=>'select',
					'table_heading' =>'Product',
					'search_field' => true,
					'display_field' =>true,
					'option' => $product_option
				),
				'stock_in' =>array(
					'type'=>'number',
					'table_heading' =>'Stock In',
					'search_field' => false,
					'display_field' =>true,
				),
				'cost_per_quantity' =>array(
					'type'=>'number',
					'table_heading' =>'Cost per qunatity',
					'search_field' => true,
					'display_field' =>true,
				),
				'service_center_id' =>array(
					'type'=>'select',
					'table_heading' =>'Stock Assign To',
					'search_field' => true,
					'display_field' =>true,
					'option'=> $service_center_option
				),
				'created_by' =>array(
					'type'=>'select',
					'table_heading' =>'Created By',
					'search_field' => true,
					'display_field' =>true,
					'option'=>$created_by_option
				),
				'Updated_by' =>array(
					'type'=>'select',
					'table_heading' =>'Updated By',
					'search_field' => true,
					'display_field' =>true,
					'option'=>$created_by_option
				),
				'created_date'=>array(
					'type'=>'date',
					'table_heading' =>'Created Date',
					'search_field' => true,
					'display_field' =>true,
					'format'=>"date('m/d/Y',strtotime('~created_date~'))"
				),
				'update_date'=>array(
					'type'=>'date',
					'table_heading' =>'Updated Date',
					'search_field' => true,
					'display_field' =>true,
					'format'=>"date('m/d/Y',strtotime('~update_date~'))"
				),
				'status' => array(
					'type' => 'select',
					'table_heading' => 'Status',
					'search_field' => true,
					'display_field' =>true,
					'option' =>array('0'=>'In-Active','1'=>'Active')
				),
		);

		$ab=$this->generate_table->set_field_list($field_list);
		$field_action = array('view','edit','delete','add');
		
		$this->generate_table->set_field_action($field_action);

		$data = $this->generate_table->get_table();
		$data['title']='Stock';
		$data['page']='Stock';
		if($this->input->post()){
			echo json_encode($data);
			exit;
		}else{
			$data['base_url']=$base_url;
			$data['per_page']=$per_page;
			
			$this->load->view('admin/header',$data);
			$this->load->view('admin/side_menu');
			$this->load->view('admin/table_view');
			$this->load->view('admin/footer');
		}
	}

	function edit($type = null){
		$this->load->library('form_validation');

		$primary_id = $this->uri->segment(3);
		$data['get_data'] = array();
		$data['errors'] = '';

		$data['spare'] = $this->auth->get_data('spare_part','id,part_name','status="1"','','order by part_name asc');

		$data['product'] = $this->auth->get_data('product_category','id,category_name','status="1"','','order by category_name asc');


		if($this->input->post()){
			$this->form_validation->set_rules('id','ID','trim|xss_clean');
			$this->form_validation->set_rules('product_id','Product','trim|xss_clean|required');
			$this->form_validation->set_rules('stock_in','Stock In','trim|xss_clean|required|alpha_numeric_spaces|min_length[2]|max_length[20]');
			$this->form_validation->set_rules('cost_per_quantity','Cost Per Stock Out','trim|xss_clean');
			$this->form_validation->set_rules('spare_part_id','Spare Part','trim|xss_clean|required');
			$this->form_validation->set_rules('status','Status','trim|xss_clean|required');

			if($this->form_validation->run() == false){
				$data['errors'] = $this->form_validation->geterror_array();
				$this->form_validation->unseterror_array();
			}else{
				$data_arr = array(
					'id' => $this->form_validation->set_value('id'),
					'product_id'=> $this->form_validation->set_value('product_id'),
					'stock_in'=> $this->form_validation->set_value('stock_in'),
					'cost_per_quantity'=> $this->form_validation->set_value('cost_per_quantity'),
					'spare_part_id'=> $this->form_validation->set_value('spare_part_id'),
					'status'=> $this->form_validation->set_value('status')
				);

				//print_r($data_arr);exit;
				$result = $this->auth->save_data('stock',$data_arr);
				if($result == 'update_data'){
					$this->session->set_userdata('status_msg', 'update_success');	
					redirect('stock','refresh');
				}else if($result == 'already_update_data'){
					$this->session->set_userdata('status_msg', 'already_update_success');	
					redirect('stock','refresh');
				}else if($result > 0){
					$this->session->set_userdata('status_msg', 'insert_success');	
					redirect('stock','refresh');
				}else{
					$this->session->set_userdata('status_msg', 'error');
					redirect('stock','refresh');	
				}
			}
		}else{
			$data['get_data'] = $this->auth->get_data_by_id($primary_id,'stock','id,product_id,spare_part_id,stock_in,cost_per_quantity,status');
		}
		$data['type'] = $type;
		$data['title'] = 'Stock Detail';
		$data['page']='Stock';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/side_menu');
		$this->load->view('admin/stock_form_view');
		$this->load->view('admin/footer');

	}

	function add(){
		$this->edit('add');	
	}

	function view(){
		$this->edit('view');	
	}

	function getsparepart(){
		$product_id = $_REQUEST['selectedCountry'];//trim($this->input->post('product_id'));
		if(!empty($product_id)){
		$spare_value=$this->auth->get_spare_data($product_id);
		echo json_encode($spare_value);exit;
	}
	   echo false;
			
	}

	function delete(){
		if(isset($_POST) && count($_POST)>0){
			$id = $_POST['id'];
			$where = 'id='.$id;
			$data = $this->auth->delete_data('stock',$where);
			echo $data;
		}
	}

	
}