<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller{
	
	function __Construct(){
		parent::__Construct();
		//$this->load->model('backend/dashboard_model');
		$this->load->library('auth');
		if(!$this->auth->is_logged_in()){
			redirect('login','refresh');
		}
	}

	function index()
    {	
    	$data['title']='Dashboard';
    	$data['page']='Dashboard';
    	$this->load->view('admin/header',$data);
    	$this->load->view('admin/side_menu');
    	$this->load->view('admin/dashboard');
    	$this->load->view('admin/footer');
    }

   // function test()
   // {	
    	//echo 'You are now dashboard <a href="'.base_url().'logout">logout</a>';

  //   	$data = array();
  //   	if(count($this->input->post())>0){
	 //    	if(!empty($_FILES['excel_file']['name']))
	 //    	{	
		// 		$arr=$_FILES['excel_file']['name'];
		// 		$path_parts = pathinfo($arr);
		// 		$ext=$path_parts['extension'];
		// 		$folder = 'upload/excel_data';

		// 		$_FILES['excel_file']['name']=rand().'.'.$ext;
		// 		$config['upload_path'] = $folder;
		// 		$config['allowed_types'] = '*';
		// 		$config['max_size'] = '0';
		// 		$config['max_width'] = '0';
		// 		$config['max_height'] = '0';

		// 		$this->load->library('upload', $config);

		// 		if ( ! $this->upload->do_upload("excel_file")){

		// 			$data['errors'] =  $this->upload->display_errors();
		// 		}
		// 		else
		// 		{
		// 			$data['file_data'] = $this->upload->data();

		// 			$this->load->library('csvimport');
		// 			$this->load->library("PHPExcel");
		// 			$file_path = $folder.'/'.$_FILES['excel_file']['name'];
		// 			if($ext=='csv'){
		// 				$objReader = PHPExcel_IOFactory::createReader('CSV');
		// 			}else{
		// 				$objReader = PHPExcel_IOFactory::createReader('Excel2007');
		// 			}

		// 			$objReader->setReadDataOnly(true);

		// 			$objPHPExcel = $objReader->load($file_path);
		// 			$objWorksheet = $objPHPExcel->setActiveSheetIndex(0);
		// 			$highestRow = $objWorksheet->getHighestRow(); // e.g. 10

		// 			$highestColumn = $objWorksheet->getHighestColumn(); // e.g 'F'

		// 			$highestColumnIndex = PHPExcel_Cell::columnIndexFromString($highestColumn); // e.g. 5
			
		// 			for($i=0; $i<$highestColumnIndex; $i++)
		// 			{
		// 				$excel_column_name[] = $objWorksheet->getCellByColumnAndRow($i,1)->getValue();
		// 			}
		// 			$response = array();
		// 			$arr =array();
		// 			for($i=2; $i<$highestRow; $i++)
		// 			{	
		// 				foreach($excel_column_name as $key=>$value){
		// 					$arr[$value] = $objWorksheet->getCellByColumnAndRow($key,$i)->getValue();
		// 				}

		// 				array_push($response,$arr);
		// 				unset($arr);
		// 			}

		// 			unlink($file_path);
		// 			$data['excel_heading'] = $excel_column_name;
		// 			$data['excel_data'] = $response;
		// 		}
		// 	}
		// 	else if($this->input->post('submit_excel'))
		// 	{
		// 			$column_name = $this->input->post('column_name');
		// 			$excel_sr_no = $this->input->post('excel_sr_no');
		// 			$table_name = 'excel_master';
		// 			$status = $this->dashboard_model->checktable_present($table_name);
		// 			if($status){
		// 				foreach ($column_name as $key => $value){
		// 					$this->dashboard_model->sethybridtable_list($value,$table_name);
		// 					$value = str_replace(' ','_',trim(strtolower($value)));
		// 					$arr[$value] = $this->input->post($value);
		// 				}

		// 				$count = count($column_name);
		// 				for($i=0;$i<$excel_sr_no;$i++){
		// 					for($j=0;$j<$count;$j++){
		// 						$arr_data[$column_name[$j]] = (isset($arr[$column_name[$j]][$i]) &&  $arr[$column_name[$j]][$i] != '' ? $arr[$column_name[$j]][$i] : Null);
		// 					}	
		// 					$this->dashboard_model->save_excel_data($table_name,$arr_data);
		// 				}
		// 				$msg='Success';
		// 			}else{
		// 				$msg = 'Error generated';
		// 			}

		// 			$data['msg'] = $msg;
		// 	}

		// }
  //   	$this->load->view('admin/dashboard',$data);
  //  }
}
