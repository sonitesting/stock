<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class login extends CI_Controller{

	private $errors = '';
	private $steps = '';
	private $msg = '';
	private $title = 'Login';

	function __Construct(){
		parent::__construct();
		$this->load->library('auth');
		$this->load->library('form_validation');
		date_default_timezone_set('asia/kolkata');
	}

	function _remap($method, $params=array())
    {
        $methodToCall = method_exists($this, $method) ? $method : 'index';
        return call_user_func_array(array($this, $methodToCall), $params);
    }

	function index(){
		$data='';
		$data['errors'] ='';
		$username = $this->session->userdata('username');
		if(isset($_POST) && count($_POST)>0){
			if(isset($_POST['username']) && isset($_POST['password'])){
				$this->form_validation->set_rules('username','Username','trim|xss_clean|required|alphanumeric|min_length[6]|max_length[20]|callback_checkdata[username]');
				$where = ' username="'.$this->input->post('username').'"';
		    	$this->form_validation->set_rules('password','Password','trim|xss_clean|required|min_length[8]|max_length[16]|callback_checkdata[password,'.$where.']');

		    	if ($this->form_validation->run() == FALSE){
		    		$errors = $this->form_validation->geterror_array();
		    		$error = 'Enter a valid ';
	                    $flag=0;
	                    foreach($errors as $key => $value){
	                        if($flag == 1){
	                            $error .= ' or ';
	                        }
	                        $error .= ucfirst($key);
	                        $flag++;
	                    }
	                    unset($flag);
	                    $error .= '!';
	                $this->errors = $error;    
					$this->form_validation->unseterror_array();
		    		if(!array_key_exists('username',$errors)){
		    			$data['username'] = $this->form_validation->set_value('username');
						$data['username'] = preg_replace('/\s+/', '', $data['username']);
					}
			    }else{
			    	$username = $this->input->post('username');
			    }
			}else if(isset($_POST['email'])){
				$this->email_verification();
			}
		}
		$check_activation = $this->check_activation($username);
		if($check_activation){
			redirect('dashboard');
		}

		if($this->uri->segment(1) == 'verify-email'){
			$verify = $this->uri->segment(2);
			$this->verify_email($verify);
		}

		if($this->uri->segment(1) == 'forgetpassword'){
			$this->forgetpassword();
		}

		if($this->uri->segment(1) == 'reset-password'){
			$verify = $this->uri->segment(2);
			$this->resetpassword($verify);
		}
		
		$data['errors'] = $this->errors;
		$data['steps'] = $this->steps;
		$data['title'] = $this->title;
		$data['msg'] = $this->msg;
		$this->load->view('admin/login',$data);
	}

	function checkdata($value,$column_name){
		$column_name = explode(',',$column_name);
		if($column_name[0] == 'password'){
			$values = md5(trim($value));
			$where = $column_name[0].' = "'.$values.'"';
		}else{
			$where = $column_name[0].' = "'.$value.'"';	
		}
		if(isset($column_name[1]) && !empty($column_name[1])){
			$where .= ' AND '.$column_name[1];
		}
		
		$data = $this->auth->get_total_count('user',$where);
		if(!$data){
			$this->form_validation->set_message('checkdata', 'Invalid');
            return false;
		}
		return true;
	}

	function check_activation($username = null){
		if(!empty($username)){
			$where = 'username ="'.$username.'"';
			$data = $this->auth->get_data('user','id,username,profile_pic,status,roles_id,email_token,email_token_date,password_token,user_type',$where);
			//print'<pre>';print_r($data);
			if(!empty($data) && $data[0]['status'] == '0'){
				$this->errors = 'Your account is not activated!';
				return false;
			}else if(!empty($data) && $data[0]['status'] == '1'){
				$roles_data = $this->auth->get_total_count('group_access','group_access.roles_id='.$data[0]['roles_id'].' AND roles.status="1"','join roles on roles.id=group_access.roles_id');
				if(empty($roles_data)){
					$this->errors = 'Your account roles access is not valid!';
					return false;
				}
				$this->session->set_userdata(array(
									'user_id'	=> $data[0]['id'],
									'username'	=> $data[0]['username'],
									'roles_id' => $data[0]['roles_id'],
									'user_type' => $data[0]['user_type'],
									'profile_pic'	=> $data[0]['profile_pic'],
									'user_status'	=> ($data[0]['status'] == 1) ? 1 : 0
				));
				if(!empty($data[0]['password_token']) && $this->session->userdata('user_status') == 1){
					$this->auth->update_data('user','password_token = null',$where);
				}			

				$curr_date = date_create(date('Y-m-d'));
				$email_token = $data[0]['email_token'];
				$email_token_date = date_create(date('Y-m-d',strtotime($data[0]['email_token_date'])));
				$days = date_diff($email_token_date,$curr_date);
				$days = $days->format('%a');
				if(!empty($email_token) && $days > EMAIL_TOKEN_DATE_VALIDITY){
					$this->steps = 1;
					$this->title="Email Verification";
					return false;
				}else if(!empty($email_token) && $days <= EMAIL_TOKEN_DATE_VALIDITY){
					$this->steps = 2;
					$this->title="Email Verification";
					return false;
				}
				return true;
			}
		}return false;
	}

	function email_verification(){
		$this->steps = 1;
		$this->title="Email Verification";
		$where = ' status="1" AND username="'.$this->session->userdata('username').'"';
		if(isset($_POST) && count($_POST)>0){
			$this->form_validation->set_rules('email','Email Id','trim|xss_clean|required|valid_email|callback_checkdata[email,'.$where.']');
	    	if ($this->form_validation->run() == FALSE){
	    		$errors = $this->form_validation->geterror_array();
	    		$this->form_validation->unseterror_array();
	    		$error = 'Enter a valid Email Id!';
	            $this->errors = $error; 
	            return false;
			}else{
				$email_token_date = date('Y-m-d H:i:s');
				$email_token = md5(mt_rand(2, 3).microtime()).'~'.$this->session->userdata('user_id');
				$set = 'email_token="'.$email_token.'",email_token_date="'.$email_token_date.'"';
				$where .=' AND email="'.trim($this->form_validation->set_value('email')).'"';
		    	$update = $this->auth->update_data('user',$set,$where);
		    	if($update){
		    		$from = $this->config->item('from_noreplay_email');
			      	$from_name = $this->config->item('fromname');
			      	$subject = 'Please verify your email address';
			      	$to = trim($this->form_validation->set_value('email'));
			      	$data['click_link'] = base_url().'verify-email/'.$email_token; 
			      	$msg = $this->load->view('admin/email/email_verification',$data,true);
			      	if($this->sendmail($from,$from_name,$to,$subject,$msg)){
			      		return true;
			      	}else{
			      		$this->errors = 'Oops some went wrong! Please send it again or try after some time.';
			      		return false;
			      	}
		    	}	
		    }
		}
		return false;
	}

	function forgetpassword(){
		$this->steps = 3;
		$this->title="Forget Password";
      	if(isset($_POST) && count($_POST)>0){
      		$where = ' status="1"';
			$this->form_validation->set_rules('forgetpass','Email Id','trim|xss_clean|required|valid_email|callback_checkdata[email,'.$where.']');
	    	if ($this->form_validation->run() == FALSE){
	    		$errors = $this->form_validation->geterror_array();
	    		$this->form_validation->unseterror_array();
	    		$error = 'Enter a valid Email Id!';
	            $this->errors = $error;    
			}else{
				$email = trim($this->form_validation->set_value('forgetpass'));
				$data = $this->auth->get_data('user','id','email="'.$email.'"');
				if(!empty($data)){
					$password_token = md5(mt_rand(2, 3).microtime()).'~'.$data[0]['id'];
					$set = 'password_token="'.$password_token.'"';
					$where .=' AND email="'.$email.'" AND id='.$data[0]['id'];
			    	$update = $this->auth->update_data('user',$set,$where);
			    	if($update){
						$from = $this->config->item('from_noreplay_email');
				      	$from_name = $this->config->item('fromname');
				      	$subject = 'Reset password';
				      	$to = $email;
				      	$data['click_link'] = base_url().'reset-password/'.$password_token; 
				      	$msg = $this->load->view('admin/email/resetpassword',$data,true);
				      	if($this->sendmail($from,$from_name,$to,$subject,$msg)){
				      		$this->steps = 4;
							$this->title="Reset Password!";
							$this->msg = '<p style="color:green;font-size: 1.4em;"><i class="fa fa-smile-o" aria-hidden="true"></i> Please check your email to reset your password.</p>';
							return false;
				      	}else{
				      		$this->errors = 'Oops some went wrong! Please send it again or try after some time.';
				      		return false;
				      	}
				    }else{
				    	$this->errors = 'Oops some went wrong! Please send it again or try after some time.';
				      	return false;
				    }
				}
			}
		}
		return false;
	}

	function verify_email($verify){
		$column_name = explode('~',$verify);
		$where = ' status="1" AND email_token="'.$verify.'" AND id="'.(isset($column_name[1]) && !empty($column_name[1]) ? $column_name[1] : '').'"';
		$data = $this->auth->get_total_count('user',$where);
		if($data){
			$emailtoken=$this->auth->update_data('user','email_token = null',$where);
				if($emailtoken){
					$this->steps = 4;
					$this->title="Email Verification Successfull!";
					$this->msg = '<p style="color:green;font-size: 1.4em;"><i class="fa fa-smile-o" aria-hidden="true"></i> Email Verification Successfull.</p>';
					return false;
				}else{
					$this->steps = 4;
					$this->title="Email Verification Failed!";
					$this->msg = '<p style="color:red;font-size: 1.4em;"><i class="fa fa-frown-o" aria-hidden="true"></i> Email Verification Failed!</p>';
					return false;
				}
		}
		redirect('login','refresh');
	}

	function resetpassword($verify){
		$this->steps = 5;
		$this->title="Reset Password";
		$column_name = explode('~',$verify);
		$where = ' status="1" AND password_token="'.$verify.'" AND id="'.(isset($column_name[1]) && !empty($column_name[1]) ? $column_name[1] : '').'"';
		$data = $this->auth->get_total_count('user',$where);
		if(isset($_POST) && count($_POST)<=0 && !empty($data)){
			return false;	
		}else if(isset($_POST) && count($_POST)>0 && !empty($data)){
			$this->form_validation->set_rules('newpassword','New Password','trim|xss_clean|required|min_length[8]|max_length[16]');
			$this->form_validation->set_rules('confirmpassword','Confirm Password','trim|xss_clean|required|min_length[8]|max_length[16]|matches[newpassword]');

		    	if ($this->form_validation->run() == FALSE){
		    		$errors = $this->form_validation->geterror_array();
		    		$error = 'Enter a valid ';
	                    $flag=0;
	                    foreach($errors as $key => $value){
	                        if($flag == 1){
	                            $error .= ' or ';
	                        }
	                        $error .= ucfirst($key);
	                        $flag++;
	                    }
	                    unset($flag);
	                    $error .= '!';
	                $this->errors = $error;    
					$this->form_validation->unseterror_array();
					return false;
			    }else{
			    	$newpassword = $this->form_validation->set_value('newpassword');
			    	$set = 'password ="'.md5(trim($newpassword)).'", password_token = null , last_password_change_date="'.date('Y-m-d H:i:s').'"';
			    	$passwordtoken=$this->auth->update_data('user',$set,$where);
			    	if($passwordtoken){
						$this->steps = 4;
						$this->title="Password Reset Successfull!";
						$this->msg = '<p style="color:green;font-size: 1.4em;"><i class="fa fa-smile-o" aria-hidden="true"></i> Password Reset Successfull.</p>';
						return false;
					}else{
						$this->steps = 4;
						$this->title="Password Reset Failed!";
						$this->msg = '<p style="color:red;font-size: 1.4em;"><i class="fa fa-frown-o" aria-hidden="true"></i> Password Reset Failed!</p>';
						return false;
					}
			    }
		}
		redirect('login','refresh');
	}

	function sendmail($from,$from_name,$to,$subject,$msg){
		$this->load->library('My_PHPMailer');
		$mail = new PHPMailer();
      	$mail->AddAddress($to);
      	$mail->IsMail();
      	$mail->From = $from;
      	$mail->FromName = $from_name;
      	$mail->IsHTML(true);
      	$mail->Subject = $subject;
      	$mail->Body = $msg;
      	if($mail->Send()){
      		return true;
      	}else{
      		return false;
      	}
	}

	function logout(){
		$this->session->sess_destroy();
		redirect('login','refresh');
	}

}