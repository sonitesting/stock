<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class auth_roles extends CI_Controller{

	function __Construct(){
		parent::__construct();

		$this->load->library('auth');
		if(!$this->auth->is_logged_in()){
			redirect('login','refresh');
		}
	}

	function _remap($method, $params=array())
    {
        $methodToCall = method_exists($this, $method) ? $method : 'index';
        return call_user_func_array(array($this, $methodToCall), $params);
    }

	function index(){

		$created_by = $this->auth->get_data('user','id,first_name,last_name','user_type="1"','','order by first_name asc');
		$created_by_option =array();
		if(!empty($created_by)){
			foreach($created_by as $row){
				$created_by_option[$row['id']] = $row['first_name'].' '.$row['last_name']; 
			}	
		}


		$base_url = base_url().'roles';
		$segment = 2;
		$per_page = 10;

		$this->load->library('generate_table');
		$this->generate_table->set_table_name('roles');
		$this->generate_table->set_order_by('roles_name:asc');
		$this->generate_table->set_pagination_url($base_url);
		$this->generate_table->set_per_page($per_page);
		$this->generate_table->set_uri_segment($segment);
		$this->generate_table->set_table_caption('Roles');
		$field_list = array(
				'id' =>array(
					'type'=>'text',
					'table_heading' =>'ID',
					'search_field' => false,
					'display_field' =>false
				),
				'roles_name' => array(
					'type' => 'text',
					'table_heading' => 'Roles',
					'search_field' => true,
					'display_field' =>true	
				),
				'created_by' =>array(
					'type'=>'select',
					'table_heading' =>'Created By',
					'search_field' => true,
					'display_field' =>true,
					'option'=>$created_by_option
				),
				'Updated_by' =>array(
					'type'=>'select',
					'table_heading' =>'Updated By',
					'search_field' => true,
					'display_field' =>true,
					'option'=>$created_by_option
				),
				'created_date'=>array(
					'type'=>'date',
					'table_heading' =>'Created Date',
					'search_field' => true,
					'display_field' =>true,
					'format'=>"date('m/d/Y',strtotime('~created_date~'))"
				),
				'update_date'=>array(
					'type'=>'date',
					'table_heading' =>'Updated Date',
					'search_field' => true,
					'display_field' =>true,
					'format'=>"date('Y-m-d',strtotime('~update_date~'))"
				),
				'status' => array(
					'type' => 'select',
					'table_heading' => 'Status',
					'search_field' => true,
					'display_field' =>true,
					'option' =>array('0'=>'In-Active','1'=>'Active')
				),
		);
		$this->generate_table->set_field_list($field_list);
		$field_action = array('view','edit','delete','add');
		$this->generate_table->set_field_action($field_action);

		$custom_field_action = array();
		if(isset($this->session->userdata['session_action']['auth_roles_group_access']) && $this->session->userdata['session_action']['auth_roles_group_access']){
			$custom_field_action[] = '<a href="'.base_url().'roles/group_access/id" class="btn btn-info btn-icon-only btn-transparent btn-circle" title="Group Access"><i class="fa fa-universal-access" aria-hidden="true"></i></a>';
		}

		

		$custom_field_action = $custom_field_action; 
		$this->generate_table->set_custom_field_action($custom_field_action);

		$data = $this->generate_table->get_table();
		$data['title']='Roles';
		$data['page']='Roles';
		if($this->input->post()){
			echo json_encode($data);
			exit;
		}else{
			$data['base_url']=$base_url;
			$data['per_page']=$per_page;

			$this->load->view('admin/header',$data);
			$this->load->view('admin/side_menu');
			$this->load->view('admin/table_view');
			$this->load->view('admin/footer');
		}
	}

	function edit($type = null){
		$this->load->library('form_validation');

		$primary_id = $this->uri->segment(3);
		$data['get_data'] = array();
		$data['errors'] = '';
		if($this->input->post()){
			$this->form_validation->set_rules('id','ID','trim|xss_clean');
			$this->form_validation->set_rules('roles_name','Roles','trim|xss_clean|required|alpha_numeric_spaces|min_length[2]|max_length[20]');
			$this->form_validation->set_rules('status','Status','trim|xss_clean|required');

			if($this->form_validation->run() == false){
				$data['errors'] = $this->form_validation->geterror_array();
				$this->form_validation->unseterror_array();
			}else{
				$data_arr = array(
					'id' => $this->form_validation->set_value('id'),
					'roles_name'=> $this->form_validation->set_value('roles_name'),
					'status'=> $this->form_validation->set_value('status')
				);
				$result = $this->auth->save_data('roles',$data_arr);
				if($result == 'update_data'){
					$this->session->set_userdata('status_msg', 'update_success');	
					redirect('roles','refresh');
				}else if($result == 'already_update_data'){
					$this->session->set_userdata('status_msg', 'already_update_success');	
					redirect('roles','refresh');
				}else if($result > 0){

					$data_arr = array(
						'id'=>'',
						'roles_id'=>$result
					);
					$this->auth->save_data('group_access',$data_arr);

					$this->session->set_userdata('status_msg', 'insert_success');	
					redirect('roles','refresh');
				}else{
					$this->session->set_userdata('status_msg', 'error');
					redirect('roles','refresh');	
				}
			}
		}else{
			$data['get_data'] = $this->auth->get_data_by_id($primary_id,'roles','id,roles_name,status');
		}
		$data['type'] = $type;
		$data['title'] = 'Roles Detail';
		$data['page']='Roles';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/side_menu');
		$this->load->view('admin/roles_form_view');
		$this->load->view('admin/footer');

	}

	function add(){
		$this->edit('add');	
	}

	function view(){
		$this->edit('view');	
	}

	function delete(){
		if(isset($_POST) && count($_POST)>0){
			$id = $_POST['id'];
			$where = 'id='.$id;
			$data = $this->auth->delete_data('roles',$where);
			echo $data;
		}
	}

	// function group_access(){

	// 	$roles_id = $this->uri->segment(3);

	// 	$data['action_list'] = $this->auth->get_data('action_list','id,action_name','status="1"','','order by action_name asc');

	// 	if($this->input->post()){
			
	// 		if($roles_id == $this->input->post('roles_id')){

	// 			$action_list_id = $this->input->post('action_list_id');

	// 			$action_list_id = implode(',',$action_list_id);


	// 			$data_arr = array(
	// 				'id' => $this->input->post('id'),
	// 				'roles_id'=> $this->input->post('roles_id'),
	// 				'action_list_id'=> $action_list_id
	// 			);
	// 			$result = $this->auth->save_data('group_access',$data_arr);
	// 			if($result == 'update_data'){
	// 				$this->session->set_userdata('status_msg', 'update_success');	
	// 				redirect('roles','refresh');
	// 			}else if($result == 'already_update_data'){
	// 				$this->session->set_userdata('status_msg', 'already_update_success');	
	// 				redirect('roles','refresh');
	// 			}else if($result > 0){
	// 				$this->session->set_userdata('status_msg', 'insert_success');	
	// 				redirect('roles','refresh');
	// 			}else{
	// 				$this->session->set_userdata('status_msg', 'error');
	// 				redirect('roles','refresh');	
	// 			}
	// 		}else{
	// 			$this->session->set_userdata('status_msg', 'error');
	// 			redirect('roles','refresh');
	// 		}
			
	// 	}else{
	// 		$data['get_data'] = $this->auth->get_row_data('group_access','group_access.id,roles.roles_name,group_access.roles_id,group_access.action_list_id','group_access.roles_id='.$roles_id,'Join roles on roles.id=group_access.roles_id');
	// 	}
		
	// 	$data['title'] = 'Group Access';
	// 	$data['page']='Roles';
	// 	$this->load->view('admin/header',$data);
	// 	$this->load->view('admin/side_menu');
	// 	$this->load->view('admin/groupaccess_form_view');
	// 	$this->load->view('admin/footer');
	// }


	function group_access(){

		$roles_id = $this->uri->segment(3);

		$controllerlist = $this->auth->get_data('controllerlist','id,controllername,parent,menu_name,action_id','status="1" AND menu_type="1"','','order by ctl_menu_position asc , id asc');
		$controllerlist_arr = array();
		if(!empty($controllerlist)){
			foreach($controllerlist as $row){
				if($row['parent'] == 0){
					$controllerlist_arr[$row['id']]['controllername'] = $row['controllername']; 
				}else if($row['controllername'] == 'index'){
					$controllerlist_arr[$row['parent']]['functionname'][$row['id']] = $row['controllername'];
					$controllerlist_arr[$row['parent']]['menu_name'][$row['id']] = $row['menu_name'];
					$controllerlist_arr[$row['parent']]['action_id'][$row['id']] = $row['action_id'];
				}
			}

			foreach($controllerlist as $row){
				if($row['parent'] == 0){
					$controllerlist_arr[$row['id']]['controllername'] = $row['controllername']; 
				}else if($row['controllername'] != 'index'){
					$controllerlist_arr[$row['parent']]['functionname'][$row['id']] = $row['controllername'];
					$controllerlist_arr[$row['parent']]['menu_name'][$row['id']] = $row['menu_name'];
					$controllerlist_arr[$row['parent']]['action_id'][$row['id']] = $row['action_id'];
				}
			}
		}


		$data['controllerlist'] = $controllerlist_arr;

		if($this->input->post()){
			
			if($roles_id == $this->input->post('roles_id')){

				$menu_id = $this->input->post('menu_id');
				if(!empty($menu_id)){
					$menu_id = implode(',',$menu_id);
				}else{
					$menu_id = '';
				}

				$action_list_id = $this->input->post('action_list_id');

				$access_id = '';
				$action_id = '';
				if(!empty($action_list_id)){
					foreach($action_list_id as $key => $value){
						$val = explode('_',$value);
						$access_id[] = $val[0];
						$action_id[] = $val[1].'_'.$val[2];
						unset($val);
					}

					//$action_id = implode(',',$action_list_id);
				}

				if(!empty($access_id)){
					$access_id = implode(',',$access_id);
				}
				if(!empty($action_id)){
				 	$action_id = implode(',',$action_id);
				}
				
				$data_arr = array(
					'id' => $this->input->post('id'),
					'roles_id'=> $this->input->post('roles_id'),
					'menu_id' => $menu_id,
					'access_id' => $access_id,
					'action_list_id'=> $action_id
				);
				$result = $this->auth->save_data('group_access',$data_arr);
				if($result == 'update_data'){
					$this->session->set_userdata('status_msg', 'update_success');	
					redirect('roles','refresh');
				}else if($result == 'already_update_data'){
					$this->session->set_userdata('status_msg', 'already_update_success');	
					redirect('roles','refresh');
				}else if($result > 0){
					$this->session->set_userdata('status_msg', 'insert_success');	
					redirect('roles','refresh');
				}else{
					$this->session->set_userdata('status_msg', 'error');
					redirect('roles','refresh');	
				}
			}else{
				$this->session->set_userdata('status_msg', 'error');
				redirect('roles','refresh');
			}
			
		}else{
			$data['get_data'] = $this->auth->get_row_data('group_access','group_access.id,roles.roles_name,group_access.roles_id,group_access.menu_id,group_access.access_id,group_access.action_list_id','group_access.roles_id='.$roles_id,'Join roles on roles.id=group_access.roles_id');
		}
		
		//print'<pre>';print_r($data['controllerlist']);exit;

		$data['title'] = 'Group Access';
		$data['page']='Roles';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/side_menu');
		$this->load->view('admin/groupaccess_form_view');
		$this->load->view('admin/footer');
	}




}