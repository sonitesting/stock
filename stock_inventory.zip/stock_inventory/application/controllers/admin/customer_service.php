<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer_service extends CI_Controller{

	function __Construct(){
		parent::__construct();

		$this->load->library('auth');
		if(!$this->auth->is_logged_in()){
			redirect('login','refresh');
		}
	}

	function _remap($method, $params=array())
    {	
        $methodToCall = method_exists($this, $method) ? $method : 'index';
        return call_user_func_array(array($this, $methodToCall), $params);
    }

	function index(){

		$created_by = $this->auth->get_data('user','id,first_name,last_name','user_type="1"','','order by first_name asc');
		$created_by_option =array();
		if(!empty($created_by)){
			foreach($created_by as $row){
				$created_by_option[$row['id']] = $row['first_name'].' '.$row['last_name']; 
			}	
		}
		$base_url = base_url().'customer_service';
		$segment = 2;
		$per_page = 10;

		$this->load->library('generate_table');
		$this->generate_table->set_table_name('customer_service');
		$this->generate_table->set_order_by('id:desc');
		$this->generate_table->set_pagination_url($base_url);
		$this->generate_table->set_per_page($per_page);
		$this->generate_table->set_uri_segment($segment);
		$this->generate_table->set_table_caption('Customer Service');
		$field_list = array(
				'id' =>array(
					'type'=>'number',
					'table_heading' =>'Ref. No.',
					'search_field' => true,
					'display_field' =>true,
				),
				'first_name' => array(
					'type' => 'text',
					'table_heading' => 'First Name',
					'search_field' => true,
					'display_field' =>true
				),
				'last_name' => array(
					'type' => 'text',
					'table_heading' => 'Last Name',
					'search_field' => true,
					'display_field' =>true
				),
				'email' => array(
					'type' => 'text',
					'table_heading' => 'Email',
					'search_field' => true,
					'display_field' =>true
				),
				'mobile' => array(
					'type' => 'text',
					'table_heading' => 'Mobile No.',
					'search_field' => true,
					'display_field' =>true
				),
				'status' => array(
					'type' => 'select',
					'table_heading' => 'Status',
					'search_field' => true,
					'display_field' =>true,
					'option' =>array('0'=>'Closed','1'=>'Open','2'=>'Pending','3'=>'Process','4'=>'Wating')
				),
				'created_by' =>array(
					'type'=>'select',
					'table_heading' =>'Created By',
					'search_field' => true,
					'display_field' =>true,
					'option'=>$created_by_option
				),
				'updated_by' =>array(
					'type'=>'select',
					'table_heading' =>'Updated By',
					'search_field' => true,
					'display_field' =>true,
					'option'=>$created_by_option
				),
				'created_date'=>array(
					'type'=>'date',
					'table_heading' =>'Created Date',
					'search_field' => true,
					'display_field' =>true,
					'format'=>"date('m/d/Y',strtotime('~created_date~'))"
				),
				'update_date'=>array(
					'type'=>'date',
					'table_heading' =>'Updated Date',
					'search_field' => true,
					'display_field' =>true,
					'format'=>"date('m/d/Y',strtotime('~update_date~'))"
				)
		);
		$this->generate_table->set_field_list($field_list);
		$field_action = array('view','edit','delete','add');
		$this->generate_table->set_field_action($field_action);		

		$data = $this->generate_table->get_table();
		$data['title']='Customer Service';
		$data['page']='Customer Service';
		if($this->input->post()){
			echo json_encode($data);
			exit;
		}else{
			$data['base_url']=$base_url;
			$data['per_page']=$per_page;
			
			$this->load->view('admin/header',$data);
			$this->load->view('admin/side_menu');
			$this->load->view('admin/table_view');
			$this->load->view('admin/footer');
		}
	}

	function edit($type = null){
		$this->load->library('form_validation');

		$data['country'] = $this->auth->get_data('country','id,country_name','status="1"','','order by country_name asc');

		$data['category'] = $this->auth->get_data('product_category','id,category_name','status="1"','','order by category_name asc');

		$data['service_center'] = $this->auth->get_data('user','id,first_name,last_name','status="1" and roles_id=7','','order by first_name asc');

		$primary_id = $this->uri->segment(3);
		$data['get_data'] = array();
		$data['errors'] = '';
		if($this->input->post()){
			$this->form_validation->set_rules('id','ID','trim|xss_clean');
			$this->form_validation->set_rules('first_name','First Name','trim|xss_clean|required|min_length[2]|max_length[20]|callback_alpha_dash_space');
			$this->form_validation->set_rules('last_name','Last Name','trim|xss_clean|required|min_length[2]|max_length[20]|callback_alpha_dash_space');
			$this->form_validation->set_rules('gender','Gender','trim|xss_clean|required');
			$this->form_validation->set_rules('dob','DOB','trim|xss_clean');
			$this->form_validation->set_rules('email','Email Id','trim|xss_clean|required|valid_email');
			$this->form_validation->set_rules('mobile','Mobile No.','trim|xss_clean|required|min_length[10]|max_length[10]|numeric');
			$this->form_validation->set_rules('address','Street','trim|xss_clean|required|min_length[10]|max_length[100]');
			$this->form_validation->set_rules('country_id','Country','trim|xss_clean|required|numeric');
			$this->form_validation->set_rules('state_id','State','trim|xss_clean|required|numeric');
			$this->form_validation->set_rules('city_id','City','trim|xss_clean|required|numeric');
			$this->form_validation->set_rules('postcode','Pincode','trim|xss_clean|required|min_length[6]|max_length[6]|numeric');
			$this->form_validation->set_rules('product_cat_id','Category','trim|xss_clean|required');
			$this->form_validation->set_rules('complain_msg','Message','trim|xss_clean|required|min_length[10]|max_length[225]');
			$this->form_validation->set_rules('service_center_id','Service Center','trim|xss_clean|required');
			$this->form_validation->set_rules('status','Status','trim|xss_clean|required');

			if($this->form_validation->run() == false){
				$data['errors'] = $this->form_validation->geterror_array();
				$this->form_validation->unseterror_array();
			}else{

				$data_arr = array(
					'id' => $this->form_validation->set_value('id'),
					'first_name'=> $this->form_validation->set_value('first_name'),
					'last_name'=> $this->form_validation->set_value('last_name'),
					'gender'=> $this->form_validation->set_value('gender'),
					'dob'=> $this->form_validation->set_value('dob'),
					'email'=> $this->form_validation->set_value('email'),
					'mobile'=> $this->form_validation->set_value('mobile'),
					'address'=> $this->form_validation->set_value('address'),
					'country_id'=> $this->form_validation->set_value('country_id'),
					'state_id'=> $this->form_validation->set_value('state_id'),
					'city_id'=> $this->form_validation->set_value('city_id'),
					'postcode'=> $this->form_validation->set_value('postcode'),
					'product_cat_id' => $this->form_validation->set_value('product_cat_id'),
					'complain_msg' =>$this->form_validation->set_value('complain_msg'),
					'service_center_id' =>$this->form_validation->set_value('service_center_id'),
					'status'=> $this->form_validation->set_value('status')
				);

				$result = $this->auth->save_data('customer_service',$data_arr);
				if($result == 'update_data'){
					$this->session->set_userdata('status_msg', 'update_success');	
					redirect('customer_service','refresh');
				}else if($result == 'already_update_data'){
					$this->session->set_userdata('status_msg', 'already_update_success');	
					redirect('customer_service','refresh');
				}else if($result > 0){
					$this->session->set_userdata('status_msg', 'insert_success');	
					redirect('customer_service','refresh');
				}else{
					$this->session->set_userdata('status_msg', 'error');
					redirect('customer_service','refresh');	
				}
			}
		}else{
			$data['get_data'] = $this->auth->get_data_by_id($primary_id,'customer_service');
		}
		$data['type'] = $type;
		$data['title'] = 'Customer Service Detail';
		$data['page']='Customer Service';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/side_menu');
		$this->load->view('admin/customer_service_form_view');
		$this->load->view('admin/footer');

	}

	function alpha_dash_space($field){
		if (! preg_match('/^[a-zA-Z\s]+$/', $field)) {
		$this->form_validation->set_message('alpha_dash_space', 'The %s field may only contain alpha characters & White spaces');
		return FALSE;
		} else {
		return TRUE;
		}
	}

	function add(){
		$this->edit('add');	
	}

	function view(){
		$this->edit('view');	
	}

	function delete(){
		if(isset($_POST) && count($_POST)>0){
			$id = $_POST['id'];
			$where = 'id='.$id;
			$data = $this->auth->delete_data('customer_service',$where);
			echo $data;
		}
	}

	
}