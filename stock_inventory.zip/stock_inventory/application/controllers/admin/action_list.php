<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Action_list extends CI_Controller{

	function __Construct(){
		parent::__construct();

		$this->load->library('auth');
		if(!$this->auth->is_logged_in()){
			redirect('login','refresh');
		}
	}

	function _remap($method, $params=array())
    {	
        $methodToCall = method_exists($this, $method) ? $method : 'index';
        return call_user_func_array(array($this, $methodToCall), $params);
    }

	function index(){
		
		$created_by = $this->auth->get_data('user','id,first_name,last_name','user_type="1"','','order by first_name asc');
		$created_by_option =array();
		if(!empty($created_by)){
			foreach($created_by as $row){
				$created_by_option[$row['id']] = $row['first_name'].' '.$row['last_name']; 
			}	
		}
		$base_url = base_url().'action_list';
		$segment = 2;
		$per_page = 10;

		$this->load->library('generate_table');
		$this->generate_table->set_table_name('action_list');
		$this->generate_table->set_order_by('action_name:asc');
		$this->generate_table->set_pagination_url($base_url);
		$this->generate_table->set_per_page($per_page);
		$this->generate_table->set_uri_segment($segment);
		$this->generate_table->set_table_caption('Action List');
		$field_list = array(
				'id' =>array(
					'type'=>'number',
					'table_heading' =>'ID',
					'search_field' => true,
					'display_field' =>false,
				),
				'action_name' => array(
					'type' => 'text',
					'table_heading' => 'Action',
					'search_field' => true,
					'display_field' =>true,
				),
				'created_by' =>array(
					'type'=>'select',
					'table_heading' =>'Created By',
					'search_field' => true,
					'display_field' =>true,
					'option'=>$created_by_option
				),
				'Updated_by' =>array(
					'type'=>'select',
					'table_heading' =>'Updated By',
					'search_field' => true,
					'display_field' =>true,
					'option'=>$created_by_option
				),
				'created_date'=>array(
					'type'=>'date',
					'table_heading' =>'Created Date',
					'search_field' => true,
					'display_field' =>true,
					'format'=>"date('m/d/Y',strtotime('~created_date~'))"
				),
				'update_date'=>array(
					'type'=>'date',
					'table_heading' =>'Updated Date',
					'search_field' => true,
					'display_field' =>true,
					'format'=>"date('m/d/Y',strtotime('~update_date~'))"
				),
				'status' => array(
					'type' => 'select',
					'table_heading' => 'Status',
					'search_field' => true,
					'display_field' =>true,
					'option' =>array('0'=>'In-Active','1'=>'Active')
				),
		);
		$this->generate_table->set_field_list($field_list);
		$field_action = array('view','edit','delete','add');
		$this->generate_table->set_field_action($field_action);

		$data = $this->generate_table->get_table();
		$data['title']='Action List';
		$data['page']='Action';
		if($this->input->post()){
			echo json_encode($data);
			exit;
		}else{
			$data['base_url']=$base_url;
			$data['per_page']=$per_page;
			
			$this->load->view('admin/header',$data);
			$this->load->view('admin/side_menu');
			$this->load->view('admin/table_view');
			$this->load->view('admin/footer');
		}
	}

	function edit($type = null){
		$this->load->library('form_validation');

		$primary_id = $this->uri->segment(3);
		$data['get_data'] = array();
		$data['errors'] = '';
		if($this->input->post()){
			$this->form_validation->set_rules('id','ID','trim|xss_clean');
			$this->form_validation->set_rules('action_name','Action Name','trim|xss_clean|required|alpha_numeric_spaces|min_length[2]|max_length[20]');
			$this->form_validation->set_rules('status','Status','trim|xss_clean|required');

			if($this->form_validation->run() == false){
				$data['errors'] = $this->form_validation->geterror_array();
				$this->form_validation->unseterror_array();
			}else{
				$data_arr = array(
					'id' => $this->form_validation->set_value('id'),
					'action_name'=> $this->form_validation->set_value('action_name'),
					'status'=> $this->form_validation->set_value('status')
				);
				$result = $this->auth->save_data('action_list',$data_arr);
				if($result == 'update_data'){
					$this->session->set_userdata('status_msg', 'update_success');	
					redirect('action_list','refresh');
				}else if($result == 'already_update_data'){
					$this->session->set_userdata('status_msg', 'already_update_success');	
					redirect('action_list','refresh');
				}else if($result > 0){
					$this->session->set_userdata('status_msg', 'insert_success');	
					redirect('action_list','refresh');
				}else{
					$this->session->set_userdata('status_msg', 'error');
					redirect('action_list','refresh');	
				}
			}
		}else{
			$data['get_data'] = $this->auth->get_data_by_id($primary_id,'action_list','id,action_name,status');
		}
		$data['type'] = $type;
		$data['title'] = 'Action Detail';
		$data['page']='Action';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/side_menu');
		$this->load->view('admin/action_form_view');
		$this->load->view('admin/footer');

	}

	function add(){
		$this->edit('add');	
	}

	function view(){
		$this->edit('view');	
	}

	function delete(){
		if(isset($_POST) && count($_POST)>0){
			$id = $_POST['id'];
			$where = 'id='.$id;
			$data = $this->auth->delete_data('action_list',$where);
			echo $data;
		}
	}
}