<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ajaxcall extends CI_Controller{

	function __Construct(){
		parent::__construct();

		$this->load->library('auth');
		if(!$this->auth->is_logged_in()){
			redirect('login','refresh');
		}
	}

	function _remap($method, $params=array())
    {	
        $methodToCall = method_exists($this, $method) ? $method : 'index';
        return call_user_func_array(array($this, $methodToCall), $params);
    }

	function index(){
		$type = trim($this->input->post('type'));
		switch($type){
			case 'state':
				$this->state();
				break;
			case 'city':
				$this->city();
				break;
		}
		echo false;
		exit;
	}

	function state(){
		$country_id = trim($this->input->post('country_id'));
		if(!empty($country_id)){
			$where = ' status="1" AND country_id='.$country_id;
			$extra_condition = ' order by state_name asc';
			$state_list = $this->auth->get_data('state','id,state_name',$where,'',$extra_condition);
			echo json_encode($state_list);exit;
		}
		echo false;
	}

	function city(){
		$state_id = trim($this->input->post('state_id'));
		if(!empty($state_id)){
			$where = ' status="1" AND state_id='.$state_id;
			$extra_condition = ' order by city_name asc';
			$city_list = $this->auth->get_data('city','id,city_name',$where,'',$extra_condition);
			echo json_encode($city_list);exit;
		}
		echo false;
	}
}