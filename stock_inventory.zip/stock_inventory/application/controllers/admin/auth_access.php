<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class auth_access extends CI_Controller{

	function __Construct(){
		parent::__construct();

		$this->load->library('auth');
		if(!$this->auth->is_logged_in()){
			redirect('login','refresh');
		}
		$this->refresh();
	}

	function _remap($method, $params=array())
    {	
        $methodToCall = method_exists($this, $method) ? $method : 'index';
        return call_user_func_array(array($this, $methodToCall), $params);
    }

	function index(){
		
		if($this->input->post()){
			$menu_name = $this->input->post('menu_name');

			$menu_type = $this->input->post('menu_type');
			$menu_category_id = $this->input->post('menu_category_id');
			$action_id = $this->input->post('action_id');
			$url = $this->input->post('url');
			$status = $this->input->post('status');
			$ctl_menu_icon = $this->input->post('ctl_menu_icon');
			$page_active_title = $this->input->post('page_active_title');

			if(!empty($menu_name)){
				foreach($menu_name as $key => $value ){
					$data_arr = array(
						'id' => $key,
						'menu_name' => $value,
						'menu_type' => $menu_type[$key],
						'menu_category_id' =>(isset($menu_category_id[$key]) ? $menu_category_id[$key] : 0) ,
						'action_id' => (isset($action_id[$key]) ? $action_id[$key] : 0),
						'url'=>(isset($url[$key]) ? $url[$key] : ''),
						'ctl_menu_icon'=>(isset($ctl_menu_icon[$key]) ? $ctl_menu_icon[$key] : ''),
						'page_active_title'=>(isset($page_active_title[$key]) ? $page_active_title[$key] : ''),
						'status'=>$status[$key]
					);
					$set = '';
					foreach($data_arr as $arr_key => $arr_value){
						$set .= sprintf('`%s` = "%s" , ', $arr_key, $arr_value);
					} 

					$arr1 = str_split($set);
			        if ($arr[(count($arr1)) - 2] = " , ") {
			            $set = substr($set, 0, (count($arr1)) - 2);
			        }else {
			            $set = $set;
			        }
					// if(!empty($value)){
					// 	$set .= 'menu_name="'.$value.'" '; 
					// }

					// if(!empty($menu_type[$key]) && !empty($value)){
					// 	$set .= ',';
					// }
					
					// if(!empty($menu_type[$key])){
					// 	$set .= ' menu_type='.$menu_type[$key];
					// }

					// if(!empty($menu_type[$key]) && !empty($value)){
					// 	$set .= ',';
					// }

					// if(!empty($action_id[$key])){
					// 	$set .= ' action_id='.$action_id[$key];
					// }

					if(!empty($set)){
						$this->auth->update_data('controllerlist',$set,'id='.$key);
					}
				}
			}
			$this->session->set_userdata('status_msg', 'insert_success');
		}


		$data['title']='Access Control';
		$data['add_css']='<link href="'.base_url().'assets/global/plugins/jstree/dist/themes/default/style.min.css" rel="stylesheet" type="text/css" />'	;
		$data['add_js']='<script src="'.base_url().'assets/global/plugins/jstree/dist/jstree.min.js" type="text/javascript"></script>'	;

		$data['action_list'] = $this->auth->get_data('action_list','id,action_name','status="1"','','order by action_name asc');
		$data['menu_category'] = $this->auth->get_data('menu_category','id,menu_cat_name','status="1"','','order by menu_cat_name asc');

		$controllerlist = $this->auth->get_data('controllerlist','id,controllername,parent,menu_name,menu_type,action_id,menu_category_id,status,url,page_active_title,ctl_menu_icon');
		$controllerlist_arr = array();
		


		if(!empty($controllerlist)){
			foreach($controllerlist as $row){
				if($row['parent'] == '0'){
					$controllerlist_arr[$row['id']]['controllername'] = $row['controllername']; 
				}else if($row['controllername'] == 'index'){
					
					$controllerlist_arr[$row['parent']]['functionname'][$row['id']] = $row['controllername'];
					$controllerlist_arr[$row['parent']]['menu_name'][$row['id']] = $row['menu_name'];
					$controllerlist_arr[$row['parent']]['menu_type'][$row['id']] = $row['menu_type'];
					$controllerlist_arr[$row['parent']]['menu_category_id'][$row['id']] = $row['menu_category_id'];
					$controllerlist_arr[$row['parent']]['action_id'][$row['id']] = $row['action_id'];
					$controllerlist_arr[$row['parent']]['status'][$row['id']] = $row['status'];
					$controllerlist_arr[$row['parent']]['url'][$row['id']] = $row['url'];
					$controllerlist_arr[$row['parent']]['ctl_menu_icon'][$row['id']] = $row['ctl_menu_icon'];
					$controllerlist_arr[$row['parent']]['page_active_title'][$row['id']] = $row['page_active_title'];
				}
			}


			foreach($controllerlist as $row){
				if($row['parent'] == '0'){
					$controllerlist_arr[$row['id']]['controllername'] = $row['controllername']; 
				}else if($row['controllername'] != 'index'){
					
					$controllerlist_arr[$row['parent']]['functionname'][$row['id']] = $row['controllername'];
					$controllerlist_arr[$row['parent']]['menu_name'][$row['id']] = $row['menu_name'];
					$controllerlist_arr[$row['parent']]['menu_type'][$row['id']] = $row['menu_type'];
					$controllerlist_arr[$row['parent']]['menu_category_id'][$row['id']] = $row['menu_category_id'];
					$controllerlist_arr[$row['parent']]['action_id'][$row['id']] = $row['action_id'];
					$controllerlist_arr[$row['parent']]['status'][$row['id']] = $row['status'];
					$controllerlist_arr[$row['parent']]['url'][$row['id']] = $row['url'];
					$controllerlist_arr[$row['parent']]['ctl_menu_icon'][$row['id']] = $row['ctl_menu_icon'];
					$controllerlist_arr[$row['parent']]['page_active_title'][$row['id']] = $row['page_active_title'];
				}
			}



		}

		$data['controllerlist'] = $controllerlist_arr;

		//print'<pre>';print_r($data['controllerlist']);exit;
		$data['page']='Access';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/side_menu');
		$this->load->view('admin/auth_access');
		$this->load->view('admin/footer');
	}

	private function refresh(){

		$this->load->library('controllerlist');
		//print'<pre>';print_r($this->controllerlist->getControllers());

		$controllerlist_arr = $this->controllerlist->getControllers();
		//$this->auth->update_data('controllerlist','status=0');
		refresh:
		foreach($controllerlist_arr as $key => $value){
			
			$query = $this->db->query('select id,controllername,status,ctl_menu_position from controllerlist where controllername="'.$key.'" AND parent=0');
			$query = $query->row_array();
			if(!empty($query)){
				$dir = '';
				if(isset($value['dir']) && !empty($value['dir'])){
					$dir = trim($value['dir']);
				}

				$this->auth->update_data('controllerlist','status="'.$query['status'].'",dir_path="'.$dir.'"','id='.$query['id']);

				if(is_array($value)){$cnt =0;
					foreach($value as $v_key => $v_value){
						
						if($v_key === 'dir'){
								
							continue;

						}else{	

							$value_query = $this->db->query('select id,controllername,status from controllerlist where controllername="'.$v_value.'" AND parent='.$query['id']);
							$value_query_arr = $value_query->row_array();
							if(empty($value_query_arr)){
								$position = $this->db->query('select ctl_menu_position from controllerlist order by ctl_menu_position desc limit 1');		
								$position = $position->row_array();	
								$method_name = array('controllername'=>$v_value,'parent'=>$query['id'],'status'=>'0','ctl_menu_position'=>$position['ctl_menu_position']+1);
								$this->db->insert('controllerlist',$method_name);
								unset($position);
							}
							else{
								$this->auth->update_data('controllerlist','status="'.$value_query_arr['status'].'"','id='.$value_query_arr['id']);
							}
						}
						$cnt++;
					}
				}
			}else{
				$dir = '';
				if(isset($value['dir']) && !empty($value['dir'])){
					$dir = trim($value['dir']);
				}
				$position = $this->db->query('select ctl_menu_position from controllerlist order by ctl_menu_position desc limit 1');
				$position = $position->row_array();
				$controller_name = array('controllername'=>$key,'parent'=>'0','dir_path'=>$dir,'status'=>'0','ctl_menu_position'=>$position['ctl_menu_position']+1);
				$this->db->insert('controllerlist',$controller_name);
				unset($position);
				goto refresh;
			}

		}
	}
}