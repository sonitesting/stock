<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class employees extends CI_Controller{

	function __Construct(){
		parent::__construct();

		$this->load->library('auth');
		if(!$this->auth->is_logged_in()){
			redirect('login','refresh');
		}
	}

	function _remap($method, $params=array())
    {	
        $methodToCall = method_exists($this, $method) ? $method : 'index';
        return call_user_func_array(array($this, $methodToCall), $params);
    }

	function index(){

		$roles = $this->auth->get_data('roles','id,roles_name','','','order by roles_name asc');
		$roles_option =array();
		if(!empty($roles)){
			foreach($roles as $row){
				$roles_option[$row['id']] = $row['roles_name']; 
			}	
		}

		$created_by = $this->auth->get_data('user','id,first_name,last_name','user_type="1"','','order by first_name asc');
		$created_by_option =array();
		if(!empty($created_by)){
			foreach($created_by as $row){
				$created_by_option[$row['id']] = $row['first_name'].' '.$row['last_name']; 
			}	
		}
		$base_url = base_url().'employees';
		$segment = 2;
		$per_page = 10;

		$this->load->library('generate_table');
		$this->generate_table->set_table_name('user');
		$this->generate_table->set_where('user_type = "1"');
		$this->generate_table->set_order_by('id:desc');
		$this->generate_table->set_pagination_url($base_url);
		$this->generate_table->set_per_page($per_page);
		$this->generate_table->set_uri_segment($segment);
		$this->generate_table->set_table_caption('Employees');
		$field_list = array(
				'id' =>array(
					'type'=>'number',
					'table_heading' =>'ID',
					'search_field' => true,
					'display_field' =>false,
				),
				'profile_pic'=>array(
					'type'=>'null',
					'table_heading' =>'Profile Pic.',
					'search_field' => false,
					'display_field' =>true,
					'format' =>'\'<img src="'.base_url().'~profile_pic~" width="50" height="50">\''
				),
				'username' => array(
					'type' => 'text',
					'table_heading' => 'User Name',
					'search_field' => true,
					'display_field' =>true,
				),
				'email' => array(
					'type' => 'text',
					'table_heading' => 'Email',
					'search_field' => true,
					'display_field' =>false
				),
				'mobile' => array(
					'type' => 'text',
					'table_heading' => 'Mobile No.',
					'search_field' => true,
					'display_field' =>false
				),
				'roles_id' =>array(
					'type'=>'select',
					'table_heading' =>'Roles',
					'search_field' => true,
					'display_field' =>true,
					'option'=>$roles_option
				),
				'status' => array(
					'type' => 'select',
					'table_heading' => 'Status',
					'search_field' => true,
					'display_field' =>true,
					'option' =>array('0'=>'In-Active','1'=>'Active')
				),
				'created_by' =>array(
					'type'=>'select',
					'table_heading' =>'Created By',
					'search_field' => true,
					'display_field' =>true,
					'option'=>$created_by_option
				),
				'updated_by' =>array(
					'type'=>'select',
					'table_heading' =>'Updated By',
					'search_field' => true,
					'display_field' =>true,
					'option'=>$created_by_option
				),
				'created_date'=>array(
					'type'=>'date',
					'table_heading' =>'Created Date',
					'search_field' => true,
					'display_field' =>true,
					'format'=>"date('m/d/Y',strtotime('~created_date~'))"
				),
				'update_date'=>array(
					'type'=>'date',
					'table_heading' =>'Updated Date',
					'search_field' => true,
					'display_field' =>true,
					'format'=>"date('m/d/Y',strtotime('~update_date~'))"
				),
				// 'created_date'=>array(
				// 	'type'=>'date',
				// 	'table_heading' =>'Created Date',
				// 	'search_field' => true,
				// 	'display_field' =>true,
				// 	'format'=>"\"<a href='~mobile~'>\".date('Y-m-d',strtotime('~created_date~')).\"</a>\""
				// ),

		);
		$this->generate_table->set_field_list($field_list);
		$field_action = array('view','edit','delete','add');
		$this->generate_table->set_field_action($field_action);

		// $custom_field_action = array('<a href="'.base_url().'employees/id" class="btn btn-info btn-icon-only btn-transparent btn-circle" title="Access"><i class="fa fa-universal-access" aria-hidden="true"></i></a>'); 
		// $this->generate_table->set_custom_field_action($custom_field_action);

		// $bulk_action = array('delete'=>array('title'=>'Delete','url'=>'employees/delete'));
		// $this->generate_table->set_bulk_action($bulk_action);		

		$data = $this->generate_table->get_table();
		$data['title']='Employees';
		$data['page']='Employees';
		if($this->input->post()){
			echo json_encode($data);
			exit;
		}else{
			$data['base_url']=$base_url;
			$data['per_page']=$per_page;
			
			$this->load->view('admin/header',$data);
			$this->load->view('admin/side_menu');
			$this->load->view('admin/table_view');
			$this->load->view('admin/footer');
		}
	}

	/*function edit(){
		$roles = $this->auth->get_data('roles','id,roles_name');
		$roles_option =array();
		if(!empty($roles)){
			foreach($roles as $row){
				$roles_option[$row['id']] = $row['roles_name']; 
			}	
		}

		$created_by = $this->auth->get_data('user','id,first_name,last_name');
		$created_by_option =array();
		if(!empty($created_by)){
			foreach($created_by as $row){
				$created_by_option[$row['id']] = $row['first_name'].' '.$row['last_name']; 
			}	
		}

		$this->load->library('generate_form');
		$field_list = array(
				'id' =>array(
					'type'=>'number',
					'field_heading' =>'ID',
				),
				'profile_pic'=>array(
					'type'=>'hidden',
					'field_heading' =>'Profile Pic.'
				),
				'username' => array(
					'type' => 'text',
					'field_heading' => 'User Name'
				),
				'email' => array(
					'type' => 'text',
					'field_heading' => 'Email'
				),
				'mobile' => array(
					'type' => 'text',
					'field_heading' => 'Mobile No.',
				),
				'roles' =>array(
					'type'=>'select',
					'field_heading' =>'Roles',
					'option'=>$roles_option
				),
				'status' => array(
					'type' => 'select',
					'field_heading' => 'Status',
					'option'=>$roles_option
				),
				'created_by' =>array(
					'type'=>'select',
					'field_heading' =>'Created By',
					'option'=>$created_by_option
				),
				'created_date'=>array(
					'type'=>'date',
					'field_heading' =>'Created Date'
				),
				'update_date'=>array(
					'type'=>'date',
					'field_heading' =>'Updated Date'
				)
		);
		$this->generate_form->set_field_list();

		$this->load->view('admin/header',$data);
		$this->load->view('admin/side_menu');
		$this->load->view('admin/form_view');
		$this->load->view('admin/footer');
	}*/

	function edit($type = null){
		$this->load->library('form_validation');

		$data['roles'] = $this->auth->get_data('roles','id,roles_name','','','order by roles_name asc');
		$data['country'] = $this->auth->get_data('country','id,country_name','status="1"','','order by country_name asc');
		//$data['state'] = $this->auth->get_data('state','id,state_name','status="1"','','order by state_name asc');
		//$data['city'] = $this->auth->get_data('city','id,city_name','status="1"','','order by city_name asc');

		$primary_id = $this->uri->segment(3);
		$data['get_data'] = array();
		$data['errors'] = '';
		if($this->input->post()){
			$this->form_validation->set_rules('id','ID','trim|xss_clean');
			$this->form_validation->set_rules('first_name','First Name','trim|xss_clean|required|min_length[2]|max_length[20]|callback_alpha_dash_space');
			$this->form_validation->set_rules('last_name','Last Name','trim|xss_clean|required|min_length[2]|max_length[20]|callback_alpha_dash_space');
			$this->form_validation->set_rules('gender','Gender','trim|xss_clean|required');
			$this->form_validation->set_rules('dob','DOB','trim|xss_clean');
			$this->form_validation->set_rules('email','Email Id','trim|xss_clean|required|valid_email|callback_check_email['.$this->input->post('id').']');
			$this->form_validation->set_rules('mobile','Mobile No.','trim|xss_clean|required|min_length[10]|max_length[10]|numeric');
			$this->form_validation->set_rules('address','Street','trim|xss_clean|required|min_length[10]|max_length[100]');
			$this->form_validation->set_rules('country_id','Country','trim|xss_clean|required|numeric');
			$this->form_validation->set_rules('state_id','State','trim|xss_clean|required|numeric');
			$this->form_validation->set_rules('city_id','City','trim|xss_clean|required|numeric');
			$this->form_validation->set_rules('postcode','Pincode','trim|xss_clean|required|min_length[6]|max_length[6]|numeric');
			$this->form_validation->set_rules('username','User Name','trim|xss_clean|required|min_length[6]|max_length[20]|callback_check_username['.$this->input->post('id').']');

			$this->form_validation->set_rules('profile_pic','Profile Pic.','trim|xss_clean');
			$this->form_validation->set_rules('profile_img','Profile Pic.','trim|xss_clean');
			
			if($type == 'add'){
				$this->form_validation->set_rules('password','Password','trim|xss_clean|required|min_length[8]|max_length[16]');
				$this->form_validation->set_rules('cfm_password','Confirm Password','trim|xss_clean|required|min_length[8]|max_length[16]|matches[password]');
			}
			$this->form_validation->set_rules('roles_id','Roles','trim|xss_clean|required');
			$this->form_validation->set_rules('status','Status','trim|xss_clean|required');

			if($this->form_validation->run() == false){
				$data['errors'] = $this->form_validation->geterror_array();
				$this->form_validation->unseterror_array();
			}else{

				$upload_image = $this->upload_image();
				if(!$upload_image){
					$data['errors'] = $_POST['error'];
					unset($_POST['error']);
				}else{
					$data_arr = array(
						'id' => $this->form_validation->set_value('id'),
						'first_name'=> $this->form_validation->set_value('first_name'),
						'last_name'=> $this->form_validation->set_value('last_name'),
						'gender'=> $this->form_validation->set_value('gender'),
						'dob'=> $this->form_validation->set_value('dob'),
						'email'=> $this->form_validation->set_value('email'),
						'mobile'=> $this->form_validation->set_value('mobile'),
						'address'=> $this->form_validation->set_value('address'),
						'country_id'=> $this->form_validation->set_value('country_id'),
						'state_id'=> $this->form_validation->set_value('state_id'),
						'city_id'=> $this->form_validation->set_value('city_id'),
						'postcode'=> $this->form_validation->set_value('postcode'),
						'username'=> $this->form_validation->set_value('username'),
						'profile_pic' => $_POST['profile_dp'],
						'roles_id'=> $this->form_validation->set_value('roles_id'),
						'user_type' => '1',
						'status'=> $this->form_validation->set_value('status')
					);

					if($type == 'add'){
						$data_arr = array_merge($data_arr,array('password' => md5($this->form_validation->set_value('password'))));
					}

					$result = $this->auth->save_data('user',$data_arr);
					if($result == 'update_data'){
						$this->session->set_userdata('status_msg', 'update_success');	
						redirect('employees','refresh');
					}else if($result == 'already_update_data'){
						$this->session->set_userdata('status_msg', 'already_update_success');	
						redirect('employees','refresh');
					}else if($result > 0){
						$this->session->set_userdata('status_msg', 'insert_success');	
						redirect('employees','refresh');
					}else{
						$this->session->set_userdata('status_msg', 'error');
						redirect('employees','refresh');	
					}
				}
			}
		}else{
			$data['get_data'] = $this->auth->get_data_by_id($primary_id,'user','id,username,email,first_name,last_name,mobile,gender,profile_pic,roles_id,dob,address,city_id,state_id,country_id,postcode,last_password_change_date,status');
		}
		$data['type'] = $type;
		$data['title'] = 'Employee Detail';
		$data['page']='Employees';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/side_menu');
		$this->load->view('admin/employees_form_view');
		$this->load->view('admin/footer');

	}

	function alpha_dash_space($field){
		if (! preg_match('/^[a-zA-Z\s]+$/', $field)) {
		$this->form_validation->set_message('alpha_dash_space', 'The %s field may only contain alpha characters & White spaces');
		return FALSE;
		} else {
		return TRUE;
		}
	}

	function check_username($username,$id){
		if(!empty($id)){
			$result = $this->auth->get_row_data('user','username','id='.$id);
			if($result){
				if($username != $result['username']){
					$this->form_validation->set_message('check_username','The username is not valid!');
					return false;
				}
			}
			return true;
		}else{
			$result = $this->auth->get_row_data('user','username');
			if($result){
				if($username == $result['username']){
					$this->form_validation->set_message('check_username','The username is already exit!, Please enter another username.');
					return false;
				}
			}
			return true;
		}
	}

	function check_email($email,$id){
		if(!empty($id)){
			$result = $this->auth->get_row_data('user','email','id='.$id);
			if($result){
				if($email != $result['email']){
					$this->form_validation->set_message('check_email','The email id is not valid!');
					return false;
				}
			}
			return true;
		}else{
			$result = $this->auth->get_row_data('user','email');
			if($result){
				if($email == $result['email']){
					$this->form_validation->set_message('check_email','The email id is already exit!, Please enter another email id.');
					return false;
				}
			}
			return true;
		}
	}

	function upload_image(){
        
		$profile_img=$this->input->post('profile_img');

        if(isset($_FILES['profile_pic']) && !empty($_FILES['profile_pic']['name'])){

			$arr=$_FILES['profile_pic']['name'];
			$path_parts = pathinfo($arr);
			$ext=$path_parts['extension'];			 

			$_FILES['profile_pic']['name']=rand().'.'.$ext;

			$config['upload_path'] = 'upload/profile_pic';
        	$config['allowed_types'] = 'gif|png|jpg|jpeg';
        	//$config['encrypt_name'] = TRUE;

        	$this->load->library('upload', $config);

            if($this->upload->do_upload('profile_pic')){
                $link=$config['upload_path'].'/'.$_FILES['profile_pic']['name'];
                $_POST['profile_dp'] = $link;

                if($profile_img!=" " && $profile_img!="" && $profile_img!=null){
				
					if(file_exists($profile_img)){
						chmod($profile_img, 0777);
						unlink($profile_img);
					}
				}

                return true;
            }else{
                $_POST['error'] = array('profile_pic'=>$this->upload->display_errors());
                return false;
            }
        }else{
            $link=$profile_img;
            $_POST['profile_dp'] = $link;
            return true;
        }
    }

	function add(){
		$this->edit('add');	
	}

	function view(){
		$this->edit('view');	
	}

	function delete(){
		if(isset($_POST) && count($_POST)>0){
			$id = $_POST['id'];
			$where = 'id='.$id;
			$data = $this->auth->delete_data('user',$where);
			echo $data;
		}
	}

	function  pdf(){
		echo 'You are in pdf';

	}

	function  excel(){
		echo 'You are in pdf';

	}




}