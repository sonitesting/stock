<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Menu_category extends CI_Controller{

	function __Construct(){
		parent::__construct();

		$this->load->library('auth');
		if(!$this->auth->is_logged_in()){
			redirect('login','refresh');
		}
	}

	function _remap($method, $params=array())
    {	
        $methodToCall = method_exists($this, $method) ? $method : 'index';
        return call_user_func_array(array($this, $methodToCall), $params);
    }

	function index(){
		
		$created_by = $this->auth->get_data('user','id,first_name,last_name','user_type="1"','','order by first_name asc');
		$created_by_option =array();
		if(!empty($created_by)){
			foreach($created_by as $row){
				$created_by_option[$row['id']] = $row['first_name'].' '.$row['last_name']; 
			}	
		}

		$base_url = base_url().'menu_category';
		$segment = 2;
		$per_page = 10;

		$this->load->library('generate_table');
		$this->generate_table->set_table_name('menu_category');
		$this->generate_table->set_order_by('id:desc');
		$this->generate_table->set_pagination_url($base_url);
		$this->generate_table->set_per_page($per_page);
		$this->generate_table->set_uri_segment($segment);
		$this->generate_table->set_table_caption('Menu Category');
		$field_list = array(
				'id' =>array(
					'type'=>'number',
					'table_heading' =>'ID',
					'search_field' => true,
					'display_field' =>false,
				),
				'menu_cat_name' => array(
					'type' => 'text',
					'table_heading' => 'Menu Name',
					'search_field' => true,
					'display_field' =>true,
				),
				'created_by' =>array(
					'type'=>'select',
					'table_heading' =>'Created By',
					'search_field' => true,
					'display_field' =>true,
					'option'=>$created_by_option
				),
				'Updated_by' =>array(
					'type'=>'select',
					'table_heading' =>'Updated By',
					'search_field' => true,
					'display_field' =>true,
					'option'=>$created_by_option
				),
				'created_date'=>array(
					'type'=>'date',
					'table_heading' =>'Created Date',
					'search_field' => true,
					'display_field' =>true,
					'format'=>"date('m/d/Y',strtotime('~created_date~'))"
				),
				'update_date'=>array(
					'type'=>'date',
					'table_heading' =>'Updated Date',
					'search_field' => true,
					'display_field' =>true,
					'format'=>"date('m/d/Y',strtotime('~update_date~'))"
				),
				'status' => array(
					'type' => 'select',
					'table_heading' => 'Status',
					'search_field' => true,
					'display_field' =>true,
					'option' =>array('0'=>'In-Active','1'=>'Active')
				),
		);
		$this->generate_table->set_field_list($field_list);
		$field_action = array('view','edit','delete','add');
		$this->generate_table->set_field_action($field_action);

		$data = $this->generate_table->get_table();
		$data['title']='Menu Category';
		$data['page']='Menu_category';
		if($this->input->post()){
			echo json_encode($data);
			exit;
		}else{
			$data['base_url']=$base_url;
			$data['per_page']=$per_page;
			
			$this->load->view('admin/header',$data);
			$this->load->view('admin/side_menu');
			$this->load->view('admin/table_view');
			$this->load->view('admin/footer');
		}
	}

	function edit($type = null){
		$this->load->library('form_validation');

		$primary_id = $this->uri->segment(3);
		$data['get_data'] = array();
		$data['errors'] = '';
		if($this->input->post()){
			$this->form_validation->set_rules('id','ID','trim|xss_clean');
			$this->form_validation->set_rules('menu_cat_name','Menu Name','trim|xss_clean|required|min_length[2]|max_length[50]');
			$this->form_validation->set_rules('menu_icon','Menu Icon','trim|xss_clean|required|');
			$this->form_validation->set_rules('status','Status','trim|xss_clean|required');

			if($this->form_validation->run() == false){
				$data['errors'] = $this->form_validation->geterror_array();
				$this->form_validation->unseterror_array();
			}else{
				$data_arr = array(
					'id' => $this->form_validation->set_value('id'),
					'menu_cat_name'=> $this->form_validation->set_value('menu_cat_name'),
					'menu_icon' => $this->form_validation->set_value('menu_icon'),
					'status'=> $this->form_validation->set_value('status')
				);
				$result = $this->auth->save_data('menu_category',$data_arr);
				if($result == 'update_data'){
					$this->session->set_userdata('status_msg', 'update_success');	
					redirect('menu_category','refresh');
				}else if($result == 'already_update_data'){
					$this->session->set_userdata('status_msg', 'already_update_success');	
					redirect('menu_category','refresh');
				}else if($result > 0){
					$this->session->set_userdata('status_msg', 'insert_success');	
					redirect('menu_category','refresh');
				}else{
					$this->session->set_userdata('status_msg', 'error');
					redirect('menu_category','refresh');	
				}
			}
		}else{
			$data['get_data'] = $this->auth->get_data_by_id($primary_id,'menu_category','id,menu_cat_name,menu_icon,status');
		}
		$data['type'] = $type;
		$data['title'] = 'Menu Category Detail';
		$data['page']='Menu_category';
		$this->load->view('admin/header',$data);
		$this->load->view('admin/side_menu');
		$this->load->view('admin/menu_category_form_view');
		$this->load->view('admin/footer');

	}

	function add(){
		$this->edit('add');	
	}

	function view(){
		$this->edit('view');	
	}

	function delete(){
		if(isset($_POST) && count($_POST)>0){
			$id = $_POST['id'];
			$where = 'id='.$id;
			$data = $this->auth->delete_data('menu_category',$where);
			echo $data;
		}
	}
}