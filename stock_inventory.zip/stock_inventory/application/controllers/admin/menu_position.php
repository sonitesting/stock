<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class menu_position extends CI_Controller{

	function __Construct(){
		parent::__construct();

		$this->load->library('auth');
		if(!$this->auth->is_logged_in()){
			redirect('login','refresh');
		}
	}

	function _remap($method, $params=array())
    {	
        $methodToCall = method_exists($this, $method) ? $method : 'index';
        return call_user_func_array(array($this, $methodToCall), $params);
    }

	function index(){

		$menu_list = $this->auth->get_data('controllerlist','controllerlist.id,controllerlist.ctl_menu_position,controllerlist.controllername,parent,controllerlist.menu_name,controllerlist.action_id,controllerlist.menu_category_id,controllerlist.url,menu_category.menu_cat_name,menu_category.menu_icon,controllerlist.ctl_menu_icon,controllerlist.page_active_title','controllerlist.status="1" AND controllerlist.menu_type="1" AND controllerlist.menu_category_id!=0','left JOIN menu_category on menu_category.id=controllerlist.menu_category_id','order by controllerlist.ctl_menu_position asc');

			//print'<pre>';print_r($menu_list);exit;
		$data['menu_list'] = $menu_list;
		$data['title'] = 'Menu Position';
		$data['page'] ="menu_position";
 			$this->load->view('admin/header',$data);
			$this->load->view('admin/side_menu');
			$this->load->view('admin/menu_position_view');
			$this->load->view('admin/footer');
		
	}

	function position_level(){
		
		if((isset($_POST['id']) && $_POST['id']) && (isset($_POST['position']) && $_POST['position'])){
			//echo $_POST['id'].'====='.$_POST['position'];exit;
			$position = $this->db->query('select ctl_menu_position from controllerlist where id='.$_POST['id'].' limit 1');
			$position = $position->row_array();
			if($_POST['position'] == 'down'){

				$position_down = $position['ctl_menu_position']+1;

				$position_up_id = $this->db->query('select id from controllerlist where ctl_menu_position='.$position_down.' limit 1');
				$position_up_id = $position_up_id->row_array();
				$position_up = $position['ctl_menu_position'];

				$this->auth->update_data('controllerlist','ctl_menu_position='.$position_up,'id='.$position_up_id['id']);

				$result = $this->auth->update_data('controllerlist','ctl_menu_position='.$position_down,'id='.$_POST['id']);

				echo $result;exit;
			}

			if($_POST['position'] == 'up'){

				//echo 'current position =='.$position['ctl_menu_position'];
				$position_up = $position['ctl_menu_position']-1;
				//echo '---------------position_up == '.$position_up;
				$position_down_id = $this->db->query('select id from controllerlist where ctl_menu_position='.$position_up.' limit 1');
				$position_down_id = $position_down_id->row_array();
				//echo '---------------position_down_id == '.$position_down_id['id'];


				$position_down = $position['ctl_menu_position'];

				//echo '---------------position_down == '.$position_down;
				$this->auth->update_data('controllerlist','ctl_menu_position='.$position_down,'id='.$position_down_id['id']);
				//echo '---------------';
				$result = $this->auth->update_data('controllerlist','ctl_menu_position='.$position_up,'id='.$_POST['id']);

				echo $result;exit;
			}

			echo false;exit;

		}else if((isset($_POST['current_position']) && $_POST['current_position']) && (isset($_POST['set_position']) && $_POST['set_position'])){
			//echo $_POST['id'].'====='.$_POST['position'];exit;

			$current_position = $_POST['current_position'];
			$set_position = $_POST['set_position'];


			$current_position_id = $this->db->query('select id from controllerlist where ctl_menu_position='.$current_position.' limit 1');
			$current_position_id = $current_position_id->row_array();


			$set_position_id = $this->db->query('select id from controllerlist where ctl_menu_position='.$set_position.' limit 1');
			$set_position_id = $set_position_id->row_array();

			$this->auth->update_data('controllerlist','ctl_menu_position='.$current_position,'id='.$set_position_id['id']);

			$result = $this->auth->update_data('controllerlist','ctl_menu_position='.$set_position,'id='.$current_position_id['id']);
			
			echo $result;exit;

		}
		echo false;exit;
	}

}