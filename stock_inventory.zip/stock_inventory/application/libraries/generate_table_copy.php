<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Generate_table
{
    protected $ci;
    var $table_name = '';
    var $order_by = '';
    var $group_by = '';
    var $pagination_url = '';
    var $per_page = 10;
    var $offset = 3;
    var $uri_segment = 3;
    var $table_caption = 'Table Name';
    var $field_name = array();
    var $field_action = array();
    var $table_heading = '';
    var $field_list = '';
    var $field_list_count = '';
    var $display_list_count = '';
    var $field_list_arr = '';
    var $display_field = array();
    var $display_field_action = array();
    var $option_field = array();
    var $field_action_add = '';
    var $field_format = array();
    var $custom_field_action = array();
    var $bulk_action = '';
    var $controllername='';
    var $functionname ='';
    var $where = '';
    function __Construct()
    {
        $this->ci =& get_instance();
        $this->ci->load->library('session');
        $this->ci->load->library('auth');
        $this->ci->load->library('form_validation');
        $this->controllername = strtolower(trim($this->ci->router->fetch_class()));
        $this->functionname = strtolower(trim($this->ci->router->fetch_method()));

    }
    function set_table_name($table_name)
    {
        $this->table_name = $table_name;
    }
    function set_where($where){
        $this->where= $where;
    }
    function set_order_by($order_by){
        if(!empty($order_by)){
            $str = $str1 = '';
            $order = explode(',',$order_by);
            if(!empty($order)){
                foreach($order as $key=>$value){
                    $order1 = explode(':',$value);
                    if(!empty($order1)){
                        foreach($order1 as $key1=>$value1){
                            $str .= $value1.' ';
                        }
                        $str .= ',';
                    }
                }
                if(!empty($str)){
                    $str1 = ' Order by '.trim(rtrim($str,',')).' ';    
                }
                
            }
            //$order1 = explode(':',$order);
        }
        $this->order_by = $str1;
    }
    function set_group_by($group_by){
        if(!empty($group_by)){
            $str = 'Group by '.$group_by.' ';
        }
        $this->group_by = $str;
    }

    function set_pagination_url($pagination_url)
    {
        $this->pagination_url = trim($pagination_url);
    }
    function set_per_page($per_page)
    {
        $this->per_page = (int) $per_page;
    }
    function set_uri_segment($uri_segment)
    {   
        $offset = $this->ci->uri->segment((int) $uri_segment);
        if(!empty($offset) && $offset > 0){
            $this->offset = $offset;
        }else{
            $this->offset = 0;
        }
        $this->uri_segment = (int) $uri_segment;
    }
    function set_table_caption($table_caption)
    {
        $this->table_caption = $table_caption;
    }
    function set_field_list($field_list)
    {
        if (is_array($field_list) && !empty($field_list)) {
            $attch_name       = $this->table_name;
            $field_name       = array();
            $array_list       = '';
            $table_heading    = array();
            $field_list_data  = '';
            $field_list_count = 0;
            $count            = 0;
            $field_list_arr   = array();
            $display_field    = array();
            $option_field     = array();
            $field_format     = array();
            foreach ($field_list as $key => $value) {
                if (!in_array($key, $field_name)) {
                    $field_name[$count] = $key;
                }
                $attr = $key . '-' . $attch_name;
                if (!in_array($attr, $field_list_arr)) {
                    if (array_key_exists('type', $value)) {
                        if ($value['type'] == 'date') {
                            $field_list_arr[] = 'from_dta_' . $key . '-' . $attch_name;
                            $field_list_arr[] = 'to_dta_' . $key . '-' . $attch_name;
                        } else {
                            $field_list_arr[$count] = $attr;
                        }
                    } else {
                        $field_list_arr[$count] = $attr;
                    }
                }
                $field                               = '--';
                $array_list[$count]['display_field'] = (array_key_exists('display_field', $value) ? $value['display_field'] : '');
                if ($array_list[$count]['display_field']) {
                    if (!in_array($key, $display_field)) {
                        $display_field[$count] = $key;
                    }
                    $array_list[$count]['table_heading'] = (array_key_exists('table_heading', $value) ? $value['table_heading'] : '');
                    $array_list[$count]['width']         = (array_key_exists('width', $value) ? $value['width'] : '');
                    $table_heading[$count]['data']       = $array_list[$count]['table_heading'];
                    //$table_heading[$count]['width']      = $array_list[$count]['width'];
                    $option                              = '';
                    $field_list_count++;
                    if (array_key_exists('option', $value) && !empty($value['option']) && $value['type'] == 'select') {
                        $option_field[$key] = $value['option'];
                        foreach ($value['option'] as $op_key => $op_value) {
                            if ((isset($this->ci->session->userdata['search_field'][$attr])) && ((string) $this->ci->session->userdata['search_field'][$attr] === (string) $op_key)) {
                                $selected_value = 'selected="selected"';
                            } else {
                                $selected_value = '';
                            }
                            $option .= "<option value='" . $op_key . "' " . $selected_value . ">" . $op_value . "</option>";
                        }
                    }
                    if (array_key_exists('format', $value) && !empty($value['format'])) {
                        $field_format[$key] = $value['format'];
                    }
                    $array_list[$count]['search_field'] = (array_key_exists('search_field', $value) ? $value['search_field'] : '');
                    if ($array_list[$count]['search_field']) {
                        if (array_key_exists('type', $value)) {
                            $type = $value['type'];
                            if ($type == 'text') {
                                $field = '<input type="text" autocomplete="off" name="' . $attr . '" id="' . $attr . '" class="form-control form-filter input-md" value="' . (isset($this->ci->session->userdata['search_field'][$attr]) ? $this->ci->session->userdata['search_field'][$attr] : '' ). '" placeholder="' . $array_list[$count]['table_heading'] . '" style="min-width: 103px;">';
                            }
                            if ($type == 'number') {
                                $field = '<input type="number" autocomplete="off" name="' . $attr . '" id="' . $attr . '" class="form-control form-filter input-md" value="' . (isset($this->ci->session->userdata['search_field'][$attr]) ? $this->ci->session->userdata['search_field'][$attr] : '' ) . '" style="min-width: 81px;" placeholder="' . $array_list[$count]['table_heading'] . '">';
                            }
                            if ($type == 'select') {
                                $field = '<select name="' . $attr . '" id="' . $attr . '" class="form-control input-md form-filter" style="min-width: 103px;"><option value="">Select</option>' . $option . '</select>';
                            }
                            if ($type == 'date') {
                                $field = '
                                <div class="margin-bottom-5 input-group date date-picker">
                                    <input type="text" autocomplete="off" name="from_dta_' . $attr . '" id="from_dta_' . $attr . '" class="form-control form-filter input-md" readonly value="' . (isset($this->ci->session->userdata['search_field']['from_dta_' . $attr]) ? $this->ci->session->userdata['search_field']['from_dta_' . $attr] :'' ). '" placeholder="From" style="min-width: 103px;">
                                    <span class="input-group-btn">
                                        <button type="button" class="btn btn-md default">
                                            <i class="fa fa-calendar"></i>
                                        </button>
                                    </span>
                                </div>
                                <div class="input-group date date-picker">
                                    <input type="text" autocomplete="off" name="to_dta_' . $attr . '" id="to_dta_' . $attr . '" class="form-control form-filter input-md" readonly value="' . ( isset($this->ci->session->userdata['search_field']['to_dta_' . $attr]) ? $this->ci->session->userdata['search_field']['to_dta_' . $attr] : ''). '" placeholder="To" style="min-width: 103px;">
                                    <span class="input-group-btn">
                                        <button type="button" class="btn btn-md default">
                                            <i class="fa fa-calendar"></i>
                                            </button>
                                    </span>
                                </div>';
                            }
                        }
                    }
                    $array_list[$count]['type'] = $field;
                    $field_list_data[]['data']  = $array_list[$count]['type'];
                }
                $count++;
            }
            $this->field_name         = $field_name;
            $this->field_list_arr     = $field_list_arr;
            $this->table_heading      = $table_heading;
            $this->field_list         = $field_list_data;
            $this->field_list_count   = $field_list_count;
            $this->display_list_count = count($display_field);
            $this->display_field = $display_field;
            if (!in_array($field_name[0], $display_field)) {
                array_unshift($display_field, $field_name[0]);
            }
            $this->display_field_action = $display_field;
            $this->option_field  = $option_field;
            $this->field_format  = $field_format;
           // print'<pre>';print_r($field_format);exit;
        }
    }
    function set_field_action($field_action)
    {
        $default_field_action = array(
            'add',
            'view',
            'edit',
            'delete',
            'download',
            'pdf',
            'excel'
        );

        $action = array();
        if (!empty($field_action)) {
            foreach ($field_action as $key => $value) {
                if (in_array($value, $default_field_action)) {
                    if ($value == 'add') {
                        $this->field_action_add = $this->action($value,'',$this->controllername);
                    } else {
                        $action[] = $value;
                    }
                }
            }
        }
        $this->field_action = $action;
    }
    function set_custom_field_action($custom_field_action)
    {
        $this->custom_field_action = $custom_field_action;
    }
    function set_bulk_action($bulk_action){
        if(!empty($bulk_action) && is_array($bulk_action)){
            $selection = '<select class="form-control input-md form-filter" id="bulk_action" style="max-width: 132px;text-overflow: ellipsis;float:left;margin-right:10px;">';
            $selection .= '<option value="">Select Action</option>';
            foreach($bulk_action as $key=>$value){
                if(!empty($value) && is_array($value)){
                    $selection .= '<option value="'.(isset($value['url']) && !empty($value['url']) ? $value['url'] : '').'">'.(isset($value['title']) && !empty($value['title']) ? ucwords($value['title']) : ucwords($key)).'</option>';
                }else{
                    $selection .= '<option value="">'.ucwords($key).'</option>';
                }
            }
            $selection .= '</select>';
            $this->bulk_action=$selection;    
        }
    }
    function get_table()
    {
        $data           = '';
        $field_search   = '';
        $field_name     = $this->field_name;
        $table_name     = $this->table_name;
        $field_list_arr = $this->field_list_arr;
        if ($this->ci->input->post()) {
            if ($this->ci->input->post('type') == 'reset') {
                foreach ($field_list_arr as $key => $value) {
                    $this->ci->session->unset_userdata('search_field');
                }
                return true;
            } else {
                foreach ($this->ci->input->post() as $key => $value) {
                    if (in_array($key, $field_list_arr))
                        $field_search[$key] = $this->xss_clean($value);
                }
            }
        } else {
            foreach ($field_list_arr as $key => $value) {
                $field_search[$value] = (isset($this->ci->session->userdata['search_field'][$value]) && $this->ci->session->userdata['search_field'][$value] != '' ? $this->xss_clean($this->ci->session->userdata['search_field'][$value]) : '');
            }
        }
        $where = $this->get_search_fliter_query($field_search, $field_list_arr);

        if(empty($where)){
            $where = $this->where;
        }else if(!empty($this->where)){
            $where .= ' AND '.$this->where;
        }
        $this->ci->load->library('pagination');
        $config['base_url']    = $this->pagination_url;
        $offset                = $this->offset;
        $total_data            = $config['total_rows'] = $this->ci->auth->get_total_count($table_name, $where);
        $limit                 = $config['per_page'] = $this->per_page;
        $config['num_links']   = 4;
        $config['uri_segment'] = $this->uri_segment;
        $this->ci->pagination->initialize($config);
        $select          = implode(',', $field_name);

        $offest_cnt = 0;
        $offset_arr = array();
        $per_page_data = $total_data; 
        offsetreturn:
        $per_page_data =  $per_page_data - $this->per_page;
        if($per_page_data >= 0){
            $offset_arr[] = $offest_cnt;
            $offest_cnt += $this->per_page;
            goto offsetreturn; 
        }
        $offset_arr[] = $offest_cnt;

        if(!in_array($offset, $offset_arr)){
            $offset = 0;
        }

        resetoffset:
        $extra_condition = $this->group_by.$this->order_by.'limit ' . $offset . ',' . $limit;
        $array_data      = $this->ci->auth->get_data($table_name, $select, $where, '', $extra_condition);
        if(empty($array_data) && $offset > 0){
            $offset = $offset - $offset;
            goto resetoffset;
        }
        $data['links']   = $links = $this->ci->pagination->create_links();
        $this->ci->load->library('table');
        $template = array(
            'table_open' => '<table border="1" cellpadding="2" cellspacing="1" class="table table-bordered table-striped" id="table_' . $this->table_name . '" style="white-space: nowrap;">'
        );
        $this->ci->table->set_template($template);
        $this->ci->table->set_caption($this->table_caption);
        $this->ci->table->set_field_action_add($this->field_action_add);
        $this->ci->table->set_total_data($total_data);
        $this->ci->table->set_pagination($links);
        $this->ci->table->set_bulk_action($this->bulk_action);


        $table_heading_first = array(
            'data' => 'Sr. No.',
            'width' => '10%'
        );
        array_unshift($this->table_heading, $table_heading_first);
        $table_heading_last = array(
            'data' => 'Action',
            'width' => ''
        );
        array_push($this->table_heading, $table_heading_last);
        $this->ci->table->set_heading($this->table_heading);
        $select_all_checkbox = (!empty($this->bulk_action) ? '<input type="checkbox" id="select_all_' . $this->table_name . '" name="select_all_' . $this->table_name . '" onclick="checkUncheckAll(this,\'' . $this->table_name . '\');">&nbsp;&nbsp;#' : '#');
        $input_sr = array(
            'data' => $select_all_checkbox
        );
        array_unshift($this->field_list, $input_sr);
        if (!empty($this->field_list_count)) {
            $input_action = array(
                'data' => '  <div class="btn-group btn-group-devided" data-toggle="buttons">
    <input type="button" class="searching btn btn-success btn-md btn-transparent btn-circle" value="Search" style="margin-right:5px;"/> <input type="button" value="Reset" class="btn btn-info btn-md btn-transparent btn-circle" id="reset"/></div>'
            );
        } else {
            $input_action = array(
                'data' => '--'
            );
        }
        array_push($this->field_list, $input_action);
        $this->ci->table->add_row($this->field_list);
        $this->ci->table->add_row_class('search_field filter');
        if (!empty($array_data)) {
            $count = 1;
            foreach ($array_data as $row) {
                $column_field = array();
                foreach ($row as $key => $value) {
                    if (in_array($key, $this->display_field)) {
                        if (array_key_exists($key, $this->option_field)) {
                            $opt_value_value = '--';
                            if (in_array($value, array_flip($this->option_field[$key]))) {
                                $opt_value_value = $this->option_field[$key][$value];
                                if (array_key_exists($key, $this->field_format)) {
                                    $opt_value_value1 = $this->field_format[$key];
                                    foreach ($array_data[$count - 1] as $a_key => $a_value) {
                                        if (array_key_exists($a_key, $this->option_field)){
                                            if (in_array($a_value, array_flip($this->option_field[$a_key]))){
                                                $opt_val = $this->option_field[$a_key][$a_value];
                                            $opt_value_value1 = preg_replace('/~' . $a_key . '~/', $opt_value_value1, $opt_value_value1);
                                            }
                                        }
                                        $opt_value_value1 = preg_replace('/~' . $a_key . '~/', $a_value, $opt_value_value1);
                                    }

                                    $opt_value_value = $opt_value_value1;
                                }
                            }
                            $column_field[] = array(
                                'data' => $opt_value_value
                            );
                        } else {
                            if (array_key_exists($key, $this->field_format)) {
                                $value_in_format = $this->field_format[$key];
                                $value_view ='';
                                foreach ($array_data[$count - 1] as $a_key => $a_value) {
                                    $value_in_format = preg_replace('/~' . $a_key . '~/', $a_value, $value_in_format);
                                    
                                }
                                
                                if($value != ''){
                                    eval("\$value_view = ".$value_in_format.";");
                                    if($value_view != ''){
                                        $value = $value_view ;
                                     }else{
                                        $value = $value_in_format;
                                    }
                                }
                            }
                            if($value == ''){
                                $value = '--';
                            }

                            $column_field[] = array('data' => $value);
                        }
                    }
                }
                $select_checkbox = (!empty($this->bulk_action) ? '<input type="checkbox" onclick="checkUnCheckParent(\'' . $this->table_name . '\')" name="check_' . $this->table_name . '" class="bulkaction" value="' . $row[$this->display_field_action[0]] . '">&nbsp;&nbsp;<span class="cnt">' . $count . '</span>' : '<span class="cnt">' . $count . '</span>');
                $sr_field = array(
                    'data' => $select_checkbox
                );
                array_unshift($column_field, $sr_field);
                $action = '';
                foreach ($this->field_action as $key => $value) {
                    $action .= $this->action($value, $row[$this->display_field_action[0]],$this->controllername);
                }
                $custom_field_action = '';
                if (!empty($this->custom_field_action)) {
                    foreach ($this->custom_field_action as $key => $value) {
                        $ctm_field_action = $value;
                        foreach ($array_data[$count - 1] as $a_key => $a_value) {
                            $ctm_field_action = preg_replace('/' . $a_key . '/', $a_value, $ctm_field_action);
                        }
                        $custom_field_action .= $ctm_field_action;
                    }
                }
                $action .= $custom_field_action;
                if (!empty($action)) {
                    $action_field = array(
                        'data' => '  <div class="btn-group-devided"><label class="btn btn-sm">' . $action . '</label></div>'
                    );
                } else {
                    $action_field = array(
                        'data' => '--'
                    );
                }
                array_push($column_field, $action_field);
                $this->ci->table->add_row($column_field);
                $this->ci->table->add_row_class($this->table_name . '_' . $row['id']);
                
                unset($column_field);
                $count++;
            }
        } else {
            $this->ci->table->add_row(array(
                'data' => 'No Record Found!',
                'colspan' => ((int) $this->display_list_count + 2),
                'align' => 'center'
            ));
        }
        $data['table_data']     = $this->ci->table->generate();
        $data['grid_view_temp'] = 1;
        $data['offset'] = $offset;
        $data['urisegment'] = $this->offset;

       // print'<pre>';print_r($data);
        return $data;
    }
    function action($action, $id = null,$controllername = null)
    {
        switch ($action) {
            case 'view':
                if($this->ci->session->userdata['session_action'][$controllername.'_view']){
                    $action_btn = '<a class="btn btn-icon-only yellow btn-transparent btn-circle" href="javascript:;" onclick="action(this)" rel="' . $action . '_' . $id . '" title="View"><i class="fa fa-eye"></i></a>';
                }else{
                     $action_btn = '';
                }
                break;
            case 'edit':
                if($this->ci->session->userdata['session_action'][$controllername.'_edit']){
                $action_btn = '<a class="btn btn-icon-only blue btn-transparent btn-circle" href="javascript:;" onclick="action(this)" rel="' . $action . '_' . $id . '" title="Edit"><i class="fa fa-edit"></i></a>';
                }else{
                     $action_btn = '';
                }
                break;
            case 'delete':
                if($this->ci->session->userdata['session_action'][$controllername.'_delete']){
                $action_btn = '<a class="btn btn-icon-only red btn-transparent btn-circle" href="javascript:;" title="Delete" onclick="action(this)" rel="' . $action . '_' . $id . '"><i class="fa fa-trash-o"></i></a>';
                }else{
                     $action_btn = '';
                }
                break;
            case 'download':
                if($this->ci->session->userdata['session_action'][$controllername.'_download']){
                $action_btn = '<a class="btn btn-icon-only green btn-transparent btn-circle" href="javascript:;" onclick="action(this)" rel="' . $action . '_' . $id . '" title="Download"><i class="fa fa-download"></i></a>';
                }else{
                     $action_btn = '';
                }
                break;
            case 'excel':
                if($this->ci->session->userdata['session_action'][$controllername.'_excel']){
                $action_btn = '<a class="btn btn-icon-only dark btn-transparent btn-circle" href="javascript:;" onclick="action(this)" rel="' . $action . '_' . $id . '" title="Excel"><i class="fa fa-file-excel-o"></i></a>';
                }else{
                     $action_btn = '';
                }
                break;
            case 'pdf':
                if($this->ci->session->userdata['session_action'][$controllername.'_pdf']){
                $action_btn = '<a class="btn btn-icon-only purple btn-transparent btn-circle" href="javascript:;" onclick="action(this)" rel="' . $action . '_' . $id . '" title="PDF"><i class="fa fa-file-pdf-o"></i></a>';
                }else{
                     $action_btn = '';
                }
                break;
            case 'add':
                if($this->ci->session->userdata['session_action'][$controllername.'_add']){
                $action_btn = '<a class="btn btn-info btn-transparent btn-circle" href="javascript:;" onclick="action(this)" rel="' . $action . '" title="Add"><i class="fa fa-plus"></i> Add</a>';
                }else{
                     $action_btn = '';
                }
                break;
            default:
                $action_btn = '';
                break;
        }
        return $action_btn;
    }
    function get_search_fliter_query($field_search = null, $field_list_arr = null)
    {   
        $search_data_arr = $this->ci->session->userdata('search_field');

        if(!empty($search_data_arr)){
            foreach ($search_data_arr as $search_data_key => $search_data_value) {
                $data_arr = explode('-', $search_data_key);
                if(($data_arr[1] != $this->table_name) && isset($this->ci->session->userdata['search_field'][$search_data_key])){
                    unset($this->ci->session->userdata['search_field'][$search_data_key]);
                }
            }
        }

        //$search_data_arr1 = $this->ci->session->userdata('search_field');
        //print'<pre>';print_r($search_data_arr1);exit;


        if($this->ci->input->post()){
            $search_data = '';
            if (!empty($field_search)) {
                foreach ($field_search as $key => $value) {
                    $search_data[$key] = trim($value);
                }
                $this->ci->session->set_userdata('search_field',$search_data);
            } else {
                $search_data = $this->ci->session->userdata('search_field');
            }
            $query = '';
            foreach ($search_data as $field => $value) {
                if (in_array($field, $field_list_arr) && $value != "") {
                    $column_name = explode('-', $field);
                    if (strpos($column_name[0], 'from_dta_') !== false) {
                        $column_name = preg_replace('/from_dta_/', '', $column_name[0]);
                        $column_name = 'date(`' . $column_name . '`)';
                        $value       = date('Y-m-d', strtotime($value));
                        $query .= sprintf('%s >= "%s" AND ', $column_name, $value);
                    } else if (strpos($column_name[0], 'to_dta_') !== false) {
                        $column_name = preg_replace('/to_dta_/', '', $column_name[0]);
                        $column_name = 'date(`' . $column_name . '`)';
                        $value       = date('Y-m-d', strtotime($value));
                        $query .= sprintf('%s <= "%s" AND ', $column_name, $value);
                    } else {
                        $query .= sprintf('`%s` = "%s" AND ', $column_name[0], $value);
                    }
                }
                unset($column_name);
            }
            $arr1 = str_split($query);
            if ($arr[(count($arr1)) - 2] = " AND ") {
                $query = substr($query, 0, (count($arr1)) - 4);
            } else {
                $query = $query;
            }
            return $query;
        }return false;
    }

    function xss_clean($data){
        $data = trim($data);
        return filter_var($data, FILTER_SANITIZE_STRING);
    }


}