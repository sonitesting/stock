<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
define('EMAIL_TOKEN_DATE_VALIDITY', '3');
class auth
{	
	protected $ci;
	
	function __Construct(){
		$this->ci = & get_instance();
		$this->ci->load->library('session');
		$this->ci->load->model('common_query');
		$this->ci->load->helper('url');
	}

	function get_total_count($table_name,$where = null,$join = null){
		return $this->ci->common_query->get_total_count($table_name,$where,$join);
	}

	function get_data($table_name,$select = null,$where = null,$join = null,$extra_condition = null){
		return $this->ci->common_query->get_data($table_name,$select,$where,$join,$extra_condition);
	}

	function get_row_data($table_name,$select = null,$where = null,$join = null,$extra_condition = null){
		return $this->ci->common_query->get_row_data($table_name,$select,$where,$join,$extra_condition);
	}

	function update_data($table_name,$set = null,$where = null,$join = null){
		return $this->ci->common_query->update_data($table_name,$set,$where,$join);
	}

	function save_data($table_name=null,$data =null){
		return $this->ci->common_query->save_data($table_name,$data);
	}

	function delete_data($table_name=null,$where = null){
		return $this->ci->common_query->delete_data($table_name,$where);
	}

	function get_data_by_id($primary_id,$table_name,$select = null,$where = null,$join = null,$extra_condition = null){
		return $this->ci->common_query->get_data_by_id($primary_id,$table_name,$select,$where,$join,$extra_condition);
	}

	function get_spare_data($product_id=null){
		//print('auth');exit;
		return $this->ci->common_query->get_spare_data($product_id);
	}

	function get_spare_amount($spare_id=null){
		//print('auth');exit;
		return $this->ci->common_query->get_spare_amount($spare_id);
	}


	function is_logged_in(){
		if($this->get_user_id()){
			//echo 'hiiiiii';
			//print'<pre>';print_r($this->ci->session->all_userdata());
			
			$where = 'username ="'.$this->get_username().'"';
			$data = $this->ci->common_query->get_data('user','id,username,status,email_token,email_token_date,roles_id,password_token',$where);
			if(!empty($data) && $data[0]['status'] == '0'){
				$this->ci->session->sess_destroy();
				return false;
			}else if(!empty($data) && $data[0]['status'] == '1'){
				$curr_date = date_create(date('Y-m-d'));
				$email_token = $data[0]['email_token'];
				$email_token_date = date_create(date('Y-m-d',strtotime($data[0]['email_token_date'])));
				$days = date_diff($email_token_date,$curr_date);
				$days = $days->format('%a');
				if(!empty($email_token) && $days > EMAIL_TOKEN_DATE_VALIDITY){
					return false;
				}else if(!empty($email_token) && $days <= EMAIL_TOKEN_DATE_VALIDITY){
					return false;
				}
				
				$roles_data = $this->ci->common_query->get_row_data('group_access','group_access.roles_id,group_access.action_list_id,group_access.access_id,group_access.menu_id','group_access.roles_id='.$data[0]['roles_id'].' AND roles.status="1"','join roles on roles.id=group_access.roles_id');
				if(!empty($roles_data)){
					

					if(!empty($roles_data['menu_id'])){

						$main_menu_id = $this->generate_menu($roles_data['menu_id']);
						if(empty($main_menu_id)){
							return false;
						}

						$checkaccess = $this->check_access($roles_data['menu_id'],$roles_data['access_id']);
						if(empty($checkaccess)){
							return false;
						}

						if(!empty($main_menu_id) && !empty($roles_data['action_list_id'])){
							$checkaccess = $this->generate_access_action($main_menu_id,$roles_data['action_list_id']);
						}	

					}else{
						return false;
					}

					
				}else{
					return false;
				}

				
				// if(!$this->ci->session->userdata('url_access_id')){
				// 	//print'<pre>';print_r($this->ci->session->all_userdata());exit;
				// 	$this->ci->session->sess_destroy();
				// 	return false;
				// }else{
				// 	$checkaccess = $this->checkaccess();
				// 	$this->generate_access_action();
				// 	if(!$checkaccess){
				// 	 	return false;
				// 	}
				// 	return true;
				// }

				//print'<pre>';print_r($this->ci->session->all_userdata());
				return true;
			}
			
		}
		//echo 'byyyeeeeee';
		//print'<pre>';print_r($this->ci->session->all_userdata());exit;
		
		return false;
	}

	function get_username(){
		return $this->ci->session->userdata('username');
	}

	function get_user_id(){
		return $this->ci->session->userdata('user_id');
	}

	function generate_menu($menu_id = null){
		if(!empty($menu_id)){
			$menu_list = $this->ci->common_query->get_data('controllerlist c','c.id,c.controllername,c.parent,c.menu_name,c.action_id,c.menu_category_id,c.url,m.menu_cat_name,m.menu_icon,c.ctl_menu_icon,c.page_active_title','c.status="1" AND c.menu_type="1" AND c.id in ('.$menu_id.')','left JOIN menu_category m on m.id=c.menu_category_id','order by c.ctl_menu_position');

			$main_menu_id = array();
			//print'<pre>';print_r($menu_list);exit;
			if(!empty($menu_list)){
				foreach($menu_list as $row){
					if($row['menu_category_id'] != 3 && !empty($row['menu_category_id'])){
						$data[$row['menu_cat_name']]['main_menu']=$row['menu_cat_name'];
						$data[$row['menu_cat_name']]['url']= '';
						$data[$row['menu_cat_name']]['menu_icon']= $row['menu_icon'];
						$data[$row['menu_cat_name']]['sub_menu'][$row['id']]= $row['menu_name'];
						$data[$row['menu_cat_name']]['submenu_url'][$row['id']]= $row['url'];
						$data[$row['menu_cat_name']]['submenu_icon'][$row['id']]= $row['ctl_menu_icon'];
						$data[$row['menu_cat_name']]['page_active_title'][$row['id']]= $row['page_active_title'];
						if(!in_array($row['parent'],$main_menu_id)){
							$main_menu_id[] = $row['parent'];
						}
					}else if($row['menu_category_id'] == 3){
						$data[$row['menu_name']]['main_menu']=$row['menu_name'];
						$data[$row['menu_name']]['url']= $row['url'];
						$data[$row['menu_name']]['menu_icon']= $row['ctl_menu_icon'];
						$data[$row['menu_name']]['page_active_title']= $row['page_active_title'];
						
						if(!in_array($row['parent'],$main_menu_id)){
							$main_menu_id[] = $row['parent'];
						}
					}
				}
			}

			if($this->ci->session->userdata('user_type') == '2'){
				$menu_list1 = $this->ci->common_query->get_data('controllerlist c','c.id,c.controllername,c.parent,c.menu_name,c.action_id,c.menu_category_id,c.url,m.menu_cat_name,m.menu_icon,c.ctl_menu_icon,c.page_active_title','c.status="1" AND c.menu_type="4"','left JOIN menu_category m on m.id=c.menu_category_id','order by c.ctl_menu_position');
				
				
				if(!empty($menu_list1)){
					foreach($menu_list1 as $row1){
						if($row1['menu_category_id'] != 3 && !empty($row1['menu_category_id'])){
							$data[$row1['menu_cat_name']]['main_menu']=$row1['menu_cat_name'];
							$data[$row1['menu_cat_name']]['url']= '';
							$data[$row1['menu_cat_name']]['menu_icon']= $row1['menu_icon'];
							$data[$row1['menu_cat_name']]['sub_menu'][$row1['id']]= $row1['menu_name'];
							$data[$row1['menu_cat_name']]['submenu_url'][$row1['id']]= $row1['url'];
							$data[$row1['menu_cat_name']]['submenu_icon'][$row1['id']]= $row1['ctl_menu_icon'];
							$data[$row1['menu_cat_name']]['page_active_title'][$row1['id']]= $row1['page_active_title'];
							if(!in_array($row1['parent'],$main_menu_id)){
								$main_menu_id[] = $row1['parent'];
							}
						}else if($row1['menu_category_id'] == 3){
							$data[$row1['menu_name']]['main_menu']=$row1['menu_name'];
							$data[$row1['menu_name']]['url']= $row1['url'];
							$data[$row1['menu_name']]['menu_icon']= $row1['ctl_menu_icon'];
							$data[$row1['menu_name']]['page_active_title']= $row1['page_active_title'];
							
							if(!in_array($row1['parent'],$main_menu_id)){
								$main_menu_id[] = $row1['parent'];
							}
						}
					}
				}
			}


			$this->ci->session->set_userdata('menu_list',base64_encode(json_encode($data)));
			
			if(!empty($main_menu_id)){
				$main_menu_id = implode(',',$main_menu_id);
				return $main_menu_id;
			}
		}
		return false;
	}

	function generate_access_action($main_menu_id = null, $act_id = null){

		
		$main_menu_id = $main_menu_id;

		$action_id = $act_id;

		$controllername = trim($this->ci->router->fetch_class());

		$controllers_data = $this->ci->common_query->get_data('controllerlist','controllername,id','id in ('.$main_menu_id.')');

		//echo $main_menu_id;exit;
		//print'<pre>';print_r($controllers_data);exit;
		$temp_data=array();
		if(!empty($controllers_data)){
			foreach($controllers_data as $row){
				$temp_data[$row['id']] =str_replace(' ','_',strtolower(trim($row['controllername'])));
			}	
		}

		if($this->ci->session->userdata('user_type') == 2){
			$actions = $this->ci->common_query->get_data('controllerlist c','c.action_id,a.action_name,a.id,c.parent','a.status="1" AND c.status="1" AND c.menu_type="4"','JOIN action_list a on a.id=c.action_id');
			$dev_action_data = array();
			if(!empty($actions)){
				foreach($actions as $row){
					$dev_action_data[] = $row['parent'].'_'.$row['action_id']; 
				}
			}

			if(!empty($dev_action_data)){
				$dev_action_data = implode(',',$dev_action_data);
				$action_id .= ','.$dev_action_data;
			}
		}
		
		$action_list_id = explode(',',$action_id);
		$actions = $this->ci->common_query->get_data('controllerlist c','c.action_id,a.action_name,a.id,c.parent','a.status="1" AND c.status="1" AND c.parent in ('.$main_menu_id.')','JOIN action_list a on a.id=c.action_id');
		$action_list_data = array();
		$session_action = array();
		if(!empty($actions) && !empty($temp_data)){
			foreach($actions as $row){
				$action_list = $temp_data[$row['parent']].'_'.str_replace(' ','_',strtolower(trim($row['action_name'])));
				unset($this->ci->session->userdata['search_field'][$action_list]);
				if($temp_data[$row['parent']] == $controllername){
					if(in_array($row['parent'],array_flip($temp_data))){
						$action_list_data = $row['parent'].'_'.$row['action_id'];

						if(in_array($action_list_data,$action_list_id)){
							
							$session_action[$action_list] = 1; 
							
						}
					}
				}
			}

			$this->ci->session->set_userdata('session_action',$session_action);
		}

		//print'<pre>';print_r($this->ci->session->all_userdata());exit;
		//exit;
	}
	function check_access($menu_id = null,$access_id = null){
		if(!empty($menu_id)){

			if(!empty($access_id)){
				$menu_id .=','.$access_id;
			}
			$data = $this->ci->common_query->get_data('controllerlist c','CONCAT(cc.controllername,"_",c.controllername) AS controllers','c.status="1" and c.id in ('.$menu_id.')','INNER JOIN controllerlist cc ON c.parent = cc.id');
			
			

			$data1 = $this->ci->common_query->get_data('controllerlist c','CONCAT(cc.controllername,"_",c.controllername) AS controllers','c.menu_type="3"','INNER JOIN controllerlist cc ON c.parent = cc.id');
			
			$data2 = '';
			
			if($this->ci->session->userdata('user_type') == 2){
			$data2 = $this->ci->common_query->get_data('controllerlist c','CONCAT(cc.controllername,"_",c.controllername) AS controllers','c.menu_type="4"','INNER JOIN controllerlist cc ON c.parent = cc.id');
			}

			$list = array();
			if(!empty($data)){
				foreach($data as $row){
					$list[] = $row['controllers'];
				}

				if(!empty($data1)){
					foreach($data1 as $row1){
						$list[] = $row1['controllers'];
					}					
				}
			}

			if(!empty($data2)){
				foreach($data2 as $row2){
					$list[] = $row2['controllers'];
				}					
			}

			//print'<pre>';print_r($list);
			$controllername = $this->ci->router->fetch_class();
			$functionname =	$this->ci->router->fetch_method();

			if(is_numeric($functionname)){
				$functionname = 'index';
			}

			$current_url = strtolower(trim($controllername)).'_'.strtolower(trim($functionname));
			//echo $current_url;

			if(in_array($current_url, $list)){
				//echo 'hiii';exit;
				return true;
			}else{
				//echo 'byeeee';exit;
				return false;
			}

		}
		return false;
	}
	// function checkaccess(){
	// 	$controllername = $this->ci->router->fetch_class();
	// 	$functionname =	$this->ci->router->fetch_method();
	// 	$current_url = strtolower(trim($controllername)).'_'.strtolower(trim($functionname));
	// 	$url_access_id = json_decode(base64_decode($this->ci->session->userdata('url_access_id')),true);
	// 	if(in_array($current_url, $url_access_id)){
	// 		return true;
	// 	}else{
	// 		return false;
	// 	}
	// }
}