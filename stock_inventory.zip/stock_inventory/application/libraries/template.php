<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Template
{	
	public $ci;
	
	function __Construct(){
		$this->ci = & get_instance();
	}

	function load($temp_name , $body_name = null , $data = null){
		
		
	}
 
}