<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Generate_form
{
    protected $ci;
    var $field_arr = array('text','textarea','select','checkbox','hidden','number','date','radio','email','password','file','button');
    var $field_attr = array('value','class','id','name','rel','accept','align','alt','checked','readonly','disable','type','selected','required','autocomplete','autofocus','max','min','width','style','maxlength','pattern','placeholder','size','multiple');

    function __Construct()
    {
        $this->ci =& get_instance();
        $this->ci->load->library('session');
        $this->ci->load->library('auth');
        $this->ci->load->library('form_validation');
    }

    function set_field_list($field_list){
        $array_list = '';
        $data = '';
        if(!empty($field_list) && is_array($field_list)){
            foreach($field_list as $key => $value){
                if(array_key_exists('type', $value) && in_array($value['type'], $this->field_arr)){
                    $type = $value['type'];
                    if($type == 'textarea'){
                        $data[$key] = '<textarea name="'.$key.'"></textarea>';
                    }else if($type == 'select'){
                        $data[$key] = '<select name="'.$key.'"><option value="select">select</option></select>';
                    }else if($type == 'date'){
                        $data[$key] = '<input type="'.$type.'">';
                    }else{
                        $data[$key] = '<input type="'.$type.'">';
                    }
                }
            }
        }

        print'<pre>';print_r($data);exit;



    }
}