<?php 

class Dashboard_model extends CI_Model{

	function gethybridtable_list($maintable_id = null){
		$sql = $this->db->query("select table_column_name from hybrid_table_list where parent_table_id =$maintable_id");
		if($sql->num_rows() > 0 ){
			return $sql->result_array();
		}
		return false;
	}

	function checktable_present($table_name){
		$sql = $this->db->query("SHOW TABLES LIKE '$table_name'");
		if($sql->num_rows() > 0 ){
			return true;
		}
		return false;
	}

	function sethybridtable_list($column_name=null,$table_name = null){
		$query = "SELECT IFNULL(column_name, '') as column_name FROM information_schema.columns WHERE table_name ='".$table_name."' AND column_name = '".$column_name."'";
		$sql = $this->db->query($query);
		if($sql->num_rows() <= 0 ){
			$alter_column = $this->db->query("alter table $table_name add $column_name varchar(255)");
		}
	}

	function save_excel_data($maintable_id = null , $data=null){
		$this->db->insert($maintable_id,$data);
	}

	function add_message($message, $nickname, $guid)
	{
		$data = array(
			'message'	=> (string) $message,
			'nickname'	=> (string) $nickname,
			'guid'		=> (string)	$guid,
			'timestamp'	=> time(),
		);
		  
		$this->db->insert('messages', $data);
	}
 
	function get_messages($timestamp)
	{
		$this->db->where('timestamp >', $timestamp);
		$this->db->order_by('timestamp', 'DESC');
		$this->db->limit(10); 
		$query = $this->db->get('messages');
		
		return array_reverse($query->result_array());
	}
}