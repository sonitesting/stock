<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Common_query extends CI_Model{

	function __Construct(){
		parent::__construct();
	}

	function get_total_count($table_name,$where = null,$join = null){
		$join = (!empty($join) ? ' '.$join : '');
		$where = (!empty($where) ? ' where '.$where : '');
		$sql = 'select count(*) as cnt from '.$table_name.$join.$where;
		$query = $this->db->query($sql);
		$data = $query->row_array();
		return (isset($data['cnt']) && $data['cnt'] > 0 ? $data['cnt'] : '');
	}

	function get_data($table_name,$select = null,$where = null,$join = null,$extra_condition = null){
		$select = (!empty($select) ? $select : '*');
		$join = (!empty($join) ? ' '.$join : '');
		$where = (!empty($where) ? ' where '.$where : '');
		$extra_condition = (!empty($extra_condition) ? ' '.$extra_condition : '');
		$sql = 'select '.$select.' from '.$table_name.$join.$where.$extra_condition;
		// echo $sql;
		// echo nl2br('<br>');
		$data = $this->db->query($sql);
		if($data->num_rows() > 0){
			return $data->result_array();
		}
		return false;
	}

	function get_row_data($table_name,$select = null,$where = null,$join = null,$extra_condition = null){
		$select = (!empty($select) ? $select : '*');
		$join = (!empty($join) ? ' '.$join : '');
		$where = (!empty($where) ? ' where '.$where : '');
		$extra_condition = (!empty($extra_condition) ? ' '.$extra_condition : '');
		$sql = 'select '.$select.' from '.$table_name.$join.$where.$extra_condition;
		$data = $this->db->query($sql);
		if($data->num_rows() > 0){
			return $data->row_array();
		}
		return false;
	}

	function update_data($table_name,$set = null,$where = null,$join = null){
		$join = (!empty($join) ? ' '.$join : '');
		$where = (!empty($where) ? ' where '.$where : '');
		$sql = 'update '.$table_name.$join.' set '.$set.$where;
		$data = $this->db->query($sql);
		return ($this->db->affected_rows() > 0 ? true : false);
	}

	function save_data($table_name,$data = null){
		$primary="";
		if($table_name!=""){
			
			$primary_key = $this->db->field_data($table_name);

			foreach ($primary_key as $field){
			   
			   if($field->primary_key==1){

					$primary=$field->name;
			   }
			}		 

			$id=$this->input->post($primary);

			$arr = $this->db->list_fields($table_name);

			foreach ($arr as $field)
			{
				if(isset($data[$field]) && $data[$field]!="" ){
					$data1[$field]=$data[$field];						
				}
			}

			if($id==" " || $id==null){
				if(in_array('created_date', $arr)){
					$data1['created_date'] = date('Y-m-d H:i:s');
				}
				if(in_array('created_by', $arr)){
					$data1['created_by'] = $this->session->userdata('user_id');
				}
				if(in_array('updated_by', $arr)){
					$data1['updated_by'] = $this->session->userdata('user_id');
				}
				$this->db->insert($table_name,$data1);
				return ($this->db->insert_id() > 0 ? $this->db->insert_id() : false);
			}else if($id!=" "){	
				if(in_array('updated_by', $arr)){
					$data1['updated_by'] = $this->session->userdata('user_id');
				}		
				$this->db->where($primary,$id);
				$this->db->update($table_name,$data1);	
				return ($this->db->affected_rows() > 0 ? 'update_data' : 'already_update_data');	
			}
			return 0;
		}else{
			return 0;
		}
		
	}

	function delete_data($table_name = null,$where=null){
		if(!empty($where)){
			$sql = 'DELETE from '.$table_name.' where '.$where;
			$this->db->query($sql);
		}
		return ($this->db->affected_rows() > 0 ? true : false);
	}

	function get_data_by_id($primary_id,$table_name,$select = null,$where = null,$join = null,$extra_condition = null){

		$primary="";
		
		if(isset($primary_id) && !empty($primary_id)){
			$primary_id=$primary_id;
		}else{
			$primary_id="";	
		}

		$select = (!empty($select) ? $select : '*');
		$join = (!empty($join) ? ' '.$join : '');
		$extra_condition = (!empty($extra_condition) ? ' '.$extra_condition : '');
		
		if($table_name!=""){
			
			$primary_key = $this->db->field_data($table_name);
			
			foreach ($primary_key as $field){
			   
			   if($field->primary_key==1){

					$primary=$field->name;
			   }
			} 
			
			if($primary_id==""){
				
				$sql = 'select '.$select.' from '.$table_name.$join.$extra_condition;
				$query = $this->db->query($sql);

				foreach ($query->list_fields() as $field){
				   $fdata[$field]="";
				}
				return $fdata;

			}else if($primary_id!=""){
				
				$where = (!empty($where) ? ' where '.$where : '');
				if(!empty($where)){
					$where .= ' AND '.$table_name.'.'.$primary.'='.$primary_id.' ';
				}else{
					$where .= ' where '.$table_name.'.'.$primary.'='.$primary_id.' ';
				}
				
				$sql = 'select '.$select.' from '.$table_name.$join.$where.$extra_condition;
				$data = $this->db->query($sql);
				if($data->num_rows() > 0){
					return $data->row_array();
				}
				return false;
			}
		}
	}

	// function get_spare_data($product_id){
	// 	$sql="select id , part_name from spare_part where product_id='$product_id'";
	// 	$data = $this->db->query($sql);
	// 			if($data->num_rows() > 0){
	// 				return $data->row_array();
	// 			}
	// 			return false;
	// }

	 function get_spare_data($product_id='')
	 {
	    $this -> db -> select('part_name,id');
	    $this -> db -> where('product_id', $product_id);
	    $query = $this -> db -> get('spare_part');

	    if($query->num_rows() > 0){
	    	return $query->result();
	    }else{
	    	return false;
	    }
	    
	 }

	 function get_spare_amount($spare_id='')
	 {
	 		//print('auth amount');exit;
	 	$this-> db ->select_sum('stock_in');
	    $this -> db -> select('product_id,cost_per_quantity');
	    
	    $this -> db -> where('spare_part_id', $spare_id);
	    $query = $this -> db -> get('stock');

	    if($query->num_rows() > 0){

	    	return $query->result();
	    }else{
	    	return false;
	    }
	    
	 }
}