<?php 
    extract((isset($get_data) && !empty($get_data) ? $get_data : ''));
?>


<!-- BEGIN CONTENT -->
<div class="page-content-wrapper" id="content_view">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
    	<!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo base_url();?>">Dashboard</a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <a href="<?php echo base_url().'roles';?>"><span>Roles List</span></a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <span>Group Access</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"></h1>
        <!-- END PAGE TITLE-->
        
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            <span class="caption-subject font-blue-hoki bold uppercase">Group Access : <?php echo (isset($roles_name) && !empty($roles_name) ? $roles_name : '');?></span>
                        </div>
                        <div class="tools">
                            <a href="#" class="collapse"> </a>
                        </div>
                    </div>
                    <div class="portlet-body form">
                        <!-- BEGIN FORM-->
                        <form action="<?php echo base_url().'roles/'.$this->uri->segment(2).(!empty($this->uri->segment(3)) ? '/'.$this->uri->segment(3) : '');?>" class="form-horizontal form-bordered" method="post">
                            <input type="hidden" name="id" autocomplete="off" value="<?php echo (isset($id) && !empty($id) ? $id : ''); ?>">
                            <input type="hidden" name="roles_id" autocomplete="off" value="<?php echo (isset($roles_id) && !empty($roles_id) ? $roles_id : ''); ?>">
                            <div class="form-body">
                                <div class="form-body">
                                    <div class="form-group">
                                    <?php if(!empty($controllerlist)){
                                            foreach($controllerlist as $key=>$value){
                                                $cnt = 0;
                                                foreach($value['functionname'] as $f_key=>$f_value){
                                                    $checked = '';
                                                    if($f_value == 'index'){
                                    ?>

                                        <div class="form-group form-sm-checkboxes col-md-3">
                                            <div class="sm-checkbox-inline">
                                                <?php if(isset($menu_id) && !empty($menu_id)){
                                                    $menu_id1 = explode(',',$menu_id);
                                                
                                                    if(in_array($f_key, $menu_id1)){
                                                        $checked = 'checked';
                                                    }
                                                }?>
                                                <div class="md-checkbox ">
                                                    <input type="checkbox" id="menu_id_<?php echo $f_key;?>" name="menu_id[<?php echo $f_key;?>]" class="md-check" value="<?php echo $f_key;?>" <?php echo $checked;?>>
                                                    <label for="menu_id_<?php echo $f_key;?>">
                                                        <span></span>
                                                        <span class="check"></span>
                                                        <span class="box"></span>
                                                        <?php echo $value['menu_name'][$f_key];?>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <?php $cnt++;if(count($value['functionname']) > 1){?>
                                        <div class="col-md-9">
                                            <div class="form-group form-sm-checkboxes">
                                                <div class="md-checkbox-inline">
                                        <?php }else{
                                              echo '<div class="col-md-9">
                                            <div class="form-group form-sm-checkboxes">
                                                <div class="md-checkbox-inline">------------------------------------------------------------------------------------</div></div></div><div class="clearfix"></div>';
                                            }}else if(count($value['functionname']) > 1){?>
                                            
                                                    <div class="md-checkbox ">
                                                    <?php if(isset($access_id) && !empty($access_id)){
                                                            $access_id1 = explode(',',$access_id);
                                                        
                                                            if(in_array($f_key, $access_id1)){
                                                                $checked = 'checked';
                                                            }
                                                        }?>
                                                        <input type="checkbox" id="action_list_id_<?php echo $f_key;?>" name="action_list_id[<?php echo $f_key;?>]" class="md-check" value="<?php echo $f_key.'_'.$key.'_'.$value['action_id'][$f_key];?>" <?php echo $checked;?>>
                                                        <label for="action_list_id_<?php echo $f_key;?>">
                                                            <span></span>
                                                            <span class="check"></span>
                                                            <span class="box"></span>
                                                            <?php echo $value['menu_name'][$f_key];?>
                                                        </label>
                                                    </div>
                                                
                                        
                                        <?php $cnt++;if(count($value['functionname']) == $cnt){?>       </div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    <?php }}}}}?>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions right">
                                <button type="button" class="btn default cancel">Cancel</button>
                                <button type="submit" class="btn blue">
                                    <i class="fa fa-check"></i> Save
                                </button>
                            </div>
                        </form>
                        <!-- END FORM-->
                    </div>
                </div>
            </div>
        </div>
	</div>
    <!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->
<script type="text/javascript">
 $(document).ready(function(){
    $url = "<?php echo base_url().'roles/';?>";
    $(".cancel").click(function(){
        location.href =$url;
    });             
});   
</script>