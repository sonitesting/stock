<html>
<head>
<title>Email Verification</title>
<script src="https://use.fontawesome.com/006c15fcfc.js"></script>
</head>
	<body style="font-family: verdana;font-size: 15px; color: #2f2f2f;background: rgb(217, 223, 226);">
		<div style="    margin: 5% auto 0;float: none;text-align: left;width: 80%;background: #f5f5f5; padding:20px;">
			
			<p style="font-size: 29px; font-family: serif;color: #FF5722; margin:0;">LOGO</p>
			
			<p style="line-height:26px;">
				Thanks for creating an account with us. Click below to confirm your email address: <a href="<?php echo (isset($click_link) && !empty($click_link) ? $click_link : '');?>" target="_blank"><?php echo (isset($click_link) && !empty($click_link) ? $click_link : '');?></a>
			</p>
			<p style="line-height:26px;">
				If you have problems, please paste the above URL into your web browser. 
			</p>
			<p style="line-height:26px;">
				Thanks,<br />
				Admin Support 
			</p>
		
			
		</div>
		<div style="margin: 0 auto;float: none;text-align: left;width: 80%;background: #ccc; padding:20px; overflow: auto; ">
			
				<p style="line-height:26px;float:left;width:68%;font-size: 15px;">
					Change notification settings | Privacy Policy | Contact Support<br />
					High Five From Admin Support! <br />
					© 2016 Admin Support
				</p>
			
				<p style="float: right;background: #ccc;padding: 10px;color: #fff;width: 20%;text-align: right;">
					<i class="fa fa-google-plus-square" style="font-size: 25px;padding: 5px;" aria-hidden="true"></i> 
					<i class="fa fa-facebook-square" style="font-size: 25px;padding: 5px;" aria-hidden="true"></i> 
					<i class="fa fa-linkedin-square" style="font-size: 25px;padding: 5px;" aria-hidden="true"></i> 
					<i class="fa fa-twitter-square" style="font-size: 25px;padding: 5px;" aria-hidden="true"></i>
				</p>
		</div>
	</body>
</html>