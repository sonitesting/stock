<?php 
    extract((isset($get_data) && !empty($get_data) ? $get_data : ''));
?>


<!-- BEGIN CONTENT -->
<div class="page-content-wrapper" id="content_view">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
    	<!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo base_url();?>">Dashboard</a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <a href="<?php echo base_url().'state';?>"><span>State List</span></a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <span>State Detail</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"></h1>
        <!-- END PAGE TITLE-->
        
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            <span class="caption-subject font-blue-hoki bold uppercase">state Detail</span>
                        </div>
                        <div class="tools">
                            <a href="#" class="collapse"> </a>
                        </div>
                    </div>
                    <div class="portlet-body form">
                        <!-- BEGIN FORM-->
                        <form action="<?php echo base_url().'state/'.$this->uri->segment(2).(!empty($this->uri->segment(3)) ? '/'.$this->uri->segment(3) : '');?>" class="horizontal-form" method="post">
                            <input type="hidden" name="id" value="<?php echo (isset($id) && !empty($id) ? $id : set_value('id')); ?>">
                            <div class="form-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['state_name']) && !empty($errors['state_name']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                State Name
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="state_name" autocomplete="off" name="state_name" class="form-control" placeholder="State Name" value="<?php echo (isset($state_name) && !empty($state_name) ? $state_name : set_value('state_name')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['state_name']) && !empty($errors['state_name']) ? $errors['state_name'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['country_id']) && !empty($errors['country_id']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Country
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="country_id" id="country_id" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <?php if(isset($country) && !empty($country)){
                                                    foreach($country as $row){
                                                ?>
                                                <option value="<?php echo $row['id'];?>" <?php echo ((isset($country_id) && $country_id ===  $row['id']) || set_value('country_id') === $row['id'] ? 'selected' : '');?>><?php echo ucwords($row['country_name']);?></option>
                                                <?php }}?>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['country_id']) && !empty($errors['country_id']) ? $errors['country_id'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['status']) && !empty($errors['status']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Status
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="status" id="status" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <option value="0" <?php echo ((isset($status) && $status === '0') || set_value('status') === '0' ? 'selected' : '');?>>In-Active</option>
                                                <option value="1" <?php echo ((isset($status) && $status === '1') || set_value('status') === '1' ? 'selected' : '');?>>Active</option>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['status']) && !empty($errors['status']) ? $errors['status'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions right">
                                <button type="button" class="btn default cancel">Cancel</button>
                                <?php if(isset($type) && $type != 'view'){?>
                                <button type="submit" class="btn blue">
                                    <i class="fa fa-check"></i> Save</button>
                                <?php }?>
                            </div>
                        </form>
                        <!-- END FORM-->
                    </div>
                </div>
            </div>
        </div>
	</div>
    <!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->
<script type="text/javascript">
 $(document).ready(function(){
    $url = "<?php echo base_url().'state/';?>";
    $(".cancel").click(function(){
        location.href =$url;
    });             
});   
</script>