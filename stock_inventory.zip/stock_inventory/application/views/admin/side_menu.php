<!--BEGIN SIDEBAR -->
<div class="page-sidebar-wrapper">
    <!-- BEGIN SIDEBAR -->
    <div class="page-sidebar navbar-collapse collapse">
        <!-- BEGIN SIDEBAR MENU -->
        <ul class="page-sidebar-menu  page-header-fixed page-sidebar-menu-closed page-sidebar-menu-hover-submenu " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
            <!-- BEGIN SIDEBAR TOGGLER BUTTON -->
            <li class="sidebar-toggler-wrapper hide">
                <div class="sidebar-toggler">
                    <span></span>
                </div>
            </li>
            <!-- END SIDEBAR TOGGLER BUTTON -->
            <!-- <li class="sidebar-search-wrapper"> -->
                <!-- BEGIN RESPONSIVE QUICK SEARCH FORM -->
               <!--  <form class="sidebar-search  " action="http://keenthemes.com/preview/metronic/theme/admin_1/page_general_search_3.html" method="POST">
                    <a href="javascript:;" class="remove">
                        <i class="icon-close"></i>
                    </a>
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search...">
                        <span class="input-group-btn">
                            <a href="javascript:;" class="btn submit">
                                <i class="icon-magnifier"></i>
                            </a>
                        </span>
                    </div>
                </form> -->
                <!-- END RESPONSIVE QUICK SEARCH FORM -->
            <!-- </li> -->
            <?php if($this->session->userdata('menu_list')){
                    $menu_list = json_decode(base64_decode($this->session->userdata('menu_list')),true);
                    foreach($menu_list as $row){
                        if(isset($row['sub_menu']) && !empty($row['sub_menu'])){
            ?>

            <li class="nav-item start <?php echo (isset($page) && (in_array($page,$row['page_active_title'])) ? 'active open' : '');?>">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <?php if(!empty($row['menu_icon'])){
                             echo '<i class="'.$row['menu_icon'].'"></i>'; }else{ echo '<i class="icon-home"></i>';}?>
                    <span class="title"><?php echo $row['main_menu'];?></span>
                    <span class="selected"></span>
                    <span class="arrow <?php echo (isset($page) && (in_array($page,$row['page_active_title'])) ? 'open' : '');?>"></span>
                </a>
                <ul class="sub-menu">
                    <?php foreach($row['sub_menu'] as $key => $value){ ?>
                    <li class="nav-item start <?php echo (isset($page) && $page == $row['page_active_title'][$key] ? 'active' : '');?>">
                        <a href="<?php echo base_url().$row['submenu_url'][$key];?>" class="nav-link ">
                            <?php if(isset($row['ctl_menu_icon'][$key]) && !empty($row['ctl_menu_icon'][$key])){
                             echo '<i class="'.$row['ctl_menu_icon'][$key].'"></i>'; }?>
                            <span class="title"><?php echo $value;?></span>
                        </a>
                    </li>
                    <?php }?>
                </ul>
            </li>
            <?php }else{?>
            <li class="nav-item start <?php echo (isset($page) && $page == $row['page_active_title'] ? 'active' : '');?>">
                <a href="<?php echo base_url().$row['url'];?>" class="nav-link nav-toggle">
                    <?php if(!empty($row['menu_icon'])){
                             echo '<i class="'.$row['menu_icon'].'"></i>'; }else{ echo '<i class="icon-home"></i>';}?>
                    <span class="title"><?php echo $row['main_menu'];?></span>
                </a>
            </li>

            <?php }}}?>

            <!-- <li class="nav-item start <?php echo (isset($page) && $page == 'Dashboard' ? 'active' : '');?>">
                <a href="<?php echo base_url();?>dashboard" class="nav-link nav-toggle">
                    <i class="icon-home"></i>
                    <span class="title">Dashboard</span>
                </a>
            </li>
            <li class="nav-item start <?php echo (isset($page) && $page == 'Action' ? 'active' : '');?>">
                <a href="<?php echo base_url();?>action_list" class="nav-link nav-toggle">
                    <i class="icon-home"></i>
                    <span class="title">Actions</span>
                </a>
            </li>
            <li class="nav-item start <?php echo (isset($page) && ($page == 'Country' || $page == 'State' || $page == 'City') ? 'active open' : '');?> ">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="icon-home"></i>
                    <span class="title">Master</span>
                    <span class="selected"></span>
                    <span class="arrow <?php echo (isset($page) && ($page == 'Country' || $page == 'State' || $page == 'City') ? 'open' : '');?>"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item start <?php echo (isset($page) && $page == 'Country' ? 'active' : '');?>">
                        <a href="<?php echo base_url();?>country" class="nav-link ">
                            <span class="title">Country</span>
                        </a>
                    </li>
                    <li class="nav-item start <?php echo (isset($page) && $page == 'State' ? 'active' : '');?>">
                        <a href="<?php echo base_url();?>state" class="nav-link ">
                            <span class="title">State</span>
                        </a>
                    </li>
                    <li class="nav-item start <?php echo (isset($page) && $page == 'City' ? 'active' : '');?>">
                        <a href="<?php echo base_url();?>City" class="nav-link ">
                            <span class="title">City</span>
                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item start <?php echo (isset($page) && ($page == 'Employees' || $page == 'Roles') ? 'active open' : '');?>">
                <a href="javascript:;" class="nav-link nav-toggle">
                    <i class="icon-home"></i>
                    <span class="title">Admin</span>
                    <span class="selected"></span>
                    <span class="arrow <?php echo (isset($page) && ($page == 'Employees' || $page == 'Roles') ? 'open' : '');?>"></span>
                </a>
                <ul class="sub-menu">
                    <li class="nav-item start <?php echo (isset($page) && $page == 'Roles' ? 'active' : '');?>">
                        <a href="<?php echo base_url();?>roles" class="nav-link ">
                            <span class="title">Roles</span>
                        </a>
                    </li>
                    <li class="nav-item start <?php echo (isset($page) && $page == 'Employees' ? 'active' : '');?>">
                        <a href="<?php echo base_url();?>employees" class="nav-link ">
                            <span class="title">Employees</span>
                        </a>
                    </li>
                </ul>
            </li> -->
        </ul>
        <!-- END SIDEBAR MENU -->
        <!-- END SIDEBAR MENU -->
    </div>
    <!-- END SIDEBAR -->
</div>
<!-- END SIDEBAR