<style type="text/css">
    .td_center{
        text-align: center;
    }
</style>

<!-- BEGIN CONTENT -->
                    <div class="page-content-wrapper">
                        <!-- BEGIN CONTENT BODY -->
                        <div class="page-content">
                            <!-- BEGIN PAGE HEADER-->
                            <!-- BEGIN PAGE BAR -->
                            <div class="page-bar">
                                <ul class="page-breadcrumb">
                                    <li>
                                        <a href="<?php echo base_url();?>dashboard">Dashboard</a>
                                        <i class="fa fa-circle"></i>
                                    </li>
                                    <li>
                                        <span>Create Menu</span>
                                    </li>
                                </ul>
                            </div>
                            <!-- END PAGE BAR -->
                            <!-- BEGIN PAGE TITLE-->
                            <h1 class="page-title">
                            </h1>
                            <!-- END PAGE TITLE-->
                            <!-- END PAGE HEADER-->
                            <?php if($this->session->userdata('status_msg') == 'insert_success'){?>
                                <div class="alert alert-success">
                                    <button class="close" data-close="alert"></button> 
                                    The data saved successfully. 
                                </div>
                            <?php } $this->session->unset_userdata('status_msg');?>
                            <!-- BEGIN PAGE CONTENT-->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="portlet light bordered">
                                        <div class="portlet-title">
                                            <div class="caption">
                                                <i class="icon-social-dribbble font-blue-sharp"></i>
                                                <span class="caption-subject font-blue-sharp bold uppercase">Create Menu</span>
                                            </div>
                                        </div>
                                        <div class="portlet-body">
                                            <div class="table-container">
                                            <form method="post" action="<?php echo base_url();?>auth_access" class="form-horizontal" role="form">
                                                <div class="table-scrollable">
                                                <table border="1" cellpadding="2" cellspacing="1" class="table table-bordered table-hover table-striped"  style="white-space: nowrap;">
                                                        <thead>
                                                            <tr>
                                                                <th scope="col" width="10%">Sr.No.</th>
                                                                <th scope="col">Controller / Function </th>
                                                                <th scope="col">Menu Name</th>
                                                                <th scope="col">Url</th>
                                                                <th scope="col">Page Active Title</th>
                                                                <th scope="col">Menu Icon</th>
                                                                <th scope="col">Action Link</th>
                                                                <th scope="col">Menu Category</th>
                                                                <th scope="col">Menu Type</th>
                                                                <th scope="col">Status</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php if(isset($controllerlist) && !empty($controllerlist)){
                                                                $count=1;
                                                                foreach($controllerlist as $key => $value){
                                                            ?>
                                                            <?php if(isset($value['functionname']) && !empty($value['functionname'])){
                                                                foreach($value['functionname'] as $f_key=> $f_value){
                                                            ?>
                                                            <tr>
                                                                <td><?php echo $count++;?></td>
                                                                <td>
                                                                    <?php if($f_value == 'index'){
                                                                            echo $value['controllername'];
                                                                        }else{
                                                                            echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;/".$f_value;
                                                                        }?> 
                                                                </td>
                                                                <td class="td_center">

                                                                <input class="form-control form-filter input-md" type="text" name="menu_name[<?php echo $f_key;?>]" value="<?php echo $value['menu_name'][$f_key];?>" autocomplete="off" style="min-width:103px;"/>

                                                                </td>
                                                                <td class="td_center">
                                                                 <?php if($f_value == 'index'){?>
                                                                <input class="form-control form-filter input-md" type="text" name="url[<?php echo $f_key;?>]" value="<?php echo $value['url'][$f_key];?>" autocomplete="off" style="min-width:103px;"/>
                                                                <?php }else{ echo '------';}?>
                                                                </td>
                                                                <td class="td_center">
                                                                 <?php if($f_value == 'index'){?>
                                                                 <input class="form-control form-filter input-md" type="text" name="page_active_title[<?php echo $f_key;?>]" value="<?php echo $value['page_active_title'][$f_key];?>" autocomplete="off" style="min-width:103px;"/>
                                                                 <?php }else{ echo '------';}?>
                                                                </td>
                                                                <td class="td_center">
                                                                <?php if($f_value == 'index'){?>
                                                                <input class="form-control form-filter input-md" type="text" name="ctl_menu_icon[<?php echo $f_key;?>]" value="<?php echo $value['ctl_menu_icon'][$f_key];?>" autocomplete="off" style="min-width:103px;"/>
                                                                <?php }else{ echo '------';}?>
                                                                </td>
                                                                <td class="td_center">
                                                                <?php if($f_value != 'index'){?>
                                                                <select class="form-control form-filter input-md" name="action_id[<?php echo $f_key;?>]" style="min-width:103px;">
                                                                        <option value="">Select</option>
                                                                        <?php if(!empty($action_list)){
                                                                                foreach($action_list as $row){?>
                                                                        <option value="<?php echo $row['id'];?>" <?php if($value['action_id'][$f_key] == $row['id'] ){ echo 'selected';}?>><?php echo $row['action_name'];?></option>
                                                                        <?php }}?>
                                                                    </select>
                                                                <?php }else{ echo '------';}?>
                                                                </td>
                                                                <td class="td_center">
                                                                <?php if($f_value == 'index'){?>    
                                                                <select class="form-control form-filter input-md" name="menu_category_id[<?php echo $f_key;?>]" style="min-width:103px;">
                                                                        <option value="">Select</option>
                                                                        <?php if(!empty($menu_category)){
                                                                                foreach($menu_category as $row){?>
                                                                        <option value="<?php echo $row['id'];?>" <?php if($value['menu_category_id'][$f_key] == $row['id'] ){ echo 'selected';}?>><?php echo $row['menu_cat_name'];?></option>
                                                                        <?php }}?>
                                                                    </select>
                                                                <?php }else{ echo '------';}?>
                                                                </td>
                                                                <td class="td_center"><select class="form-control form-filter input-md" name="menu_type[<?php echo $f_key;?>]" style="min-width:103px;">
                                                                        <option value="">Select</option>
                                                                        <option value="1" <?php if($value['menu_type'][$f_key] == '1' ){ echo 'selected';}?>>Show Menu</option>
                                                                        <option value="2" <?php if($value['menu_type'][$f_key] == '2' ){ echo 'selected';}?>>Hidden Menu</option>
                                                                        <option value="3" <?php if($value['menu_type'][$f_key] == '3' ){ echo 'selected';}?>>Hidden Access</option>
                                                                         <option value="4" <?php if($value['menu_type'][$f_key] == '4' ){ echo 'selected';}?>>Developer Access</option>
                                                                    </select>
                                                                </td>
                                                                <td class="td_center"><select class="form-control form-filter input-md" name="status[<?php echo $f_key;?>]" style="min-width:103px;">
                                                                        <option value="">Select</option>
                                                                        <option value="0" <?php if($value['status'][$f_key] == '0' ){ echo 'selected';}?>>In-Active</option>
                                                                        <option value="1" <?php if($value['status'][$f_key] == '1' ){ echo 'selected';}?>>Active</option>
                                                                    </select>
                                                                </td>
                                                            </tr>  

                                                            <?php }}}}?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                <div class="form-actions">
                                                    <div class="row">
                                                        <div class="col-md-offset-4 col-md-8">
                                                            <button class="btn blue" type="submit">Submit</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                            <!-- END PAGE CONTENT-->
                        </div>
                        <!-- END CONTENT BODY -->
                    </div>
                    <!-- END CONTENT -->