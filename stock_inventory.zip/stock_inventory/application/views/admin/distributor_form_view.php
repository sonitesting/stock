<?php 
    extract((isset($get_data) && !empty($get_data) ? $get_data : ''));
?>


<!-- BEGIN CONTENT -->
<div class="page-content-wrapper" id="content_view">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo base_url();?>">Dashboard</a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <a href="<?php echo base_url().'stock_distributor';?>"><span>Stock Distributor List</span></a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <span>Stock Distributor</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"></h1>
        <!-- END PAGE TITLE-->
        
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            <span class="caption-subject font-blue-hoki bold uppercase">Stock Distributor</span>
                        </div>
                        <div class="tools">
                            <a href="#" class="collapse"> </a>
                        </div>
                    </div>
                    <div class="portlet-body form">
                        <!-- BEGIN FORM-->
                        <form action="<?php echo base_url().'stock_distributor/'.$this->uri->segment(2).(!empty($this->uri->segment(3)) ? '/'.$this->uri->segment(3) : '');?>" class="horizontal-form" method="post">
                            <input type="hidden" name="id" value="<?php echo (isset($id) && !empty($id) ? $id : set_value('id')); ?>">
                            <div class="form-body">
                                <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group <?php echo (isset($errors['service_center_id']) && !empty($errors['service_center_id']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Service Center
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="service_center_id" id="service_center_id" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <?php if(isset($services) && !empty($services)){
                                                    foreach($services as $row){
                                                        //$service_center_option[$row['id']] = $row['first_name'].' '.$row['last_name']; 
                                                ?>
                                                <option value="<?php echo $row['id'];?>" <?php echo ((isset($service_center_id) && $service_center_id ===  $row['id']) || set_value('service_center_id') === $row['id'] ? 'selected' : '');?>><?php echo ucwords($row['first_name'].' '.$row['last_name']);?></option>
                                                
                                                <?php }}?>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['service_center_id']) && !empty($errors['service_center_id']) ? $errors['service_center_id'] : ''); ?></span>
                                        </div>  
                                    </div>
                                <div class="col-md-3">
                                        <div class="form-group <?php echo (isset($errors['product_id']) && !empty($errors['product_id']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Product Name
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control spare_product" name="product_id" id="spare_product" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <?php if(isset($product) && !empty($product)){
                                                    foreach($product as $row){
                                                ?>
                                                <option value="<?php echo $row['id'];?>" <?php echo ((isset($product_id) && $product_id ===  $row['id']) || set_value('product_id') === $row['id'] ? 'selected' : '');?>><?php echo ucwords($row['category_name']);?></option>
                                                <?php }}?>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['product_id']) && !empty($errors['product_id']) ? $errors['product_id'] : ''); ?></span>
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="form-group <?php echo (isset($errors['spare_part_id']) && !empty($errors['spare_part_id']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Spare Part Name
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="hidden" id="spare_part_id" autocomplete="off" value="<?php echo (isset($spare_part_id) && !empty($spare_part_id) ? $spare_part_id : set_value('spare_part_id')); ?>">
                                            <select name="spare_part_id" id="spare_id" class="form-control spare_id" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                               <option value="">Select Spare</option>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['spare_part_id']) && !empty($errors['spare_part_id']) ? $errors['spare_part_id'] : ''); ?></span>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-3">
                                        <div class="form-group <?php echo (isset($errors['stock_in']) && !empty($errors['stock_in']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Stock Quantity
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="stock_in" autocomplete="off" name="stock_in" class="form-control" placeholder="Stock quantity" value="<?php echo (isset($stock_in) && !empty($stock_in) ? $stock_in : set_value('stock_in')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> readonly>
                                            <span class="help-block"><?php echo (isset($errors['stock_in']) && !empty($errors['stock_in']) ? $errors['stock_in'] : ''); ?></span>
                                        </div>
                                    </div>
									<div class="col-md-3">
                                        <div class="form-group <?php echo (isset($errors['cost_per_quantity']) && !empty($errors['cost_per_quantity']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Cost Per Quantity
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="cost_per_quantity" autocomplete="off" name="cost_per_quantity" class="form-control" placeholder="Cost Per Quantity" value="<?php echo (isset($cost_per_quantity) && !empty($cost_per_quantity) ? $cost_per_quantity : set_value('cost_per_quantity')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> readonly>
                                            <span class="help-block"><?php echo (isset($errors['cost_per_quantity']) && !empty($errors['cost_per_quantity']) ? $errors['cost_per_quantity'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group <?php echo (isset($errors['quantity_amount']) && !empty($errors['quantity_amount']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Quantity Amount
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="quantity_amount" autocomplete="off" name="quantity_amount" class="form-control" placeholder="Quantity Amount" value="<?php echo (isset($quantity_amount) && !empty($quantity_amount) ? $quantity_amount : set_value('quantity_amount')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> onkeyup="myFunction()">
                                            <span class="help-block"><?php echo (isset($errors['quantity_amount']) && !empty($errors['quantity_amount']) ? $errors['quantity_amount'] : ''); ?></span>
                                        </div>
                                    </div>
									<div class="col-md-3">
                                        <div class="form-group <?php echo (isset($errors['amount']) && !empty($errors['amount']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Total Actual Amount
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="amount" autocomplete="off" name="amount" class="form-control" placeholder="amount" value="<?php echo (isset($amount) && !empty($amount) ? $amount : set_value('amount')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['amount']) && !empty($errors['amount']) ? $errors['amount'] : ''); ?></span>
                                        </div>
                                    </div>
                                   
									<div class="col-md-3">
                                        <div class="form-group>
                                            <label class="control-label">
                                                Discount Type
                                                 </span>
                                            </label>
                                            <select class="form-control discounts" name="discount_type" id="discounttype" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="0">Select</option>
                                                <option value="percent" <?php echo ((isset($discount_type) && $discount_type ===  'percent') || set_value('percent') === 'percent' ? 'selected' : '');?> >Discount Percent</option> 
                                                <option value="amount" <?php echo ((isset($discount_type) && $discount_type ===  'amount') || set_value('amount') === 'amount' ? 'selected' : '');?>>Discount Amount</option> 
                                            </select>
                                       
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="form-group <?php echo (isset($errors['discount_amount']) && !empty($errors['discount_amount']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Discount Amount
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="discount_amount" autocomplete="off" name="discount_amount" class="form-control" placeholder="Quantity Amount" value="<?php echo (isset($discount_amount) && !empty($discount_amount) ? $discount_amount : set_value('discount_amount')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> onkeyup="calDiscount()">
                                            <span class="help-block"><?php echo (isset($errors['discount_amount']) && !empty($errors['discount_amount']) ? $errors['discount_amount'] : ''); ?></span>
                                        </div>
                                    </div>
									<div class="col-md-3">
                                        <div class="form-group <?php echo (isset($errors['total_amount']) && !empty($errors['total_amount']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Discounted Total Amount
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="total_amount" autocomplete="off" name="total_amount" class="form-control" placeholder="Amount" value="<?php echo (isset($total_amount) && !empty($total_amount) ? $total_amount : set_value('total_amount')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['total_amount']) && !empty($errors['total_amount']) ? $errors['total_amount'] : ''); ?></span>
                                        </div>
                                    </div>
                                   
                                </div>
                            </div>
                            <div class="form-actions right">
                                <button type="button" class="btn default cancel">Cancel</button>
                                <?php if(isset($type) && $type != 'view'){?>
                                <button type="submit" class="btn blue">
                                    <i class="fa fa-check"></i> Save</button>
                                <?php }?>
                            </div>
                        </form>
                        <!-- END FORM-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->
<script type="text/javascript">
select_spare();
 $(document).ready(function(){
    $url = "<?php echo base_url().'stock_distributor/';?>";
    $(".cancel").click(function(){
        location.href =$url;
    });  
	
	$(document).delegate('#spare_id', 'change', function(){
        select_amount();
    });

	 $(document).delegate('#discounttype', 'change', function(){
        select_discount();
    });

  $(document).delegate('#spare_product', 'change', function(){
        select_spare();
    });	
});

function select_spare(){
        
        $selectedCountry = $(".spare_product option:selected").val();
        $spare_part_id = $('#spare_part_id').val();
    
        if($selectedCountry != '' && $selectedCountry != undefined && $selectedCountry != " " ){
        $.ajax({
            type : 'POST',
            url: base_url+'stock/getsparepart',
            data : 'selectedCountry='+$selectedCountry,
            cache : false,
            success:function(result){
                //alert(result);
                    var obj = $.parseJSON(result);
                    var objlength = obj.length;
                    var select_option = '';
                    $('.spare_id').html('<option value="">Select</option>');
                    for(var i=0;i < objlength;i++){
                        if($spare_part_id == obj[i].id){
                            select_option +='<option value="'+obj[i].id+'" selected>'+obj[i].part_name+'</option>'; 
                        }else{
                            select_option +='<option value="'+obj[i].id+'">'+obj[i].part_name+'</option>';     
                        }
                    }
                    $('.spare_id').append(select_option);
            }
        });
    }
} 

function select_amount(){
        $spareid = $(".spare_id option:selected").val();
        if($spareid != '' && $spareid != undefined && $spareid != " " ){
        $.ajax({
            type : 'POST',
            url: base_url+'stock_distributor/getspareid',
            data : 'spareid='+$spareid,
            cache : false,
            success:function(response){
              //  alert(response);return false;
                    var obj = $.parseJSON(response);
                    var objlength = obj.length;
                    var select_option = '';
                 
                     $("input#stock_in").val(obj[0].stock_in);
                    $("input#cost_per_quantity").val(obj[0].cost_per_quantity);
                    
            }
        });
    }  
}

function select_discount(){
	$discount_type = $("#discounttype").val();
	$discount_amt = $("#discount_amount").val();
	$amount = $("#amount").val();
	if($discount_type=='percent'){
		$amt=$amount*$discount_amt / 100;
		$tot=($amount-$amt);
		$('#total_amount').val($tot);
	}else if($discount_type=='amount'){
		$tot=($amount-$discount_amt);
		$('#total_amount').val($tot);
	}else{
		$('#total_amount').val($amount);
	}
}  
</script>

<script type="text/javascript">
function myFunction() {
        var quantityamt= document.getElementById('quantity_amount').value;
        var quantityamt2 = document.getElementById('cost_per_quantity').value;
        var discounttype = $(".discounts option:selected").val();
        var result = parseFloat(quantityamt) * parseFloat(quantityamt2);
        if(!isNaN(result)){
            document.getElementById('amount').value = result;
        }

}

function calDiscount() {
        var discount_amt= document.getElementById('discount_amount').value;
        var actual_amount = document.getElementById('amount').value;
        var discount_type = document.getElementById('discounttype').value;
		if(discount_type=='percent'){
			var amt = parseFloat(actual_amount) * parseFloat(discount_amt) /100;
			var tot = parseFloat(actual_amount) - amt;
			document.getElementById('total_amount').value = tot;
		}else if(discount_type=='amount'){
			var tot = parseFloat(actual_amount) - parseFloat(discount_amt);
			document.getElementById('total_amount').value = tot;
		}else{
			document.getElementById('total_amount').value = actual_amount;
		}
}
</script>