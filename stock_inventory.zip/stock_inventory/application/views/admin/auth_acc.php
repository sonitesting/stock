<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Access</title>
    <!-- <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/global/plugins/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/bootstrap-combined.min.css"> -->
    <link href="<?php echo base_url();?>/assets/global/plugins/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>/assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url();?>/assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <style>
        .verifying {
            background-image: url('<?php echo base_url()?>assets/images/loader.gif');
            background-repeat: no-repeat;
            background-size: 18px;
            background-position: right;
        }
        .verified {
            background-image: url('<?php echo base_url()?>assets/images/verified.png');
            background-repeat: no-repeat;
            background-size: 18px;
            background-position: right;
        }
        #verify_status {
            color: red;
        }
    </style>
    <form action="<?php echo base_url();?>index.php/cms/auth_access/save" method="POST" id="form_file" enctype="multipart/form-data" class="form-horizontal">

        <label>Username : </label>
        <input type="text" name="username" id="username" data-validation="required alphanumeric length" data-validation-length="6-10" data-validation-allowing="-_@#*." data-validation-error-msg="You did not enter a valid username" data-validation-error-msg-container="#username_error" class="" value="<?php echo set_value('username'); ?>" autocomplete="off" />
        </div><span id="verify_status"></span><span id="username_error"></span>
        <br>
        <label>Password : </label>
        <input type="password" name="password" id="password" data-validation-error-msg="You did not enter a valid password" data-validation="required length" data-validation-length="8-16" data-validation-error-msg-container="#password_error" data-display="myDisplayElement1" autocomplete="off" value="" /><span id="myDisplayElement1"></span><span id="password_error"></span>
        <br>
        <label>Confirm Password : </label>
        <input type="password" name="confirm_password" data-validation-error-msg="You did not enter a valid confirm password" data-validation="required length confirmation" data-validation-length="8-16" data-validation-error-msg-container="#confirm_password_error" data-validation-confirm="password" autocomplete="off" value="" /><span id="confirm_password_error"></span>
        <br>
        <label>Email : </label>
        <input type="text" name="email" data-validation-error-msg="You did not enter a valid e-mail" data-validation="required email" data-validation-error-msg-container="#email_error" value="<?php echo set_value('email'); ?>" autocomplete="off" /><span id="email_error"></span>
        <br>
        <label>Mobile No. : </label>
        <input type="tel" name="mobile" data-validation="required number length" data-validation-length="6-10" data-validation-error-msg="You did not enter a valid mobile no." data-validation-error-msg-container="#mobile_error" value="<?php echo set_value('mobile'); ?>" autocomplete="off" /><span id="mobile_error"></span>
        <br>
        <label>Roles : </label>
        <select name="roles" data-validation="required" data-validation-error-msg="You did not select a valid roles" data-validation-error-msg-container="#roles_error">
            <option value="">Select</option>
            <?php if(isset($roles) && !empty($roles)){ foreach($roles as $rl_row){ echo '<option value="'.$rl_row[ 'id']. '">'.$rl_row[ 'roles_name']. '</option>'; }}?>
        </select><span id="roles_error"></span>
        <br>
        <input type="submit" value="Submit" />
    </form>
    <script src="<?php echo base_url();?>/assets/global/plugins/jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>/assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- <script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.js"></script> -->
   <!--  <script type="text/javascript" src="<?php echo base_url();?>assets/js/form_validation.js"></script> -->
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/pStrength.jquery.js"></script>
    <script type="text/javascript">
        var ajaxQueries = new Array();
        $(document).ready(function() {
            // $.validate({
            //     modules: 'html5 security'
            // });
            $('#username').val('');
            $('#password').val('');
            $('#username').keyup(function() {
                $username = $(this).val();
                if ($username.length >= 6 && $username.length <= 10) {
                    stopAjaxQuery();
                    $(this).addClass('verifying');
                    ajaxquery = $.ajax({
                        type: 'POST',
                        url: '<?php echo base_url();?>cms/auth_access/ajax',
                        data: 'type=verifying&username=' + $username,
                        datatype: 'JSON',
                        cache: false,
                        success: function(result) {
                            $('#username').removeClass('verifying');
                            if (result) {
                                if (!$('#username').hasClass('error')) {
                                    $('#username').removeClass('verified');
                                    $('#verify_status').html('Already Used!');
                                }
                            } else {
                                if (!$('#username').hasClass('error'))
                                    $('#username').addClass('verified');
                                $('#verify_status').html('');
                            }
                        }

                    });
                    ajaxQueries.push(ajaxquery);
                } else {
                    $('#verify_status').html('');
                    $(this).removeClass('verifying');
                    $(this).removeClass('verified');
                    stopAjaxQuery();
                }
            });

            var options = {

                onKeyUp: function(evt) {
                    $(evt.target).pwstrength("outputErrorList");
                }
            };
            $('#password').pwstrength(options);
        });

        function stopAjaxQuery() {
            if (typeof(ajaxQueries) == 'undefined')
                ajaxQueries = new Array();
            for (i = 0; i < ajaxQueries.length; i++)
                ajaxQueries[i].abort();
            ajaxQueries = new Array();
        }
    </script>
</body>

</html>