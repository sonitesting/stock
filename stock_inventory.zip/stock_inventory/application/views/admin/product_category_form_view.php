<?php 
    extract((isset($get_data) && !empty($get_data) ? $get_data : ''));
?>


<!-- BEGIN CONTENT -->
<div class="page-content-wrapper" id="content_view">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
    	<!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo base_url();?>">Dashboard</a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <a href="<?php echo base_url().'category';?>"><span>Product List</span></a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <span>Product Detail</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"></h1>
        <!-- END PAGE TITLE-->
        
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            <span class="caption-subject font-blue-hoki bold uppercase">Product Detail</span>
                        </div>
                        <div class="tools">
                            <a href="#" class="collapse"> </a>
                        </div>
                    </div>
                    <div class="portlet-body form">
                        <!-- BEGIN FORM-->
                        <form action="<?php echo base_url().'product/'.$this->uri->segment(2).(!empty($this->uri->segment(3)) ? '/'.$this->uri->segment(3) : '');?>" class="horizontal-form" method="post">
                            <input type="hidden" name="id" value="<?php echo (isset($id) && !empty($id) ? $id : set_value('id')); ?>">
                            <div class="form-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['category_name']) && !empty($errors['category_name']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Product Name
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="category_name" autocomplete="off" name="category_name" class="form-control" placeholder="Category Name" value="<?php echo (isset($category_name) && !empty($category_name) ? $category_name : set_value('category_name')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['category_name']) && !empty($errors['category_name']) ? $errors['category_name'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <!-- <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['menu_icon']) && !empty($errors['menu_icon']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Parent Category
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="parent_id" id="parent_id" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <option value="0" <?php echo ((isset($parent_id) && $parent_id === '0') || set_value('parent_id') === '0' ? 'selected' : '');?>>In-Active</option>
                                                <option value="1" <?php echo ((isset($parent_id) && $parent_id === '1') || set_value('parent_id') === '1' ? 'selected' : '');?>>Active</option>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['parent_id']) && !empty($errors['parent_id']) ? $errors['parent_id'] : ''); ?></span>
                                        </div>
                                    </div> -->
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['status']) && !empty($errors['status']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Status
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="status" id="status" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <option value="0" <?php echo ((isset($status) && $status === '0') || set_value('status') === '0' ? 'selected' : '');?>>In-Active</option>
                                                <option value="1" <?php echo ((isset($status) && $status === '1') || set_value('status') === '1' ? 'selected' : '');?>>Active</option>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['status']) && !empty($errors['status']) ? $errors['status'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions right">
                                <button type="button" class="btn default cancel">Cancel</button>
                                <?php if(isset($type) && $type != 'view'){?>
                                <button type="submit" class="btn blue">
                                    <i class="fa fa-check"></i> Save</button>
                                <?php }?>
                            </div>
                        </form>
                        <!-- END FORM-->
                    </div>
                </div>
            </div>
        </div>
	</div>
    <!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->
<script type="text/javascript">
 $(document).ready(function(){
    $url = "<?php echo base_url().'product/';?>";
    $(".cancel").click(function(){
        location.href =$url;
    });             
});   
</script>