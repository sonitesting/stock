<!-- BEGIN CONTENT -->
<div class="page-content-wrapper" id="content_view">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
    	<!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo base_url();?>">Dashboard</a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <span><?php echo $title;?></span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- BEGIN PAGE TITLE-->
	    <h1 class="page-title">
	    </h1>
	    <!-- END PAGE TITLE-->

	    <!-- BEGIN MESSAGE-->
	    <?php if($this->session->userdata('status_msg') == 'insert_success'){?>
            <div class="alert alert-success">
                <button class="close" data-close="alert"></button> 
                The data saved successfully. 
            </div>
        <?php } else if($this->session->userdata('status_msg') == 'update_success'){?>
            <div class="alert alert-success">
                <button class="close" data-close="alert"></button> 
                The data updated successfully. 
            </div>
        <?php }else if($this->session->userdata('status_msg') == 'already_update_success'){?>
            <div class="alert alert-warning">
                <button class="close" data-close="alert"></button> 
                The data already updated. 
            </div>
        <?php }else if($this->session->userdata('status_msg') == 'error'){?>
            <div class="alert alert-danger">
                <button class="close" data-close="alert"></button> 
                Opps Something went wrong!
            </div>
        <?php } $this->session->unset_userdata('status_msg'); ?>
        <!-- END MESSAGE-->

		<div class="row">
			<div class="col-md-12">
				<?php echo (isset($table_data) && !empty($table_data) ? $table_data : '');?>
			</div>
		</div>
	
		<script type="text/javascript">
			var base_url = "<?php echo $base_url;?>";

			bulk_action();

			$(document).ready(function(){
				
				$offset = <?php echo $offset;?>;
				$urisegment = <?php echo $urisegment;?>;
				$url_segment = location.href.split("/");
				$url_length = $url_segment.length;
				

				if($offset != $urisegment || $offset < 0 || $url_segment[$url_length-1] < 0){
					if($offset > 0){ 	
						$url_segment[$url_length-1] = $offset;
					}else{
						$url_segment[$url_length-1] = '';
					}
					$url_segment = $url_segment.join("/");
					location.href=$url_segment;
				}

				$(document).delegate("#search_form","keypress", function(event) { 
	    			return event.keyCode != 13;
				});

				$(document).delegate('.searching', 'click', function(){
					$data = $("#search_form").serialize();
					$data = $data.replace(/[^&]+=\.?(?:&|$)/g, '');
					//alert($data);
					if($data){
						$.blockUI();
						$.ajax({
							type:'POST',
							url:base_url,
							data:$data,
							cache:false,
							success:function(result){
								var obj = $.parseJSON(result);
								$('#table_generate').replaceWith(utf8_decode(obj.table_data));
								location.href=base_url;
							}
						});
					}$.unblockUI();
				});
				$(document).delegate('#reset', 'click', function(){
					$data = $("#search_form").serialize();
					$data = $data.replace(/[^&]+=\.?(?:&|$)/g, '');
					if($data){
						$.blockUI();
						$.ajax({
							type:'POST',
							url:base_url,
							data:'type=reset',
							cache:false,
							success:function(result){
								if(result)
									location.href=base_url;
									
							}
						});
					}$.unblockUI();
				});

				$(document).delegate('#bulk_action', 'change', function(){
					bulk_action();
				});

				$(document).delegate('.bulk_action', 'click', function(){
					var val = [];
					var bulk_action = $('#bulk_action').val();

					$('.bulkaction:checked').each(function(i){
						val[i]= $(this).val();
					});
					if(val.length <= 0){
						alert('Please select at least one record!');
						return false;
					}else{
						$.blockUI();
						$.ajax({
							type:'POST',
							url: '<?php echo base_url();?>'+bulk_action,
							data:{id:val.join()},
							cache:false,
							success:function(result){
								if(result)
									location.href=base_url;
									
							}
						});
						$.unblockUI();
					}
				});
			});

			function bulk_action(){

				if($('#bulk_action').length > 0){
					$bulk_action = $('#bulk_action').val();
					if($bulk_action.length > 0){
						if($('.bulk-action').find('.bulk_action').length == 0 || $('.bulk-action').find('.bulk_action').length < 0){
							$('.bulk-action').append('<input type="button" class="btn btn-success btn-md btn-transparent btn-circle bulk_action" value="Submit" />');
						}
					}else{
						if($('.bulk-action').find('.bulk_action').length == 1){
							$('.bulk_action').remove();
						}
					}
				}
			}
			

			function action(elem){
				

				$rel = $(elem).attr('rel');
				if($rel == 'add'){
					var	action = 'add';
				}else{
					$rel = $rel.split('_');
					var action = $rel[0];
					var id = $rel[1];
				}


				switch(action){
					case 'add':
						location.href = base_url+'/'+action;
						break;
					case 'edit':
					case 'view':
					case 'pdf':
					case 'download':
					case 'excel':
						location.href = base_url+'/'+action+'/'+id;
						break;
					case 'delete':
						var class_name = $(elem).parent().parent().parent().parent().attr('class');
						$msg = confirm('Are you sure to delete this record ?');
						if($msg == true){
							$.ajax({
								type:"post",
								url: base_url+'/'+action,
								data:"id="+id,
								success:function(result){
									if(result == 1){
										$("."+class_name+"").remove();
										$table_id = $('#table_generate').find('table').attr('id');
										table_rows($table_id);
									}
								}
							});
						}
						break;
					default :
						location.href = base_url+'/'+action;
						break;
				}
			}

			function table_rows(table_id = null){
				$per_page = <?php echo (isset($per_page) && !empty($per_page) ? $per_page : 0);?>;

				$row_count = $('#'+table_id+' > tbody > tr').not('.search_field').length;

				if($row_count <= 0){
					urlsegment($per_page);
				}
				$('#'+table_id+' > tbody > tr > td > span').each(function (i){
					if($(this).hasClass('cnt')){
		            	i++;
		            	$(this).text(i);
		            }
		        });
				return true;
			}

			function utf8_decode (utfstr) {
				var res = '';
				for (var i = 0; i < utfstr.length;) {
					var c = utfstr.charCodeAt(i);

					if (c < 128)
					{
						res += String.fromCharCode(c);
						i++;
					}
					else if((c > 191) && (c < 224))
					{
						var c1 = utfstr.charCodeAt(i+1);
						res += String.fromCharCode(((c & 31) << 6) | (c1 & 63));
						i += 2;
					}
					else
					{
						var c1 = utfstr.charCodeAt(i+1);
						var c2 = utfstr.charCodeAt(i+2);
						res += String.fromCharCode(((c & 15) << 12) | ((c1 & 63) << 6) | (c2 & 63));
						i += 3;
					}
				}
				return res;
			}

			function checkUncheckAll(sender = null,name = null){
	            var chkElements = document.getElementsByName('check_'+name);
	            for (var i = 0; i < chkElements.length; i++) {
	                chkElements[i].checked = sender.checked;
	            }
	        }

	        function checkUnCheckParent(name = null){
	            var chkHeader = document.getElementById('select_all_'+name);
	            var chkElements = document.getElementsByName('check_'+name);
	            var checkedCount = 0;
	            for (var i = 0; i < chkElements.length; i++) {
	                if (chkElements[i].checked) {
	                    checkedCount += 1;
	                }
	            }
	            chkHeader.checked = (checkedCount === chkElements.length);
	        }


	        function urlsegment($per_page = null){
	        	$url_segment = location.href.split("/");
				$url_length = $url_segment.length; 
				if(isNaN($url_segment[$url_length-1])){
					$url_segment = $url_segment.join("/");
					location.href=$url_segment;
				}else if(parseInt($url_segment[$url_length-1]) <= 0 || parseInt($url_segment[$url_length-1]) == undefined){
						location.reload();
				}else if(parseInt($url_segment[$url_length-1]) > 0 || parseInt($url_segment[$url_length-1]) != undefined){

					if(parseInt($url_segment[$url_length-1]) > $per_page){
						$url_segment[$url_length-1] = (parseInt($url_segment[$url_length-1])-$per_page);
					}else{
						$url_segment[$url_length-1] = 0;
					}
					if(parseInt($url_segment[$url_length-1]) == 0 || parseInt($url_segment[$url_length-1]) == undefined){
						$url_segment[$url_length-1] = '';
					}
					$url_segment = $url_segment.join("/");
					location.href=$url_segment;
				}
	        }

		</script>
 	</div>
    <!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->
