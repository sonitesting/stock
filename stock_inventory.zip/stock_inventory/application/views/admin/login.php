<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <head>
        <meta charset="utf-8" />
        <title>Stock Inventory | <?php echo (isset($title) && !empty($title) ? $title : '');?></title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport" />
        <meta content="" name="description" />
        <meta content="" name="author" />
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700&amp;subset=all" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/global/plugins/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/global/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <link href="<?php echo base_url();?>assets/global/plugins/select2/css/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url();?>assets/global/plugins/select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL STYLES -->
        <link href="<?php echo base_url();?>assets/global/css/components.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo base_url();?>assets/global/css/plugins.min.css" rel="stylesheet" type="text/css" />
        <!-- END THEME GLOBAL STYLES -->
        <!-- BEGIN PAGE LEVEL STYLES -->
        <link href="<?php echo base_url();?>assets/pages/css/login-2.min.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL STYLES -->
        <!-- BEGIN THEME LAYOUT STYLES -->
        <!-- END THEME LAYOUT STYLES -->
        <link rel="shortcut icon" href="favicon.ico" /> 
         <style>
            .form-actions{
                border-width: 0px 0px 0px !important;
            }
            .forgot_password{
                margin-top:10px;
            }
            .input-icon > i {
                color: #fff;
            }
        </style> 
    </head>
    <!-- END HEAD -->

    <body class=" login">
        <!-- BEGIN LOGO -->
        <div class="logo">
            <a href="<?php echo base_url();?>">
                <img src="<?php echo base_url();?>assets/pages/img/logo.png" width="77px" alt=""/> </a>
        </div>
        <!-- END LOGO -->
        <!-- BEGIN LOGIN -->
        <div class="content">
            <?php if(isset($steps) && $steps=='1'){?>
            <!-- BEGIN EMAIL VERIFICATION FORM -->
            <form action="<?php echo base_url();?>login" method="post">
                <div class="form-title">
                    <span class="form-title">Email Verification ?</span>
                    <span class="form-subtitle">Enter your e-mail for verification..</span>
                </div>
                <?php if(isset($errors) && !empty($errors)){?>
                <div class="alert alert-danger">
                    <button class="close" data-close="alert"></button>
                    <span><?php echo $errors;?></span>
                </div>
                <?php }?> 
                <div class="form-group">
                    <div class="input-icon">
                        <i class="fa fa-envelope"></i>
                        <input class="form-control placeholder-no-fix" type="email" autocomplete="off" placeholder="Email" name="email" /> </div>
                </div>
                <div class="form-actions">
                    <a href="<?php echo base_url(); ?>logout" id="back-btn" class="btn red"> Logout </a>
                    <button type="submit" class="btn green pull-right"> Submit </button>
                </div>
            </form>
            <!-- END EMAIL VERIFICATION FORM -->
            <?php }else if(isset($steps) && $steps=='2'){?>
            <!-- BEGIN EMAIL VERIFICATION MSG -->
            <div class="form-title">
                <span class="form-title">Email Verification ?</span>
                <span class="form-subtitle"> Please check your email to verify your email id.</span>
            </div>
            <div class="form-actions">
                <a href="<?php echo base_url();?>logout" id="back-btn" class="btn red "> Logout </a>
            </div>
            <!-- END EMAIL VERIFICATION MSG -->
            <?php }else if(isset($steps) && $steps=='3'){?>
            <!-- BEGIN FORGOT PASSWORD FORM -->
            <form action="<?php echo base_url();?>forgetpassword" method="post">
                <div class="form-title">
                    <span class="form-title">Forget Password ?</span>
                    <span class="form-subtitle">Enter your e-mail to reset it.</span>
                </div>
                <?php if(isset($errors) && !empty($errors)){?>
                <div class="alert alert-danger">
                    <button class="close" data-close="alert"></button>
                    <span><?php echo $errors;?></span>
                </div>
                <?php }?>
                <div class="form-group">
                    <div class="input-icon">
                        <i class="fa fa-envelope"></i>
                        <input class="form-control placeholder-no-fix" type="email" autocomplete="off" placeholder="Email" name="forgetpass" /> </div>
                </div>
                <div class="form-actions">
                    <a href="<?php echo base_url();?>login" id="back-btn" class="btn grey-salsa">Login</a>
                    <button type="submit" class="btn green pull-right"> Submit </button>
                </div>
            </form>
            <!-- END FORGOT PASSWORD FORM -->
            <?php }else if(isset($steps) && $steps=='4'){?>
            <!-- BEGIN All MSG -->
            <span align="center"><?php echo (isset($msg) && !empty($msg) ? $msg : '')?></span>
            <div class="form-actions">
                <?php if($this->session->userdata('user_id')){?>
                    <a href="<?php echo base_url();?>dashboard" class="btn green pull-right">Go To Dashboard</a>
                <?php }else{?>
                    <a href="<?php echo base_url();?>login" class="btn green pull-right">Go To Login</a>
                <?php }?>
            </div>
            <!-- END All MSG -->
            <?php }else if(isset($steps) && $steps == '5'){?>
            <!-- BEGIN Resetpassword FORM -->
            <form class="login-form" method="post" action="">
                <div class="form-title">
                    <span class="form-title">Reset Password</span>
                </div>
                <?php if(isset($errors) && !empty($errors)){?>
                <div class="alert alert-danger">
                    <button class="close" data-close="alert"></button>
                    <span><?php echo $errors;?></span>
                </div>
                <?php }?> 
                <div class="form-group">
                    <!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
                    <label class="control-label visible-ie8 visible-ie9">New Password</label>
                    <div class="input-icon">
                        <i class="fa fa-user"></i>
                        <input class="form-control placeholder-no-fix" type="password" autocomplete="off" placeholder="New Password" name="newpassword" id="newpassword" required value="" /> </div>
                </div>
                <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9">Confirm Password</label>
                    <div class="input-icon">
                        <i class="fa fa-lock"></i>
                        <input class="form-control placeholder-no-fix" type="password" autocomplete="off" placeholder="Confirm Password" name="confirmpassword" id="confirmpassword" /> </div>
                </div>
                <div class="form-actions">
                    <a href="<?php echo base_url(); ?>login" class="btn btn-info">Back To Login </a>
                    <button type="submit" class="btn green pull-right"> Submit </button>
                    
                </div>
            </form>
            <!-- END Resetpassword FORM -->
            <?php }else{?>
            <!-- BEGIN LOGIN FORM -->
            <form class="login-form" action="<?php echo base_url();?>login" method="post">
                <div class="form-title">
                    <span class="form-title">Welcome.</span>
                    <span class="form-subtitle">Please login.</span>
                </div>
                <?php if(isset($errors) && !empty($errors)){?>
                <div class="alert alert-danger">
                    <button class="close" data-close="alert"></button>
                    <span><?php echo $errors;?></span>
                </div>
                <?php }?> 
                <div class="form-group">
                    <!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
                    <label class="control-label visible-ie8 visible-ie9">Username</label>
                    <div class="input-icon">
                        <i class="fa fa-user" style="padding: 3px;"></i>
                        <input class="form-control placeholder-no-fix" type="text" autocomplete="off" placeholder="Username" name="username" id="username" required value="<?php echo (isset($username) && !empty($username) ? $username : '');?>" /> </div>
                </div>
                <div class="form-group">
                    <label class="control-label visible-ie8 visible-ie9">Password</label>
                    <div class="input-icon">
                        <i class="fa fa-lock" style="padding: 3px;"></i>
                        <input class="form-control placeholder-no-fix" type="password" autocomplete="off" placeholder="Password" name="password" id="password" /> </div>
                </div>
                 <div class="form-actions">
                    <button type="submit" class="btn red btn-block uppercase">Login</button>
                </div>
                <div class="form-actions">
                    <div class="forget-password-block" style="text-align: center;">
                        <a href="<?php echo base_url();?>forgetpassword" id="forget-password" class="forget-password">Forgot Password?</a>
                    </div>
                </div>
            </form>
            <!-- END LOGIN FORM -->
            <?php }?>
        </div>
        <div class="copyright">Developed By E-Softbunch 2017</div>
        <!-- END LOGIN -->
        <!--[if lt IE 9]>
<script src="<?php echo base_url();?>assets/global/plugins/respond.min.js"></script>
<script src="<?php echo base_url();?>assets/global/plugins/excanvas.min.js"></script> 
<![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo base_url();?>assets/global/plugins/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/js.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo base_url();?>assets/global/plugins/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>assets/global/plugins/select2/js/select2.full.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo base_url();?>assets/global/scripts/app.min.js" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo base_url();?>assets/pages/scripts/login.min.js" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <!-- END THEME LAYOUT SCRIPTS -->
</body>
</html>