
<!-- BEGIN CONTENT -->
<div class="page-content-wrapper" id="content_view">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
    	<!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo base_url();?>">Dashboard</a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <span>Menu Position</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"></h1>
        <!-- END PAGE TITLE-->
        
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            <span class="caption-subject font-blue-hoki bold uppercase">Menu Position </span>
                        </div>
                        <div class="tools">
                            <a href="#" class="collapse"> </a>
                        </div>
                    </div>
                    <div class="portlet-body">
                                        <div class="table-scrollable">
                                            <table class="table table-striped table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th> Sr. No.</th>
                                                        <th scope="col" > Menu Name </th>
                                                        <th>Menu Category</th>
                                                        <th>Current Position</th>
                                                        <th scope="col">Set Position </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php if(!empty($menu_list)){
                                                        $cnt = 0;
                                                        foreach($menu_list as $row){
                                                            $cnt++;
                                                ?>
                                                    <tr>
                                                        <td><?php echo $cnt;?></td>
                                                        <td> <?php echo $row['menu_name']?> </td>
                                                        <td><?php echo $row['menu_cat_name']?></td>
                                                         
                                                        <td><?php echo $row['ctl_menu_position']?></td>
                                                        <td>
                                                        <?php if($cnt == 1){ echo '&nbsp;&nbsp;';}?>

                                                        <?php if($cnt != count($menu_list)){?>
                                                        <a href="javascript:;" onclick="position(<?php echo $row['id']?>,'down')"><i class="fa fa-arrow-down"></i></a>
                                                        <?php }?>
                                                         &nbsp;&nbsp;
                                                        <?php if($cnt != 1){?>
                                                        <a href="javascript:;" onclick="position(<?php echo $row['id']?>,'up')"><i class="fa fa-arrow-up"></i></a> 
                                                        <?php }?>
                                                        <span style="float:right;"><input  type="text" placeholder="Enter Position No." id="set_position_<?php echo $row['id']?>" autocomplete="off" value=""><input autocomplete="off" type="hidden" id="current_position_<?php echo $row['id']?>" value="<?php echo $row['ctl_menu_position'];?>"><button onclick="set_position(this);" id="<?php echo $row['id']?>" class="btn btn-primary">Set</button></span>
                                                        </td>

                                                    </tr>
                                                <?php }}else{ ?>
                                                    <tr>
                                                        <td colspan="4" syle="text-align:center;"> No data found!</td>
                                                    </tr>
                                                <?php }?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                </div>
            </div>
        </div>
	</div>
    <!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->
<script type="text/javascript">
 
var url = base_url+'menu_position/';
function position(index,position){
    $.ajax({
        type:'POST',
        url: url+'position_level',
        data:{id:index,position:position},
        cache:false,
        success:function(result){
            //alert(result);return false;
            if(result)
                location.href=url;
                
        }

    });
}

function set_position(index){

    $id = $(index).attr('id');

    $current_position = $('#current_position_'+$id).val();
    $set_position = $('#set_position_'+$id).val();
    
    if($set_position <= 0 || $set_position == '' || $set_position == " " || $set_position == undefined){
        alert('Please enter the valid number');
        return false;
    }else{
        //alert($current_position+'===='+$set_position);return false;
        $.ajax({
            type:'POST',
            url: url+'position_level',
            data:{current_position:$current_position,set_position:$set_position},
            cache:false,
            success:function(result){
                //alert(result);return false;
                if(result)
                    location.href=url;
                    
            }

        });
    }
}
 
</script>