<?php 
    extract((isset($get_data) && !empty($get_data) ? $get_data : ''));
?>

<!-- BEGIN CONTENT -->
<div class="page-content-wrapper" id="content_view">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo base_url();?>">Dashboard</a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <a href="<?php echo base_url().'customer_query';?>"><span>Customer Query List</span></a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <span>Customer Query Detail</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"></h1>
        <!-- END PAGE TITLE-->
        
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            <span class="caption-subject font-blue-hoki bold uppercase">Customer Query Detail</span>
                        </div>
                        <div class="tools">
                            <a href="#" class="collapse"> </a>
                        </div>
                    </div>
                    <div class="portlet-body form">
                        <!-- BEGIN FORM-->
                        <form action="<?php echo base_url().'customer_query/'.$this->uri->segment(2).(!empty($this->uri->segment(3)) ? '/'.$this->uri->segment(3) : '');?>" class="horizontal-form" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?php echo (isset($id) && !empty($id) ? $id : set_value('id')); ?>">
                            <div class="form-body">
                                <h3 class="form-section">Person Info</h3>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['first_name']) && !empty($errors['first_name']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                First Name
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="first_name" autocomplete="off" name="first_name" class="form-control" placeholder="First Name" value="<?php echo (isset($first_name) && !empty($first_name) ? $first_name : set_value('first_name')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['first_name']) && !empty($errors['first_name']) ? $errors['first_name'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['last_name']) && !empty($errors['last_name']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Last Name
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="last_name" autocomplete="off" name="last_name" class="form-control" placeholder="Last Name" value="<?php echo (isset($last_name) && !empty($last_name) ? $last_name : set_value('last_name')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['last_name']) && !empty($errors['last_name']) ? $errors['last_name'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['gender']) && !empty($errors['gender']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Gender
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="gender" id="gender" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <option value="Male" <?php echo ((isset($gender) && $gender == 'Male') || set_value('gender') == 'Male' ? 'selected' : '');?>>Male</option>
                                                <option value="Female" <?php echo ((isset($gender) && $gender == 'Female') || set_value('gender') == 'Female' ? 'selected' : '');?>>Female</option>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['gender']) && !empty($errors['gender']) ? $errors['gender'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label">
                                                DOB
                                            </label>
                                            <input type="text" id="dob" name="dob" autocomplete="off" class="form-control" placeholder="yyyy-mm-dd" value="<?php echo (isset($dob) && !empty($dob) ? $dob : set_value('dob')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['email']) && !empty($errors['email']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Email Id
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="email" autocomplete="off" name="email" class="form-control" placeholder="Email Id" value="<?php echo (isset($email) && !empty($email) ? $email : set_value('email')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['email']) && !empty($errors['email']) ? $errors['email'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['mobile']) && !empty($errors['mobile']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Mobile No.
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="mobile" autocomplete="off" name="mobile" class="form-control" placeholder="Mobile No." size="10" value="<?php echo (isset($mobile) && !empty($mobile) ? $mobile : set_value('mobile')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['mobile']) && !empty($errors['mobile']) ? $errors['mobile'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                                
                                <h3 class="form-section">Address</h3>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group <?php echo (isset($errors['address']) && !empty($errors['address']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Street
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="address" autocomplete="off" name="address" class="form-control" placeholder="Street" value="<?php echo (isset($address) && !empty($address) ? $address : set_value('address')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['address']) && !empty($errors['address']) ? $errors['address'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['country_id']) && !empty($errors['country_id']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Country
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="country_id" id="country_id" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <?php if(isset($country) && !empty($country)){
                                                    foreach($country as $row){
                                                ?>
                                                <option value="<?php echo $row['id'];?>" <?php echo ((isset($country_id) && $country_id ===  $row['id']) || set_value('country_id') === $row['id'] ? 'selected' : '');?>><?php echo ucwords($row['country_name']);?></option>
                                                <?php }}?>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['country_id']) && !empty($errors['country_id']) ? $errors['country_id'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['state_id']) && !empty($errors['state_id']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                State
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="hidden" id="state_id_val" autocomplete="off" value="<?php echo (isset($state_id) && !empty($state_id) ? $state_id : set_value('state_id')); ?>">
                                            <select class="form-control" name="state_id" id="state_id" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <?php if(isset($state) && !empty($state)){
                                                    foreach($state as $row){
                                                ?>
                                                <option value="<?php echo $row['id'];?>" <?php echo ((isset($state_id) && $state_id ===  $row['id']) || set_value('state_id') === $row['id'] ? 'selected' : '');?>><?php echo ucwords($row['state_name']);?></option>
                                                <?php }}?>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['state_id']) && !empty($errors['state_id']) ? $errors['state_id'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['city_id']) && !empty($errors['city_id']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                City
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="hidden" id="city_id_val" autocomplete="off" value="<?php echo (isset($city_id) && !empty($city_id) ? $city_id : set_value('city_id')); ?>">
                                            <select class="form-control" name="city_id" id="city_id" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <?php if(isset($city) && !empty($city)){
                                                    foreach($city as $row){
                                                ?>
                                                <option value="<?php echo $row['id'];?>" <?php echo ((isset($city_id) && $city_id ===  $row['id']) || set_value('city_id') === $row['id'] ? 'selected' : '');?>><?php echo ucwords($row['city_name']);?></option>
                                                <?php }}?>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['city_id']) && !empty($errors['city_id']) ? $errors['city_id'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['postcode']) && !empty($errors['postcode']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Pincode
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="postcode" autocomplete="off" name="postcode" class="form-control" placeholder="Pincode"  value="<?php echo (isset($postcode) && !empty($postcode) ? $postcode : set_value('postcode')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['postcode']) && !empty($errors['postcode']) ? $errors['postcode'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <h3 class="form-section">Complain Message</h3>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['product_cat_id']) && !empty($errors['product_cat_id']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Category
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="product_cat_id" id="product_cat_id" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <?php if(isset($category) && !empty($category)){
                                                    foreach($category as $row){
                                                ?>
                                                <option value="<?php echo $row['id'];?>" <?php echo ((isset($product_cat_id) && $product_cat_id ===  $row['id']) || set_value('product_cat_id') === $row['id'] ? 'selected' : '');?>><?php echo ucwords($row['category_name']);?></option>
                                                <?php }}?>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['product_cat_id']) && !empty($errors['product_cat_id']) ? $errors['product_cat_id'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group <?php echo (isset($errors['status']) && !empty($errors['status']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Status
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="status" id="status" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <option value="1" <?php echo ((isset($status) && $status === '1') || set_value('status') === '1' ? 'selected' : '');?>>Open</option>
                                                <option value="0" <?php echo ((isset($status) && $status === '0') || set_value('status') === '0' ? 'selected' : '');?>>Closed</option>
                                                <option value="2" <?php echo ((isset($status) && $status === '2') || set_value('status') === '1' ? 'selected' : '');?>>Pending</option>
                                                <option value="3" <?php echo ((isset($status) && $status === '3') || set_value('status') === '1' ? 'selected' : '');?>>Process</option>
                                                <option value="4" <?php echo ((isset($status) && $status === '4') || set_value('status') === '1' ? 'selected' : '');?>>Waiting</option>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['status']) && !empty($errors['status']) ? $errors['status'] : ''); ?></span>
                                        </div>
                                    </div>

                                    <div class="col-md-3">
                                        <div class="form-group <?php echo (isset($errors['service_center_id']) && !empty($errors['service_center_id']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Service Center
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                             <input type="hidden" id="service_center_id" autocomplete="off" name="service_center_id" class="form-control" placeholder="Pincode"  value="<?php echo (isset($service_center_id) && !empty($service_center_id) ? $service_center_id : set_value('service_center_id')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>

                                                <?php $service_name = '';
                                                    if(isset($service_center) && !empty($service_center)){
                                                    foreach($service_center as $row){
                                                   if((isset($service_center_id) && $service_center_id ===  $row['id']) || set_value('service_center_id') === $row['id']){ 
                                                        $service_name = ucwords($row['first_name'].' '.$row['last_name']); 
                                                 }}}?>
                                                <input type="text" class="form-control" value="<?php echo $service_name;?>" readonly>
                                            
                                            <span class="help-block"><?php echo (isset($errors['service_center_id']) && !empty($errors['service_center_id']) ? $errors['service_center_id'] : ''); ?></span>
                                        </div>
                                    </div>




                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group <?php echo (isset($errors['complain_msg']) && !empty($errors['complain_msg']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Complain Message
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <textarea id="complain_msg" autocomplete="off" name="complain_msg" class="form-control" placeholder="Complain Message (Notes: Only 225 Character)" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>><?php echo (isset($complain_msg) && !empty($complain_msg) ? $complain_msg : set_value('complain_msg')); ?></textarea>
                                            <span class="help-block"><?php echo (isset($errors['complain_msg']) && !empty($errors['complain_msg']) ? $errors['complain_msg'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions right">
                                <button type="button" class="btn default cancel">Cancel</button>
                                <?php if(isset($type) && $type != 'view'){?>
                                <button type="submit" class="btn blue">
                                    <i class="fa fa-check"></i> Save</button>
                                <?php }?>
                            </div>
                        </form>
                        <!-- END FORM-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->
<script src="<?php echo base_url();?>assets/js/ajaxcall_csc.js" type="text/javascript"></script>
<script type="text/javascript">
    
$(document).ready(function(){
    $url = "<?php echo base_url().'customer_query/';?>";
    $(".cancel").click(function(){
        location.href =$url;
    });  

});   
</script>