<?php 
    extract((isset($get_data) && !empty($get_data) ? $get_data : ''));
?>

<!-- BEGIN CONTENT -->
<div class="page-content-wrapper" id="content_view">
    <!-- BEGIN CONTENT BODY -->
    <div class="page-content">
        <!-- BEGIN PAGE BAR -->
        <div class="page-bar">
            <ul class="page-breadcrumb">
                <li>
                    <a href="<?php echo base_url();?>">Dashboard</a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <a href="<?php echo base_url().'partners';?>"><span>Partners List</span></a>
                    <i class="fa fa-angle-right"></i>
                </li>
                <li>
                    <span>Partners Detail</span>
                </li>
            </ul>
        </div>
        <!-- END PAGE BAR -->
        <!-- BEGIN PAGE TITLE-->
        <h1 class="page-title"></h1>
        <!-- END PAGE TITLE-->
        
        <div class="row">
            <div class="col-md-12">
                <div class="portlet light bordered">
                    <div class="portlet-title">
                        <div class="caption">
                            <span class="caption-subject font-blue-hoki bold uppercase">Partners Detail</span>
                        </div>
                        <div class="tools">
                            <a href="#" class="collapse"> </a>
                        </div>
                    </div>
                    <div class="portlet-body form">
                        <!-- BEGIN FORM-->
                        <form action="<?php echo base_url().'partners/'.$this->uri->segment(2).(!empty($this->uri->segment(3)) ? '/'.$this->uri->segment(3) : '');?>" class="horizontal-form" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?php echo (isset($id) && !empty($id) ? $id : set_value('id')); ?>">
                            <div class="form-body">
                                <h3 class="form-section">Person Info</h3>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['first_name']) && !empty($errors['first_name']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                First Name
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="first_name" name="first_name" class="form-control" placeholder="First Name" value="<?php echo (isset($first_name) && !empty($first_name) ? $first_name : set_value('first_name')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['first_name']) && !empty($errors['first_name']) ? $errors['first_name'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['last_name']) && !empty($errors['last_name']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Last Name
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="last_name" name="last_name" class="form-control" placeholder="Last Name" value="<?php echo (isset($last_name) && !empty($last_name) ? $last_name : set_value('last_name')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['last_name']) && !empty($errors['last_name']) ? $errors['last_name'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['gender']) && !empty($errors['gender']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Gender
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="gender" id="gender" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <option value="Male" <?php echo ((isset($gender) && $gender == 'Male') || set_value('gender') == 'Male' ? 'selected' : '');?>>Male</option>
                                                <option value="Female" <?php echo ((isset($gender) && $gender == 'Female') || set_value('gender') == 'Female' ? 'selected' : '');?>>Female</option>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['gender']) && !empty($errors['gender']) ? $errors['gender'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="control-label">
                                                DOB
                                            </label>
                                            <input type="text" id="dob" name="dob" class="form-control" placeholder="yyyy-mm-dd" value="<?php echo (isset($dob) && !empty($dob) ? $dob : set_value('dob')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['email']) && !empty($errors['email']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Email Id
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="email" name="email" class="form-control" placeholder="Email Id" value="<?php echo (isset($email) && !empty($email) ? $email : set_value('email')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['email']) && !empty($errors['email']) ? $errors['email'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['mobile']) && !empty($errors['mobile']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Mobile No.
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="mobile" name="mobile" class="form-control" placeholder="Mobile No." size="10" value="<?php echo (isset($mobile) && !empty($mobile) ? $mobile : set_value('mobile')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['mobile']) && !empty($errors['mobile']) ? $errors['mobile'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                                
                                <h3 class="form-section">Address</h3>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group <?php echo (isset($errors['address']) && !empty($errors['address']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Street
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="address" name="address" class="form-control" placeholder="Street" value="<?php echo (isset($address) && !empty($address) ? $address : set_value('address')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['address']) && !empty($errors['address']) ? $errors['address'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['country_id']) && !empty($errors['country_id']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Country
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="country_id" id="country_id" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <?php if(isset($country) && !empty($country)){
                                                    foreach($country as $row){
                                                ?>
                                                <option value="<?php echo $row['id'];?>" <?php echo ((isset($country_id) && $country_id ===  $row['id']) || set_value('country_id') === $row['id'] ? 'selected' : '');?>><?php echo ucwords($row['country_name']);?></option>
                                                <?php }}?>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['country_id']) && !empty($errors['country_id']) ? $errors['country_id'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['state_id']) && !empty($errors['state_id']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                State
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="state_id" id="state_id" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <?php if(isset($state) && !empty($state)){
                                                    foreach($state as $row){
                                                ?>
                                                <option value="<?php echo $row['id'];?>" <?php echo ((isset($state_id) && $state_id ===  $row['id']) || set_value('state_id') === $row['id'] ? 'selected' : '');?>><?php echo ucwords($row['state_name']);?></option>
                                                <?php }}?>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['state_id']) && !empty($errors['state_id']) ? $errors['state_id'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['city_id']) && !empty($errors['city_id']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                City
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="city_id" id="city_id" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <?php if(isset($city) && !empty($city)){
                                                    foreach($city as $row){
                                                ?>
                                                <option value="<?php echo $row['id'];?>" <?php echo ((isset($city_id) && $city_id ===  $row['id']) || set_value('city_id') === $row['id'] ? 'selected' : '');?>><?php echo ucwords($row['city_name']);?></option>
                                                <?php }}?>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['city_id']) && !empty($errors['city_id']) ? $errors['city_id'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['postcode']) && !empty($errors['postcode']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Pincode
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="postcode" name="postcode" class="form-control" placeholder="Pincode"  value="<?php echo (isset($postcode) && !empty($postcode) ? $postcode : set_value('postcode')); ?>" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['postcode']) && !empty($errors['postcode']) ? $errors['postcode'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <h3 class="form-section">Access</h3>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['username']) && !empty($errors['username']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Username
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="username" name="username" class="form-control" placeholder="Username" value="<?php echo (isset($username) && !empty($username) ? $username : set_value('username')); ?>" <?php if(((isset($type) && !empty($type) && $type == 'view') || (isset($username) && !empty($username)) || set_value('username')) &&  (isset($type) && !empty($type) && $type != 'add')){ echo 'readonly'; }?>>
                                            <span class="help-block"><?php echo (isset($errors['username']) && !empty($errors['username']) ? $errors['username'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['profile_pic']) && !empty($errors['profile_pic']) ? 'has-error' : ''); ?>" >
                                            <label class="control-label col-md-12 col-xs-12" style="padding-left: inherit;">
                                                Profile Pic.
                                            </label>
                                            <div style="text-align:left;" class="col-md-6 col-xs-6">
                                            <input type="file" id="profile_pic" name="profile_pic"  placeholder="Profile Pic"  <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> style="padding-left: inherit;">
                                            <span class="help-block"><?php echo (isset($errors['profile_pic']) && !empty($errors['profile_pic']) ? $errors['profile_pic'] : ''); ?></span>
                                            </div>
                                            <span id='dvPreview' class="col-md-6 col-xs-6" style="height:100px;margin-top: -30px;text-align:right;">
                                                <?php if(isset($profile_pic) && !empty($profile_pic)){
                                                    $pic = $profile_pic;
                                                    }else{
                                                        $pic = set_value('profile_img');
                                                    }
                                                    if(!empty($pic)){
                                                ?>
                                                    <img src="<?php echo base_url().$pic;?>" class="img-responsive img-thumbnail" style="height:100px;">
                                                <?php }else{?>
                                                    <img src="<?php echo base_url().'assets/images/pic.png';?>" class="img-responsive img-thumbnail" style="height:100px;">
                                                <?php }?>
                                            </span>
                                            <input type="hidden" value="<?php echo (isset($profile_pic) && !empty($profile_pic) ? $profile_pic : set_value('profile_img')); ?>" name="profile_img" id="profile_img">
                                        </div>
                                    </div>
                                </div>




                                <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['document']) && !empty($errors['document']) ? 'has-error' : ''); ?>" >
                                            <label class="control-label col-md-12 col-xs-12" style="padding-left: inherit;">
                                                Document.
                                            </label>
                                            <div style="text-align:left;" class="col-md-6 col-xs-6">
                                            <input type="file" id="document" name="document"  placeholder="document Pic"  <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> style="padding-left: inherit;">
                                            <span class="help-block"><?php echo (isset($errors['document']) && !empty($errors['document']) ? $errors['document'] : ''); ?></span>
                                            </div>
                                            <span id='dvPreview_doc' class="col-md-6 col-xs-6" style="height:100px;margin-top: -30px;text-align:right;">
                                                <?php if(isset($document) && !empty($document)){
                                                    $docpic = $document;
                                                    }else{
                                                        $docpic = set_value('doc_img');
                                                    }
                                                    if(!empty($docpic)){
                                                ?>
                                                    <img src="<?php echo base_url().$docpic;?>" class="img-responsive img-thumbnail" style="height:100px;">
                                                <?php }else{?>
                                                    
                                                <?php }?>
                                            </span>
                                            <input type="hidden" value="<?php echo (isset($document) && !empty($document) ? $document : set_value('doc_img')); ?>" name="doc_img" id="doc_img">
                                        </div>
                                    </div>
                                </div>
                                <?php if(isset($type) && $type == 'add'){?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['password']) && !empty($errors['password']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Password
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="password" name="password" class="form-control" placeholder="Password" value="">
                                            <span class="help-block"><?php echo (isset($errors['password']) && !empty($errors['password']) ? $errors['password'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['cfm_password']) && !empty($errors['cfm_password']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Confirm Password
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <input type="text" id="cfm_password" name="cfm_password" class="form-control" placeholder="Confirm Password" value="">
                                            <span class="help-block"><?php echo (isset($errors['cfm_password']) && !empty($errors['cfm_password']) ? $errors['cfm_password'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <?php }?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['roles_id']) && !empty($errors['roles_id']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Roles
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="roles_id" id="roles_id" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <?php if(isset($roles) && !empty($roles)){
                                                    foreach($roles as $row){
                                                ?>
                                                <option value="<?php echo $row['id'];?>" <?php echo ((isset($roles_id) && $roles_id ===  $row['id']) || set_value('roles_id') === $row['id'] ? 'selected' : '');?>><?php echo ucwords($row['roles_name']);?></option>
                                                <?php }}?>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['roles_id']) && !empty($errors['roles_id']) ? $errors['roles_id'] : ''); ?></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group <?php echo (isset($errors['status']) && !empty($errors['status']) ? 'has-error' : ''); ?>">
                                            <label class="control-label">
                                                Status
                                                <span class="required" aria-required="true"> * </span>
                                            </label>
                                            <select class="form-control" name="status" id="status" <?php if(isset($type) && !empty($type) && $type == 'view'){ echo 'disabled'; }?> >
                                                <option value="">Select</option>
                                                <option value="0" <?php echo ((isset($status) && $status === '0') || set_value('status') === '0' ? 'selected' : '');?>>In-Active</option>
                                                <option value="1" <?php echo ((isset($status) && $status === '1') || set_value('status') === '1' ? 'selected' : '');?>>Active</option>
                                            </select>
                                            <span class="help-block"><?php echo (isset($errors['status']) && !empty($errors['status']) ? $errors['status'] : ''); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions right">
                                <button type="button" class="btn default cancel">Cancel</button>
                                <?php if(isset($type) && $type != 'view'){?>
                                <button type="submit" class="btn blue">
                                    <i class="fa fa-check"></i> Save</button>
                                <?php }?>
                            </div>
                        </form>
                        <!-- END FORM-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END CONTENT BODY -->
</div>
<!-- END CONTENT -->
<script type="text/javascript">
    var matched, browser;

jQuery.uaMatch = function( ua ) {
    ua = ua.toLowerCase();

    var match = /(chrome)[ \/]([\w.]+)/.exec( ua ) ||
        /(webkit)[ \/]([\w.]+)/.exec( ua ) ||
        /(opera)(?:.*version|)[ \/]([\w.]+)/.exec( ua ) ||
        /(msie) ([\w.]+)/.exec( ua ) ||
        ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec( ua ) ||
        [];

    return {
        browser: match[ 1 ] || "",
        version: match[ 2 ] || "0"
    };
};

matched = jQuery.uaMatch( navigator.userAgent );
browser = {};

if ( matched.browser ) {
    browser[ matched.browser ] = true;
    browser.version = matched.version;
}

// Chrome is Webkit, but Webkit is also Safari.
if ( browser.chrome ) {
    browser.webkit = true;
} else if ( browser.webkit ) {
    browser.safari = true;
}

jQuery.browser = browser;



 $(document).ready(function(){
    $url = "<?php echo base_url().'partners/';?>";
    $(".cancel").click(function(){
        location.href =$url;
    });  

    $("#profile_pic").change(function () {
        $("#dvPreview").html("");
        var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
        if (regex.test($(this).val().toLowerCase())) {
            if ($.browser.msie && parseFloat(jQuery.browser.version) <= 9.0) {
                $("#dvPreview").show();
                $("#dvPreview")[0].filters.item("DXImageTransform.Microsoft.AlphaImageLoader").src = $(this).val();
            }
            else {
                if (typeof (FileReader) != "undefined") {
                    $("#dvPreview").show();
                    $("#dvPreview").append("<img />");
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $("#dvPreview img").attr("src", e.target.result);
                        $("#dvPreview img").attr("class","img-responsive img-thumbnail");
                        $("#dvPreview img").attr("style","height:100px;");
                    }
                    reader.readAsDataURL($(this)[0].files[0]);
                } else {
                    alert("This browser does not support FileReader.");
                }
            }
        } else {
            $('#profile_pic').val(null);
            $profile_img = $('#profile_img').val();
            if($profile_img != ''){
            $("#dvPreview").html('<img src="<?php echo base_url();?>'+$profile_img+'" class="img-responsive img-thumbnail" style="height:100px;">');
            }else{
                $("#dvPreview").html('<img src="<?php echo base_url().'assets/images/pic.png';?>" class="img-responsive img-thumbnail" style="height:100px;">');
            }
            alert("Please upload a valid image file.");
        }
    });



$url_doc = "<?php echo base_url().$this->router->class.'/';?>";
    $(".cancel").click(function(){
        location.href =$url_doc;
    });  

    $("#document").change(function () {
        $("#dvPreview_doc").html("");
        var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.pdf|.doc)$/;
        if (regex.test($(this).val().toLowerCase())) {
            if ($.browser.msie && parseFloat(jQuery.browser.version) <= 9.0) {
                $("#dvPreview_doc").show();
                $("#dvPreview_doc")[0].filters.item("DXImageTransform.Microsoft.AlphaImageLoader").src = $(this).val();
            }
            else {
                if (typeof (FileReader) != "undefined") {
                    $("#dvPreview_doc").show();
                    $("#dvPreview_doc").append("<img />");
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $("#dvPreview_doc img").attr("src", e.target.result);
                        $("#dvPreview_doc img").attr("class","img-responsive img-thumbnail");
                        $("#dvPreview_doc img").attr("style","height:100px;");
                    }
                    reader.readAsDataURL($(this)[0].files[0]);
                } else {
                    alert("This browser does not support FileReader.");
                }
            }
        } else {
            $('#document').val(null);
            $doc_img = $('#doc_img').val();
            if($doc_img != ''){
            $("#dvPreview_doc").html('<img src="<?php echo base_url();?>'+$doc_img+'" class="img-responsive img-thumbnail" style="height:100px;">');
            }else{
                $("#dvPreview_doc").html('<img src="<?php echo base_url().'assets/images/pic.png';?>" class="img-responsive img-thumbnail" style="height:100px;">');
            }
            alert("Please upload a valid doc file.");
        }
    });


});   
</script>